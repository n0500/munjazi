import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export default function Footer() {
    return (_jsxs("footer", { style: {
            borderTop: '1px solid #e2e2e2',
            padding: '14px',
            textAlign: 'center',
            marginTop: 40,
            fontFamily: "'IBM Plex Sans Arabic', sans-serif",
        }, dir: "rtl", children: [_jsx("div", { style: { fontSize: 10, color: '#4a4a4a' }, children: "\u0645\u0646\u062C\u0632\u064A \u00A9 2026 \u2014 \u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0642 \u0645\u062D\u0641\u0648\u0638\u0629" }), _jsx("div", { style: { fontSize: 9, color: '#8a8a8a', marginTop: 2 }, children: "\u062A\u0635\u0645\u064A\u0645 \u0648\u062A\u0637\u0648\u064A\u0631: \u0623. \u0646\u0647\u0649 \u0641\u0627\u0644\u062D \u0627\u0644\u0645\u0637\u064A\u0631\u064A" })] }));
}
