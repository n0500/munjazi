import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { getPendingActions, activateAction, deferAction } from '../lib/actionEngine.js';
const TYPE_LABEL = {
    remedial: { icon: '⚠', text: 'علاجي' },
    enrichment: { icon: '⭐', text: 'إثرائي' },
};
export default function QuickReview({ schoolId, classId, teacherUid }) {
    const [pending, setPending] = useState(null);
    const [expandedId, setExpandedId] = useState(null);
    async function load() {
        const actions = await getPendingActions(schoolId, classId);
        setPending(actions);
    }
    useEffect(() => {
        load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [schoolId, classId]);
    if (pending === null) {
        return _jsx("p", { style: { fontSize: 13, color: '#999', padding: 16 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    }
    if (pending.length === 0) {
        return (_jsx("div", { style: { textAlign: 'center', color: '#999', padding: '40px 0', fontSize: 13 }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0627\u0642\u062A\u0631\u0627\u062D\u0627\u062A \u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u062D\u0627\u0644\u064A\u0627\u064B." }));
    }
    return (_jsxs("div", { dir: "rtl", style: { maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12, padding: 16 }, children: [_jsxs("h2", { style: { fontWeight: 600, marginBottom: 4 }, children: ["\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0627\u0642\u062A\u0631\u0627\u062D\u0627\u062A (", pending.length, ")"] }), pending.map((action) => (_jsx(ReviewCard, { schoolId: schoolId, teacherUid: teacherUid, action: action, expanded: expandedId === action.id, onToggle: () => setExpandedId(expandedId === action.id ? null : action.id), onDone: load }, action.id)))] }));
}
function ReviewCard({ schoolId, teacherUid, action, expanded, onToggle, onDone }) {
    const [text, setText] = useState(action.finalText || action.suggestedText);
    const [saving, setSaving] = useState(false);
    const label = TYPE_LABEL[action.type];
    async function handleActivate() {
        setSaving(true);
        try {
            await activateAction(schoolId, {
                actionId: action.id,
                teacherUid,
                finalText: text,
                reviewDate: defaultReviewDate(),
            });
            onDone();
        }
        finally {
            setSaving(false);
        }
    }
    async function handleDefer() {
        setSaving(true);
        try {
            await deferAction(schoolId, { actionId: action.id });
            onDone();
        }
        finally {
            setSaving(false);
        }
    }
    return (_jsxs("div", { style: { border: '1px solid #e5e5e5', borderRadius: 12, padding: 12, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }, children: [_jsxs("div", { children: [_jsxs("p", { style: { fontWeight: 500, fontSize: 13, margin: 0 }, children: [label.icon, " ", action.studentName] }), _jsxs("p", { style: { fontSize: 12, color: '#888', margin: '2px 0 0' }, children: [action.affectedSkillTitles.join('، '), action.deferCount > 0 && (_jsxs("span", { style: { color: '#b8860b' }, children: [" \u00B7 \u0645\u0624\u062C\u064E\u0651\u0644 ", action.deferCount, " \u0645\u0631\u0629"] }))] })] }), _jsx("button", { onClick: onToggle, style: { fontSize: 12, color: '#999', background: 'none', border: 'none', flexShrink: 0 }, children: expanded ? 'إخفاء التعديل' : 'تعديل النص ▾' })] }), expanded ? (_jsx("textarea", { value: text, onChange: (e) => setText(e.target.value), rows: 2, style: { width: '100%', marginTop: 8, border: '1px solid #ccc', borderRadius: 8, padding: 8, fontSize: 13 } })) : (_jsx("p", { style: { fontSize: 13, color: '#333', marginTop: 8, background: '#fafafa', borderRadius: 8, padding: 8 }, children: text })), _jsxs("div", { style: { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }, children: [_jsx("button", { onClick: handleDefer, disabled: saving, style: { padding: '4px 12px', fontSize: 12, color: '#555', border: '1px solid #ccc', background: '#fff', borderRadius: 8 }, children: "\u062A\u0623\u062C\u064A\u0644 \u23ED" }), _jsx("button", { onClick: handleActivate, disabled: saving, style: { padding: '4px 12px', fontSize: 12, color: '#fff', background: '#b8860b', border: 'none', borderRadius: 8 }, children: "\u062A\u0641\u0639\u064A\u0644 \u2713" })] })] }));
}
function defaultReviewDate() {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
}
