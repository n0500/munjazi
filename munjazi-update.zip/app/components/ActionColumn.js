import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { updateActionText, updateActionEnrichmentLink, listActionTemplatesForType, addActionTemplate } from '../lib/actionEngine.js';
const TYPE_LABEL = {
    remedial: { icon: '⚠', text: 'علاجي' },
    enrichment: { icon: '⭐', text: 'إثرائي' },
};
const NEW_TEMPLATE_VALUE = '__new__';
export default function ActionColumn({ schoolId, teacherUid, studentName, actions, onChanged }) {
    const [openAction, setOpenAction] = useState(null);
    if (!actions || actions.length === 0) {
        return _jsx("span", { style: { color: '#ccc' }, children: "\u2014" });
    }
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 4 }, children: [actions.map((action) => {
                const label = TYPE_LABEL[action.type];
                const bg = action.type === 'remedial' ? '#fdf3e2' : '#eaf6ee';
                const border = action.type === 'remedial' ? '#e0b25c' : '#0b7a4b';
                const textColor = action.type === 'remedial' ? '#8a5a00' : '#0b5c33';
                return (_jsxs("button", { onClick: () => setOpenAction(action), style: {
                        fontSize: 12,
                        textAlign: 'right',
                        padding: '4px 8px',
                        borderRadius: 6,
                        background: bg,
                        border: `1px solid ${border}`,
                        color: textColor,
                        cursor: 'pointer',
                    }, children: [_jsx("span", { style: { fontWeight: 'bold' }, children: label.icon }), ' ', action.affectedSkillTitles.join('، '), _jsx("span", { style: { fontSize: 10, opacity: 0.7, marginRight: 4 }, children: "(\u0646\u0634\u0637)" })] }, action.id));
            }), openAction && (_jsx(ActionModal, { schoolId: schoolId, teacherUid: teacherUid, studentName: studentName, action: openAction, onClose: () => setOpenAction(null), onChanged: () => {
                    setOpenAction(null);
                    onChanged?.();
                } }))] }));
}
function ActionModal({ schoolId, teacherUid, studentName, action, onClose, onChanged }) {
    const [text, setText] = useState(action.finalText || action.suggestedText);
    const [enrichmentLink, setEnrichmentLink] = useState(action.enrichmentLink || '');
    const [templates, setTemplates] = useState([]);
    const [saving, setSaving] = useState(false);
    const label = TYPE_LABEL[action.type];
    useEffect(() => {
        listActionTemplatesForType(schoolId, action.type).then(setTemplates);
    }, [schoolId, action.type]);
    async function handleTemplateSelect(value) {
        if (value === NEW_TEMPLATE_VALUE) {
            const newText = window.prompt('يرجى كتابة نص الإجراء الجديد:');
            if (!newText || !newText.trim())
                return;
            try {
                await addActionTemplate(schoolId, { type: action.type, text: newText, teacherUid });
                setText(newText.trim());
                const updated = await listActionTemplatesForType(schoolId, action.type);
                setTemplates(updated);
            }
            catch (err) {
                window.alert(err.message || 'تعذّر إضافة النص.');
            }
            return;
        }
        setText(value);
    }
    async function handleSave() {
        setSaving(true);
        try {
            await updateActionText(schoolId, { actionId: action.id, finalText: text });
            if (action.type === 'enrichment') {
                await updateActionEnrichmentLink(schoolId, { actionId: action.id, enrichmentLink });
            }
            onChanged();
        }
        finally {
            setSaving(false);
        }
    }
    return (_jsx("div", { style: {
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50, padding: 16,
        }, dir: "rtl", children: _jsxs("div", { style: { background: '#fff', borderRadius: 12, boxShadow: '0 10px 30px rgba(0,0,0,0.2)', width: '100%', maxWidth: 420, padding: 20 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }, children: [_jsx("span", { style: { fontSize: 18 }, children: label.icon }), _jsxs("h3", { style: { margin: 0, fontWeight: 600 }, children: ["\u0625\u062C\u0631\u0627\u0621 ", label.text, " \u2014 ", studentName] })] }), _jsxs("p", { style: { fontSize: 12, color: '#777', marginBottom: 16 }, children: ["\u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u062A\u0623\u062B\u0631\u0629: ", action.affectedSkillTitles.join('، ')] }), templates.length > 0 && (_jsxs("select", { value: "", onChange: (e) => handleTemplateSelect(e.target.value), style: { width: '100%', padding: 6, fontSize: 12, marginBottom: 8 }, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0646\u0635 \u062C\u0627\u0647\u0632" }), templates.map((t) => (_jsx("option", { value: t.text, children: t.text }, t.id))), _jsx("option", { value: NEW_TEMPLATE_VALUE, children: "+ \u0625\u0636\u0627\u0641\u0629 \u0646\u0635 \u062C\u062F\u064A\u062F" })] })), templates.length === 0 && (_jsx("button", { onClick: () => handleTemplateSelect(NEW_TEMPLATE_VALUE), style: { fontSize: 12, color: '#0b7a4b', background: 'none', border: 'none', marginBottom: 8, padding: 0 }, children: "+ \u0625\u0636\u0627\u0641\u0629 \u0623\u0648\u0644 \u0646\u0635 \u0644\u0647\u0630\u0627 \u0627\u0644\u0646\u0648\u0639" })), _jsx("label", { style: { display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 4 }, children: "\u0646\u0635 \u0627\u0644\u0625\u062C\u0631\u0627\u0621" }), _jsx("textarea", { value: text, onChange: (e) => setText(e.target.value), rows: 3, style: { width: '100%', border: '1px solid #ccc', borderRadius: 8, padding: 8, fontSize: 13, marginBottom: 16 } }), action.type === 'enrichment' && (_jsxs(_Fragment, { children: [_jsx("label", { style: { display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 4 }, children: "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0625\u062B\u0631\u0627\u0626\u064A \u0627\u0644\u0645\u0631\u062A\u0628\u0637 \u0628\u0647\u0630\u0627 \u0627\u0644\u0625\u062C\u0631\u0627\u0621 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)" }), _jsx("input", { type: "text", value: enrichmentLink, onChange: (e) => setEnrichmentLink(e.target.value), placeholder: "https://...", style: { width: '100%', border: '1px solid #ccc', borderRadius: 8, padding: 8, fontSize: 13, marginBottom: 16, boxSizing: 'border-box' } })] })), _jsxs("div", { style: { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }, children: [_jsx("button", { onClick: onClose, style: { padding: '6px 12px', fontSize: 13, color: '#777', background: 'none', border: 'none', borderRadius: 8 }, children: "\u0625\u063A\u0644\u0627\u0642" }), _jsx("button", { onClick: handleSave, disabled: saving, style: { padding: '6px 12px', fontSize: 13, color: '#fff', background: '#0b7a4b', border: 'none', borderRadius: 8 }, children: saving ? '...' : 'حفظ التعديل' })] })] }) }));
}
