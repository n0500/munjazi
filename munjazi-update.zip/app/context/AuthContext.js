import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../lib/firebase.js';
import { logout as firebaseLogout } from '../lib/auth.js';

const AuthContext = createContext(null);
const PROFILE_CACHE_PREFIX = 'munjazi_profile_cache_v1:';
const STARTUP_TIMEOUT_MS = 7000;

function cacheKey(uid) {
    return `${PROFILE_CACHE_PREFIX}${uid}`;
}
function readCachedProfile(uid) {
    try {
        const raw = sessionStorage.getItem(cacheKey(uid));
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        if (!parsed || parsed.uid !== uid || parsed.disabled) return null;
        return parsed;
    }
    catch {
        return null;
    }
}
function writeCachedProfile(profile) {
    try {
        if (profile?.uid && !profile.disabled)
            sessionStorage.setItem(cacheKey(profile.uid), JSON.stringify(profile));
    }
    catch {}
}
function clearCachedProfile(uid) {
    try {
        if (uid) sessionStorage.removeItem(cacheKey(uid));
    }
    catch {}
}

export function AuthProvider({ children }) {
    const [firebaseUser, setFirebaseUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);
    const [startupError, setStartupError] = useState('');
    const currentUidRef = useRef(null);

    useEffect(() => {
        let disposed = false;
        let unsubProfile = null;
        let startupTimer = setTimeout(() => {
            if (disposed) return;
            setLoading(false);
            setStartupError((current) => current || 'تأخر الاتصال. تحققي من الشبكة ثم أعيدي المحاولة.');
        }, STARTUP_TIMEOUT_MS);

        const unsubAuth = onAuthStateChanged(auth, (user) => {
            if (disposed) return;
            if (unsubProfile) {
                unsubProfile();
                unsubProfile = null;
            }
            currentUidRef.current = user?.uid || null;
            setFirebaseUser(user);
            setStartupError('');

            if (!user) {
                setProfile(null);
                clearTimeout(startupTimer);
                setLoading(false);
                return;
            }

            const cached = readCachedProfile(user.uid);
            if (cached) {
                // افتح الواجهة فورًا بالملف الموثوق من الجلسة الحالية، ثم حدّثه من Firestore بالخلفية.
                setProfile(cached);
                setLoading(false);
            }
            else {
                setLoading(true);
            }

            const userRef = doc(db, 'users', user.uid);
            unsubProfile = onSnapshot(userRef, (snap) => {
                if (disposed || currentUidRef.current !== user.uid) return;
                clearTimeout(startupTimer);
                if (!snap.exists()) {
                    clearCachedProfile(user.uid);
                    setProfile(null);
                    setLoading(false);
                    setStartupError('هذا الحساب غير مفعّل بمنجزي.');
                    return;
                }
                const data = { uid: user.uid, ...snap.data() };
                if (data.disabled) {
                    clearCachedProfile(user.uid);
                    setProfile(null);
                    setLoading(false);
                    firebaseLogout().catch(() => {});
                    return;
                }
                writeCachedProfile(data);
                setProfile(data);
                setStartupError('');
                setLoading(false);
            }, (err) => {
                if (disposed || currentUidRef.current !== user.uid) return;
                clearTimeout(startupTimer);
                // إذا كان لدينا ملف جلسة صالح، لا نعطل الواجهة بسبب انقطاع مؤقت في Firestore.
                if (!readCachedProfile(user.uid)) {
                    setProfile(null);
                    setStartupError(err?.message || 'تعذر الاتصال ببيانات الحساب.');
                }
                setLoading(false);
            });
        }, (err) => {
            if (disposed) return;
            clearTimeout(startupTimer);
            setStartupError(err?.message || 'تعذر التحقق من تسجيل الدخول.');
            setLoading(false);
        });

        return () => {
            disposed = true;
            clearTimeout(startupTimer);
            if (unsubProfile) unsubProfile();
            unsubAuth();
        };
    }, []);

    async function logout() {
        clearCachedProfile(firebaseUser?.uid);
        await firebaseLogout();
    }
    function retryStartup() {
        window.location.reload();
    }
    return (_jsx(AuthContext.Provider, { value: { firebaseUser, profile, loading, startupError, retryStartup, logout }, children: children }));
}

export function useAuth() {
    const ctx = useContext(AuthContext);
    if (!ctx)
        throw new Error('useAuth must be used inside AuthProvider');
    return ctx;
}
