import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { Suspense, lazy } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import Login from './pages/Login.js';
import Logo from './components/Logo.js';
import { colors } from './lib/theme.js';
import ParentDashboard from './pages/ParentDashboard.js';
const OwnerDashboard = lazy(() => import('./pages/OwnerDashboard.js'));
const OwnerBackup = lazy(() => import('./pages/OwnerBackup.js'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard.js'));
const AdminTeacherAccounts = lazy(() => import('./pages/AdminTeacherAccounts.js'));
const TeacherDashboard = lazy(() => import('./pages/TeacherDashboard.js'));
const PdfTestPage = lazy(() => import('./pages/PdfTestPage.js'));
const ScanActions = lazy(() => import('./pages/ScanActions.js'));
class AppLoadBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { error: null };
    }
    static getDerivedStateFromError(error) {
        return { error };
    }
    componentDidCatch(error) {
        const message = String(error?.message || error || '');
        const chunkError = /dynamically imported module|failed to fetch|loading chunk|importing a module/i.test(message);
        if (!chunkError) return;
        try {
            const key = 'munjazi_chunk_reload_once';
            const last = Number(sessionStorage.getItem(key) || 0);
            if (!last || Date.now() - last > 60000) {
                sessionStorage.setItem(key, String(Date.now()));
                window.location.reload();
            }
        }
        catch {}
    }
    render() {
        if (!this.state.error) return this.props.children;
        return _jsxs("div", { dir: "rtl", style: { maxWidth: 420, margin: '90px auto', padding: 22, textAlign: 'center', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 14 }, children: [
            _jsx("h3", { style: { marginTop: 0, color: colors.ink }, children: "تعذر إكمال فتح الصفحة" }),
            _jsx("p", { style: { color: colors.textMuted, lineHeight: 1.8 }, children: "تم تحديث منجزي أثناء فتح الصفحة. اضغطي إعادة التحميل لإكمال الدخول." }),
            _jsx("button", { onClick: () => window.location.reload(), style: { padding: '10px 18px', background: colors.primary, color: '#fff', border: 'none', borderRadius: 8 }, children: "إعادة التحميل" })
        ] });
    }
}
function LoadingFallback() {
    return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
}
function TopBar({ logout, role }) {
    return (_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: `1px solid ${colors.border}`, gap: 10 }, dir: "rtl", children: [_jsx(Logo, { size: "sm" }), _jsxs("div", { style: { display: 'flex', gap: 8, alignItems: 'center' }, children: [_jsxs(_Fragment, { children: [role === 'admin' && (_jsx("button", { onClick: () => { window.location.search = '?teacheraccounts=1'; }, style: { padding: '8px 12px', background: '#f2f2f2', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: 8 }, children: "حسابات المعلمات" }))] }), role === 'owner' && _jsx("button", { onClick: () => { window.location.search = '?ownersettings=1'; }, style: { padding: '8px 12px', background: '#f2f2f2', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: 8 }, children: "إعدادات" }), _jsx("button", { onClick: logout, style: { padding: '8px 16px', background: colors.red, color: '#fff', border: 'none', borderRadius: 8 }, children: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C" })] })] }));
}
function AppInner() {
    const { firebaseUser, profile, loading, startupError, retryStartup, logout } = useAuth();
    const params = new URLSearchParams(window.location.search);
    if (loading)
        return _jsx(LoadingFallback, {});
    if (startupError && firebaseUser && !profile)
        return _jsxs("div", { dir: "rtl", style: { maxWidth: 420, margin: '90px auto', padding: 22, textAlign: 'center', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 14 }, children: [_jsx("h3", { style: { marginTop: 0 }, children: "تعذر إكمال التحميل" }), _jsx("p", { style: { color: colors.textMuted, lineHeight: 1.8 }, children: startupError }), _jsx("button", { onClick: retryStartup, style: { padding: '10px 18px', background: colors.primary, color: '#fff', border: 'none', borderRadius: 8 }, children: "إعادة المحاولة" })] });
    if (!firebaseUser || !profile)
        return _jsx(Login, {});
    if (params.get('scanactions') === '1' && (profile.role === 'admin' || profile.role === 'owner')) {
        return _jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: profile.role }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(ScanActions, { schoolId: profile.schoolId }) })] });
    }
    if (profile.role === 'owner') {
        if (params.get('ownersettings') === '1') {
            return _jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: "owner" }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(OwnerBackup, { onBack: () => { window.location.search = ''; } }) })] });
        }
        return _jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: "owner" }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(OwnerDashboard, {}) })] });
    }
    if (profile.role === 'admin') {
        if (params.get('teacheraccounts') === '1') {
            return (_jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: "admin" }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(AdminTeacherAccounts, { schoolId: profile.schoolId, onBack: () => { window.location.search = ''; } }) })] }));
        }
        return _jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: "admin" }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(AdminDashboard, { schoolId: profile.schoolId }) })] });
    }
    if (profile.role === 'teacher') {
        return (_jsxs("div", { children: [_jsx(TopBar, { logout: logout, role: "teacher" }), _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(TeacherDashboard, { schoolId: profile.schoolId, teacherUid: firebaseUser.uid, teacherName: profile.displayName }) })] }));
    }
    return _jsx("div", { children: _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(ParentDashboard, { schoolId: profile.schoolId, profile: profile, logout: logout }) }) });
}
export default function App() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('pdftest') === '1')
        return _jsx(AppLoadBoundary, { children: _jsx(Suspense, { fallback: _jsx(LoadingFallback, {}), children: _jsx(PdfTestPage, {}) }) });
    return _jsx(AppLoadBoundary, { children: _jsx(AuthProvider, { children: _jsx(AppInner, {}) }) });
}
