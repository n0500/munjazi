import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { listSchoolTeachers, setTeacherDisabled } from '../lib/teachersApi.js';
import { listTeacherAssignments, listClasses } from '../lib/classesApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
export default function AdminTeacherAccounts({ schoolId, onBack }) {
    const [teachers, setTeachers] = useState([]);
    const [assignmentDetails, setAssignmentDetails] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [busyUid, setBusyUid] = useState(null);
    const [searchText, setSearchText] = useState('');

    function normalizeName(value) {
        return String(value || '')
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[أإآ]/g, 'ا')
            .replace(/ى/g, 'ي')
            .replace(/ة/g, 'ه')
            .toLowerCase();
    }

    function shortUid(uid) {
        const value = String(uid || '');
        if (!value) return '—';
        return value.length <= 10 ? value : `${value.slice(0, 5)}…${value.slice(-4)}`;
    }

    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const [rows, classes] = await Promise.all([
                listSchoolTeachers(schoolId, { includeDisabled: true }),
                listClasses(schoolId),
            ]);

            const classNameById = Object.fromEntries(
                classes.map((c) => [c.id, c.name || 'فصل غير محدد'])
            );

            const details = await Promise.all(rows.map(async (t) => {
                const assignments = await listTeacherAssignments(
                    schoolId,
                    t.uid,
                    { includeInactive: true }
                );

                const active = assignments
                    .filter((a) => a.active !== false && a.teacherDisabled !== true)
                    .map((a) => ({
                        id: a.id,
                        subject: a.subject || 'مادة غير محددة',
                        className: classNameById[a.classId] || 'فصل غير محدد',
                    }));

                return [t.uid, {
                    activeCount: active.length,
                    activeAssignments: active,
                }];
            }));

            setAssignmentDetails(Object.fromEntries(details));
            setTeachers(rows.sort((a, b) =>
                (a.displayName || '').localeCompare(b.displayName || '', 'ar')
            ));
        }
        catch (err) {
            setError(err.message || 'تعذر تحميل حسابات المعلمات.');
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [schoolId]);

    async function handleToggle(teacher) {
        const disabling = !teacher.disabled;
        const actionLabel = disabling ? 'تعطيل' : 'إعادة تفعيل';
        const detail = assignmentDetails[teacher.uid] || { activeCount: 0, activeAssignments: [] };
        const accountLabel = teacher.email || `معرّف الحساب ${shortUid(teacher.uid)}`;
        const assignmentsText = detail.activeAssignments.length
            ? detail.activeAssignments.map((a) => `${a.className} — ${a.subject}`).join('\n')
            : 'لا توجد إسنادات نشطة.';

        if (!window.confirm(
            `${actionLabel} حساب "${teacher.displayName}"؟\n` +
            `${accountLabel}\n\n` +
            `الإسنادات النشطة (${detail.activeCount}):\n${assignmentsText}\n\n` +
            (disabling
                ? 'سيتم إنهاء وصولها للمنصة وإخفاء إسناداتها عن لوحة ولي الأمر، مع بقاء الرصد والبيانات محفوظة.'
                : 'ستعود الإسنادات النشطة للظهور ويمكنها تسجيل الدخول مجددًا.')
        )) return;

        setBusyUid(teacher.uid);
        setError('');
        try {
            await setTeacherDisabled(schoolId, teacher.uid, disabling);
            await refresh();
        }
        catch (err) {
            setError(err.message || `تعذر ${actionLabel} الحساب.`);
        }
        finally {
            setBusyUid(null);
        }
    }

    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...جارٍ التحميل" });

    const activeCount = teachers.filter((t) => !t.disabled).length;
    const disabledCount = teachers.length - activeCount;

    const nameCounts = teachers.reduce((acc, teacher) => {
        const key = normalizeName(teacher.displayName || 'معلّمة');
        acc[key] = (acc[key] || 0) + 1;
        return acc;
    }, {});

    const q = searchText.trim().toLowerCase();
    const visibleTeachers = teachers.filter((t) => {
        if (!q) return true;
        const details = assignmentDetails[t.uid]?.activeAssignments || [];
        const haystack = [
            t.displayName || '',
            t.email || '',
            t.uid || '',
            ...details.flatMap((a) => [a.subject || '', a.className || '']),
        ].join(' ').toLowerCase();
        return haystack.includes(q);
    });

    return (_jsxs("div", {
        style: { maxWidth: 820, margin: '20px auto', padding: spacing.lg },
        dir: "rtl",
        children: [
            _jsx("button", {
                onClick: onBack,
                style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm },
                children: "← العودة إلى لوحة الإدارة"
            }),
            _jsx("h1", {
                style: { fontFamily: font.family, color: colors.ink, marginBottom: 4 },
                children: "حسابات المعلمات"
            }),
            _jsxs("p", {
                style: { color: colors.textMuted, fontSize: 13, marginTop: 0 },
                children: ["نشطة: ", activeCount, " · معطلة: ", disabledCount]
            }),

            _jsx("input", {
                type: "search",
                value: searchText,
                onChange: (e) => setSearchText(e.target.value),
                placeholder: "بحث بالاسم أو البريد أو المادة أو الفصل",
                style: {
                    width: '100%',
                    boxSizing: 'border-box',
                    padding: '11px 12px',
                    border: `1px solid ${colors.border}`,
                    borderRadius: radius.button,
                    marginBottom: spacing.md,
                    fontSize: 14,
                }
            }),

            _jsx("div", {
                style: {
                    background: colors.primaryTint,
                    color: colors.ink,
                    borderRadius: radius.button,
                    padding: '10px 12px',
                    fontSize: 12,
                    marginBottom: spacing.md,
                    lineHeight: 1.8,
                },
                children: "البريد يظهر مباشرة للحسابات الجديدة. الحساب القديم الذي لا يظهر بريده سيُحفظ بريده تلقائيًا عند أول تسجيل دخول للمعلمة بعد هذا التحديث."
            }),

            error && _jsx("div", {
                style: {
                    background: colors.redTint,
                    color: colors.red,
                    padding: 10,
                    borderRadius: radius.button,
                    marginBottom: spacing.md
                },
                children: error
            }),

            visibleTeachers.length === 0
                ? _jsx("p", { style: { color: colors.textMuted }, children: "لا توجد حسابات مطابقة." })
                : visibleTeachers.map((t) => {
                    const details = assignmentDetails[t.uid] || {
                        activeCount: 0,
                        activeAssignments: []
                    };
                    const duplicateCount = nameCounts[normalizeName(t.displayName || 'معلّمة')] || 1;

                    return _jsxs("div", {
                        style: {
                            border: `1px solid ${duplicateCount > 1 ? '#d7a436' : colors.border}`,
                            borderRadius: radius.card,
                            padding: spacing.md,
                            marginBottom: 12,
                            background: t.disabled ? '#fafafa' : '#fff'
                        },
                        children: [
                            _jsxs("div", {
                                style: {
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'flex-start',
                                    gap: 12,
                                    flexWrap: 'wrap'
                                },
                                children: [
                                    _jsxs("div", {
                                        style: { flex: '1 1 320px', minWidth: 0 },
                                        children: [
                                            _jsxs("div", {
                                                style: { display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' },
                                                children: [
                                                    _jsx("strong", {
                                                        style: { fontSize: 16, color: colors.ink },
                                                        children: t.displayName || 'معلّمة'
                                                    }),
                                                    duplicateCount > 1 && _jsxs("span", {
                                                        style: {
                                                            fontSize: 11,
                                                            background: '#fff6dd',
                                                            color: '#8a5c00',
                                                            border: '1px solid #e5c46e',
                                                            borderRadius: 999,
                                                            padding: '2px 8px'
                                                        },
                                                        children: ["اسم مكرر ×", duplicateCount]
                                                    })
                                                ]
                                            }),

                                            _jsx("div", {
                                                style: {
                                                    direction: 'ltr',
                                                    textAlign: 'right',
                                                    fontSize: 14,
                                                    marginTop: 6,
                                                    color: t.email ? colors.ink : colors.red,
                                                    fontWeight: t.email ? 600 : 400,
                                                    overflowWrap: 'anywhere'
                                                },
                                                children: t.email || 'البريد غير محفوظ بعد'
                                            }),

                                            !t.email && _jsxs("div", {
                                                style: { fontSize: 11, color: colors.textMuted, marginTop: 3 },
                                                children: ["معرّف الحساب: ", shortUid(t.uid)]
                                            }),

                                            _jsx("div", {
                                                style: {
                                                    fontSize: 12,
                                                    color: t.disabled ? colors.red : '#0b5c33',
                                                    marginTop: 5,
                                                    fontWeight: 600
                                                },
                                                children: t.disabled ? 'معطل' : 'نشط'
                                            })
                                        ]
                                    }),

                                    _jsx("button", {
                                        onClick: () => handleToggle(t),
                                        disabled: busyUid === t.uid,
                                        style: {
                                            padding: '8px 13px',
                                            background: t.disabled ? colors.primary : colors.red,
                                            color: '#fff',
                                            border: 'none',
                                            borderRadius: radius.button
                                        },
                                        children: busyUid === t.uid ? '...' : t.disabled ? 'إعادة التفعيل' : 'تعطيل الحساب'
                                    })
                                ]
                            }),

                            _jsxs("div", {
                                style: {
                                    marginTop: 10,
                                    paddingTop: 9,
                                    borderTop: `1px solid ${colors.border}`,
                                    fontSize: 12,
                                    color: colors.textMuted
                                },
                                children: [
                                    _jsxs("div", {
                                        style: { marginBottom: 5 },
                                        children: ["الإسنادات النشطة: ", details.activeCount]
                                    }),
                                    details.activeAssignments.length > 0
                                        ? _jsx("div", {
                                            style: { display: 'flex', gap: 6, flexWrap: 'wrap' },
                                            children: details.activeAssignments.map((a) =>
                                                _jsxs("span", {
                                                    style: {
                                                        background: '#f6f7f7',
                                                        color: colors.ink,
                                                        border: `1px solid ${colors.border}`,
                                                        borderRadius: 999,
                                                        padding: '3px 8px'
                                                    },
                                                    children: [a.className, " — ", a.subject]
                                                }, a.id)
                                            )
                                        })
                                        : _jsx("span", { children: "لا توجد إسنادات نشطة" })
                                ]
                            })
                        ]
                    }, t.uid);
                })
        ]
    }));
}
