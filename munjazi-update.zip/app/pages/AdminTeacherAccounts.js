import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { listSchoolTeachers, setTeacherDisabled } from '../lib/teachersApi.js';
import { listTeacherAssignments } from '../lib/classesApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
export default function AdminTeacherAccounts({ schoolId, onBack }) {
    const [teachers, setTeachers] = useState([]);
    const [assignmentCounts, setAssignmentCounts] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [busyUid, setBusyUid] = useState(null);
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const rows = await listSchoolTeachers(schoolId, { includeDisabled: true });
            setTeachers(rows.sort((a, b) => (a.displayName || '').localeCompare(b.displayName || '', 'ar')));
            const counts = await Promise.all(rows.map(async (t) => {
                const assignments = await listTeacherAssignments(schoolId, t.uid, { includeInactive: true });
                return [t.uid, assignments.filter((a) => a.active !== false).length];
            }));
            setAssignmentCounts(Object.fromEntries(counts));
        }
        catch (err) {
            setError(err.message || 'تعذر تحميل حسابات المعلمات.');
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [schoolId]);
    async function handleToggle(teacher) {
        const disabling = !teacher.disabled;
        const actionLabel = disabling ? 'تعطيل' : 'إعادة تفعيل';
        if (!window.confirm(`${actionLabel} حساب "${teacher.displayName}"؟ ${disabling ? 'سيتم إنهاء وصولها للمنصة وإخفاء إسناداتها عن لوحة ولي الأمر، مع بقاء الرصد والبيانات محفوظة.' : 'ستعود الإسنادات النشطة للظهور ويمكنها تسجيل الدخول مجددًا.'}`))
            return;
        setBusyUid(teacher.uid);
        setError('');
        try {
            await setTeacherDisabled(schoolId, teacher.uid, disabling);
            await refresh();
        }
        catch (err) {
            setError(err.message || `تعذر ${actionLabel} الحساب.`);
        }
        finally {
            setBusyUid(null);
        }
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    const activeCount = teachers.filter((t) => !t.disabled).length;
    const disabledCount = teachers.length - activeCount;
    return (_jsxs("div", { style: { maxWidth: 720, margin: '20px auto', padding: spacing.lg }, dir: "rtl", children: [_jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0644\u0648\u062D\u0629 \u0627\u0644\u0625\u062F\u0627\u0631\u0629" }), _jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0645\u0627\u062A" }), _jsxs("p", { style: { color: colors.textMuted, fontSize: 13 }, children: ["\u0646\u0634\u0637\u0629: ", activeCount, " \u00B7 \u0645\u0639\u0637\u0644\u0629: ", disabledCount] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), teachers.length === 0 ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0633\u0627\u0628\u0627\u062A \u0645\u0639\u0644\u0645\u0627\u062A." }) : teachers.map((t) => (_jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap' }, children: [_jsxs("div", { children: [_jsx("strong", { children: t.displayName || 'معلّمة' }), _jsxs("div", { style: { fontSize: 12, color: colors.textMuted }, children: [t.email || 'البريد غير محفوظ في الحسابات القديمة', " \u00B7 ", assignmentCounts[t.uid] || 0, " \u0625\u0633\u0646\u0627\u062F \u0646\u0634\u0637"] }), _jsx("div", { style: { fontSize: 12, color: t.disabled ? colors.red : '#0b5c33' }, children: t.disabled ? 'معطل' : 'نشط' })] }), _jsx("button", { onClick: () => handleToggle(t), disabled: busyUid === t.uid, style: { padding: '7px 12px', background: t.disabled ? colors.primary : colors.red, color: '#fff', border: 'none', borderRadius: radius.button }, children: busyUid === t.uid ? '...' : t.disabled ? 'إعادة التفعيل' : 'تعطيل الحساب' })] }, t.uid)))] }));
}
