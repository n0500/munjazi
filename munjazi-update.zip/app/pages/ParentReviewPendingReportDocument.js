import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';

Font.register({
    family: 'Plex',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf',
});
Font.register({
    family: 'Plex-Bold',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf',
});
Font.registerHyphenationCallback((word) => [word]);

const HEADER_BG = '#14261e';
const HEADER_DIVIDER = '#3a4a42';
const ROW_BORDER = '#e0e0e0';
const COL_BORDER = '#cfcfcf';

const styles = StyleSheet.create({
    page: {
        fontFamily: 'Plex',
        paddingTop: 150,
        paddingBottom: 40,
        paddingHorizontal: 24,
        fontSize: 8.5,
    },
    fixedHeaderBlock: {
        position: 'absolute',
        top: 14,
        left: 24,
        right: 24,
    },
    reportLogo: { position: 'absolute', top: 0, right: 0, width: 72, height: 33, objectFit: 'contain' },
    schoolName: {
        fontFamily: 'Plex-Bold',
        fontSize: 15,
        color: '#14261e',
        textAlign: 'center',
        lineHeight: 1.3,
    },
    reportTitle: {
        fontFamily: 'Plex-Bold',
        fontSize: 14,
        color: '#0b7a4b',
        textAlign: 'center',
        marginTop: 8,
        lineHeight: 1.3,
    },
    metaLine: {
        fontSize: 8.5,
        color: '#555',
        textAlign: 'center',
        marginTop: 4,
        lineHeight: 1.3,
    },
    countLine: {
        fontFamily: 'Plex-Bold',
        fontSize: 9,
        color: '#a10000',
        textAlign: 'center',
        marginTop: 7,
        marginBottom: 8,
    },
    tableHeaderRow: {
        flexDirection: 'row-reverse',
        backgroundColor: HEADER_BG,
        borderWidth: 1,
        borderColor: HEADER_BG,
        paddingVertical: 6,
    },
    headerCell: {
        fontFamily: 'Plex-Bold',
        fontSize: 8.2,
        textAlign: 'center',
        color: '#fff',
        borderLeftWidth: 0.75,
        borderLeftColor: HEADER_DIVIDER,
        paddingHorizontal: 3,
        lineHeight: 1.35,
    },
    headerCellFirst: {
        textAlign: 'right',
        paddingRight: 6,
    },
    row: {
        flexDirection: 'row-reverse',
        minHeight: 27,
        alignItems: 'center',
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderBottomWidth: 0.75,
        borderColor: ROW_BORDER,
    },
    rowEven: { backgroundColor: '#fafafa' },
    cell: {
        fontSize: 8,
        textAlign: 'right',
        paddingHorizontal: 5,
        paddingVertical: 5,
        borderLeftWidth: 0.75,
        borderLeftColor: COL_BORDER,
        lineHeight: 1.35,
    },
    statusText: {
        fontFamily: 'Plex-Bold',
        color: '#a10000',
        textAlign: 'center',
    },
    footer: {
        position: 'absolute',
        bottom: 14,
        left: 24,
        right: 24,
        flexDirection: 'row-reverse',
        fontSize: 8,
        color: '#333',
        borderTop: 0.5,
        borderTopColor: '#ccc',
        paddingTop: 6,
    },
    footerRight: { flex: 1, textAlign: 'right' },
    footerLeft: { flex: 1, textAlign: 'left' },
});

const COL = {
    student: 14,
    teacher: 14,
    subjectClass: 18,
    week: 12,
    status: 13,
    skills: 22,
    review: 7,
};

function weaknessSummary(row) {
    const parts = [];
    if (row.notMasteredCount > 0)
        parts.push(`${row.notMasteredCount} غير متقنة`);
    if (row.needsSupportCount > 0)
        parts.push(`${row.needsSupportCount} تحتاج متابعة`);
    return parts.join(' — ') || '—';
}

function skillsSummary(row) {
    return (row.weakSkills || []).map((skill) => {
        const label = skill.status === 'notMastered' ? 'غير متقنة' : 'تحتاج متابعة';
        return `${skill.title} (${label})`;
    }).join('، ');
}

export default function ParentReviewPendingReportDocument({ rows, schoolName, generatedDate }) {
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", orientation: "landscape", style: styles.page, children: [
        _jsxs(View, { style: styles.fixedHeaderBlock, fixed: true, children: [
            _jsx(ReportLogo, { style: styles.reportLogo }),
            _jsx(Text, { style: styles.schoolName, children: schoolName || 'المدرسة' }),
            _jsx(Text, { style: styles.reportTitle, children: "تقرير متابعة أولياء الأمور الذين لم يطلعوا على الرصد" }),
            _jsxs(Text, { style: styles.metaLine, children: ["تاريخ التقرير: ", generatedDate] }),
            _jsx(Text, { style: styles.metaLine, children: "يشمل فقط الطالبات اللاتي لديهن مهارات غير متقنة أو تحتاج متابعة ولم يطلع ولي الأمر على آخر رصد." }),
            _jsxs(Text, { style: styles.countLine, children: ["عدد الحالات التي تحتاج متابعة: ", rows.length] }),
            _jsxs(View, { style: styles.tableHeaderRow, children: [
                _jsx(Text, { style: [styles.headerCell, styles.headerCellFirst, { width: `${COL.student}%` }], children: "الطالبة" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.teacher}%` }], children: "المعلمة" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.subjectClass}%` }], children: "المادة / الفصل" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.week}%` }], children: "الأسبوع / النوع" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.status}%` }], children: "الحالة" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.skills}%` }], children: "المهارات" }),
                _jsx(Text, { style: [styles.headerCell, { width: `${COL.review}%` }], children: "الاطلاع" }),
            ] })
        ] }),
        rows.map((row, i) => (_jsxs(View, { style: [styles.row, i % 2 === 1 && styles.rowEven], wrap: false, children: [
            _jsx(Text, { style: [styles.cell, { width: `${COL.student}%`, fontFamily: 'Plex-Bold' }], children: row.studentName }),
            _jsx(Text, { style: [styles.cell, { width: `${COL.teacher}%` }], children: row.teacherName }),
            _jsxs(Text, { style: [styles.cell, { width: `${COL.subjectClass}%` }], children: [row.subject, " — ", row.className] }),
            _jsxs(Text, { style: [styles.cell, { width: `${COL.week}%`, textAlign: 'center' }], children: [row.weekName, " — ", row.weekTypeLabel] }),
            _jsx(Text, { style: [styles.cell, { width: `${COL.status}%`, textAlign: 'center' }], children: weaknessSummary(row) }),
            _jsx(Text, { style: [styles.cell, { width: `${COL.skills}%` }], children: skillsSummary(row) }),
            _jsx(Text, { style: [styles.cell, styles.statusText, { width: `${COL.review}%` }], children: "لم يطلع" }),
        ] }, `${row.weekId}_${row.studentId}`))),
        _jsxs(View, { style: styles.footer, fixed: true, children: [
            _jsx(Text, { style: styles.footerRight, children: "متابعة الإدارة — منجزي" }),
            _jsx(Text, { style: styles.footerLeft, render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` }),
        ] })
    ] }) }));
}
