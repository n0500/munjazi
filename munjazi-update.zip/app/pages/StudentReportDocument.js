import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font, Link } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';
Font.register({
    family: 'Plex',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf',
});
Font.register({
    family: 'Plex-Bold',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf',
});
Font.registerHyphenationCallback((word) => [word]);
const STATUS_STYLE = {
    mastered: { bg: '#eaf6ee', text: '#0b5c33', border: '#0b7a4b' },
    needsSupport: { bg: '#fff7e0', text: '#8a6d00', border: '#d9b400' },
    notMastered: { bg: '#fdecea', text: '#a10000', border: '#c62828' },
    absent: { bg: '#f2f2f2', text: '#666', border: '#ccc' },
};
const HEADER_BG = '#14261e';
const HEADER_DIVIDER = '#3a4a42';
const ROW_BORDER = '#e0e0e0';
const COL_BORDER = '#cfcfcf';
const styles = StyleSheet.create({
    page: { fontFamily: 'Plex', paddingTop: 150, paddingBottom: 40, paddingHorizontal: 26, fontSize: 9 },
    fixedHeaderBlock: { position: 'absolute', top: 14, left: 26, right: 26 },
    reportLogo: { position: 'absolute', top: 0, right: 0, width: 65, height: 30, objectFit: 'contain' },
    schoolName: { fontFamily: 'Plex-Bold', fontSize: 14, color: '#14261e', textAlign: 'center', lineHeight: 1.3 },
    headerLine: { fontSize: 9, color: '#555', textAlign: 'center', marginTop: 3, lineHeight: 1.3 },
    reportTitle: { fontFamily: 'Plex-Bold', fontSize: 13, color: '#0b7a4b', textAlign: 'center', marginTop: 8, marginBottom: 4 },
    studentLine: { fontSize: 10, textAlign: 'center', marginTop: 2 },
    studentLineBold: { fontFamily: 'Plex-Bold' },
    actionBox: {
        borderWidth: 1, borderRadius: 6, padding: 8, marginBottom: 8,
    },
    actionRemedial: { backgroundColor: '#fdf3e2', borderColor: '#e0b25c' },
    actionEnrichment: { backgroundColor: '#eaf6ee', borderColor: '#0b7a4b' },
    actionTitle: { fontFamily: 'Plex-Bold', fontSize: 9, marginBottom: 2 },
    actionText: { fontSize: 8 },
    statsRow: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 10, fontSize: 8, color: '#333' },
    weekBlock: { borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 10, marginBottom: 10 },
    weekTitle: { fontFamily: 'Plex-Bold', fontSize: 11, marginBottom: 4, textAlign: 'right' },
    weekLink: { fontSize: 8, color: '#0b7a4b', textDecoration: 'underline', marginBottom: 6 },
    tableHeaderRow: { flexDirection: 'row-reverse', backgroundColor: HEADER_BG, paddingVertical: 4 },
    tableHeaderCell: { fontFamily: 'Plex-Bold', fontSize: 8.5, color: '#fff', textAlign: 'center', borderLeftWidth: 0.5, borderLeftColor: HEADER_DIVIDER },
    tableHeaderCellFirst: { textAlign: 'right', paddingRight: 6 },
    englishSkill: { direction: 'ltr', textAlign: 'center' },
    skillRow: { flexDirection: 'row-reverse', minHeight: 18, alignItems: 'center', borderBottomWidth: 0.5, borderBottomColor: ROW_BORDER },
    skillCell: { fontSize: 8.5, paddingHorizontal: 4, paddingVertical: 3, borderLeftWidth: 0.5, borderLeftColor: COL_BORDER },
    badge: { paddingHorizontal: 5, paddingVertical: 2, borderRadius: 4, borderWidth: 1, alignSelf: 'center', minWidth: 40, alignItems: 'center' },
    badgeText: { fontSize: 8, fontFamily: 'Plex-Bold' },
    recLine: { fontSize: 8.5, marginTop: 5 },
    footer: {
        position: 'absolute', bottom: 14, left: 26, right: 26,
        flexDirection: 'row-reverse', fontSize: 8, color: '#333',
        borderTop: 0.5, borderTopColor: '#ccc', paddingTop: 6,
    },
    footerColRight: { flex: 1, textAlign: 'right' },
    footerColCenter: { flex: 1, textAlign: 'center' },
    footerColLeft: { flex: 1, textAlign: 'left' },
});
function StatusBadge({ status, statusLabel }) {
    const s = STATUS_STYLE[status] || { bg: '#f2f2f2', text: '#666', border: '#ccc' };
    return (_jsx(View, { style: [styles.badge, { backgroundColor: s.bg, borderColor: s.border }], children: _jsx(Text, { style: [styles.badgeText, { color: s.text }], children: statusLabel }) }));
}
export default function StudentReportDocument({ data }) {
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", style: styles.page, children: [_jsxs(View, { style: styles.fixedHeaderBlock, fixed: true, children: [_jsx(ReportLogo, { style: styles.reportLogo }), _jsx(Text, { style: styles.schoolName, children: data.schoolName }), _jsxs(Text, { style: styles.headerLine, children: ["\u0627\u0644\u0645\u0627\u062F\u0629: ", data.subject || 'غير محددة'] }), _jsxs(Text, { style: styles.headerLine, children: ["\u0645\u0646 ", data.fromWeekName, " \u0625\u0644\u0649 ", data.toWeekName] }), _jsx(Text, { style: styles.reportTitle, children: "\u062A\u0642\u0631\u064A\u0631 \u0637\u0627\u0644\u0628\u0629" }), _jsxs(Text, { style: styles.studentLine, children: [_jsx(Text, { style: styles.studentLineBold, children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629: " }), data.studentName] }), _jsxs(Text, { style: styles.studentLine, children: [_jsx(Text, { style: styles.studentLineBold, children: "\u0627\u0644\u0641\u0635\u0644: " }), data.className] })] }), data.activeActions && data.activeActions.length > 0 && (_jsx(View, { wrap: false, children: data.activeActions.map((a, i) => (_jsxs(View, { style: [styles.actionBox, a.type === 'remedial' ? styles.actionRemedial : styles.actionEnrichment], children: [_jsxs(Text, { style: [styles.actionTitle, { color: a.type === 'remedial' ? '#8a5a00' : '#0b5c33' }], children: [a.type === 'remedial' ? '⚠ إجراء علاجي' : '⭐ إجراء إثرائي', " \u2014 ", a.affectedSkillTitles.join('، ')] }), _jsx(Text, { style: styles.actionText, children: a.text })] }, i))) })), _jsxs(View, { style: styles.statsRow, wrap: false, children: [_jsxs(Text, { children: ["\u0645\u062A\u0642\u0646\u0629: ", data.statusCounts.mastered] }), _jsxs(Text, { children: ["\u062A\u062D\u062A\u0627\u062C \u062F\u0639\u0645: ", data.statusCounts.needsSupport] }), _jsxs(Text, { children: ["\u063A\u064A\u0631 \u0645\u062A\u0642\u0646\u0629: ", data.statusCounts.notMastered] }), _jsxs(Text, { children: ["\u063A\u0627\u0626\u0628\u0629: ", data.statusCounts.absent] })] }), data.weeks.map((w) => (_jsxs(View, { style: styles.weekBlock, wrap: false, children: [_jsxs(Text, { style: styles.weekTitle, children: [w.name, " \u2014 ", w.typeLabel] }), w.enrichmentLink && (_jsx(Text, { style: styles.weekLink, children: _jsx(Link, { src: w.enrichmentLink, style: styles.weekLink, children: "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0625\u062B\u0631\u0627\u0626\u064A" }) })), _jsxs(View, { style: styles.tableHeaderRow, children: [_jsx(Text, { style: [styles.tableHeaderCell, styles.tableHeaderCellFirst, { width: '65%' }], children: "\u0627\u0644\u0645\u0647\u0627\u0631\u0629" }), _jsx(Text, { style: [styles.tableHeaderCell, { width: '35%' }], children: "\u0627\u0644\u062D\u0627\u0644\u0629" })] }), w.skills.map((sk, i) => (_jsxs(View, { style: styles.skillRow, children: [_jsx(Text, { style: [styles.skillCell, styles.englishSkill, { width: '65%' }], children: sk.title }), _jsx(View, { style: [styles.skillCell, { width: '35%' }], children: _jsx(StatusBadge, { status: sk.status, statusLabel: sk.statusLabel }) })] }, i))), w.recommendation && (_jsxs(Text, { style: styles.recLine, children: [_jsx(Text, { style: styles.studentLineBold, children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0629: " }), w.recommendation] }))] }, w.id))), _jsxs(View, { style: styles.footer, fixed: true, children: [_jsxs(Text, { style: styles.footerColRight, children: ["\u0645\u062F\u064A\u0631\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629: ", data.principalName || '—'] }), _jsxs(Text, { style: styles.footerColCenter, children: ["\u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629: ", data.teacherName] }), _jsx(Text, { style: styles.footerColLeft, render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` })] })] }) }));
}
