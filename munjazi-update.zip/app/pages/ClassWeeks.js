import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect, useState } from 'react';
import { listWeeksForAssignmentGroup, createWeek, copyWeekToMultipleAssignments, deleteWeekWithData } from '../lib/weeksApi.js';
import { SCHOOL_WEEK_NAMES } from '../lib/schoolWeekNames.js';
import { normalizeSubject, normalizeWeekName } from '../lib/dataLogic.js';
import WeekDetail from './WeekDetail.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const TYPE_LABELS = { measurement: 'قياس', remediation: 'معالجة' };
export default function ClassWeeks({ schoolId, assignment, allAssignments, historicalAssignments = allAssignments, classNameFor, onBack = null }) {
    const { classId, teacherUid } = assignment;
    const [weeks, setWeeks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [name, setName] = useState('');
    const [type, setType] = useState('measurement');
    const [opening, setOpening] = useState(false);
    const [selectedWeekId, setSelectedWeekId] = useState(null);
    const [showCopy, setShowCopy] = useState(false);
    const [copySourceId, setCopySourceId] = useState('');
    const [copyName, setCopyName] = useState('');
    const [copyType, setCopyType] = useState('remediation');
    const [copyTargetIds, setCopyTargetIds] = useState(new Set([assignment.id]));
    const [copying, setCopying] = useState(false);
    const [copyResults, setCopyResults] = useState(null);
    const [deletingId, setDeletingId] = useState(null);
    const sameSubjectAssignments = allAssignments
        .filter((a) => a.teacherUid === teacherUid && normalizeSubject(a.subject) === normalizeSubject(assignment.subject))
        .sort((a, b) => (a.id === assignment.id ? -1 : b.id === assignment.id ? 1 : classNameFor(a.classId).localeCompare(classNameFor(b.classId), 'ar')));
    async function refresh() { setLoading(true); setError(''); try {
        setWeeks(await listWeeksForAssignmentGroup(schoolId, assignment));
    }
    catch (err) {
        setError(err.message || 'تعذّر تحميل الأسابيع الدراسية.');
    }
    finally {
        setLoading(false);
    } }
    useEffect(() => { setSelectedWeekId(null); setName(''); setType('measurement'); setCopyTargetIds(new Set([assignment.id])); refresh(); }, [assignment.id]);
    async function handleOpenOrCreate(e) { e.preventDefault(); if (!name || opening)
        return; setOpening(true); setError(''); try {
        const existing = weeks.find(w => normalizeWeekName(w.name) === normalizeWeekName(name) && w.type === type && w.archived !== true);
        if (existing) {
            setSelectedWeekId(existing.id);
        }
        else {
            const created = await createWeek(schoolId, { classId, teacherUid, assignmentId: assignment.id, subject: assignment.subject, name, type, enrichmentLink: '' });
            await refresh();
            setSelectedWeekId(created.id);
        }
    }
    catch (err) {
        setError(err.message || 'تعذّر فتح الأسبوع.');
    }
    finally {
        setOpening(false);
    } }
    function toggleCopyTarget(id) { setCopyTargetIds(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; }); }
    async function handleCopy(e) { e.preventDefault(); if (!copySourceId || !copyName || !copyTargetIds.size || copying)
        return; setCopying(true); setError(''); setCopyResults(null); try {
        const results = await copyWeekToMultipleAssignments(schoolId, { sourceAssignmentId: assignment.id, sourceWeekId: copySourceId, targetAssignmentIds: [...copyTargetIds], targetName: copyName, targetType: copyType, copyAssessments: true, copyComments: true });
        setCopyResults(results);
        await refresh();
        const current = results.find((r) => r.assignmentId === assignment.id && r.ok);
        if (current?.id)
            setSelectedWeekId(current.id);
    }
    catch (err) {
        setError(err.message || 'تعذّر نسخ الأسبوع.');
    }
    finally {
        setCopying(false);
    } }
    async function handleDelete(week) {
        const msg = `سيتم حذف "${week.name}" نهائيًا مع المهارات والرصد والتوصيات والخطط العلاجية والمتابعات المرتبطة بهذا الأسبوع. لن يمكن استعادته بعد الحذف. هل تريدين الحذف؟`;
        if (!window.confirm(msg))
            return;
        setDeletingId(week.id);
        setError('');
        try {
            await deleteWeekWithData(schoolId, week.id);
            if (copySourceId === week.id)
                setCopySourceId('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر حذف الأسبوع.');
        }
        finally {
            setDeletingId(null);
        }
    }
    if (selectedWeekId) {
        const week = weeks.find(w => w.id === selectedWeekId);
        if (week)
            return _jsx(WeekDetail, { schoolId: schoolId, assignment: assignment, allAssignments: allAssignments, historicalAssignments: historicalAssignments, classNameFor: classNameFor, week: week, onBack: () => { setSelectedWeekId(null); refresh(); } });
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 50 }, children: "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644..." });
    return _jsxs("div", { style: { width: '100%', maxWidth: '100%', margin: '0 auto', boxSizing: 'border-box' }, dir: "rtl", children: [onBack && _jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: 8 }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629" }), _jsx("h2", { style: { fontFamily: font.family, color: colors.ink, marginBottom: 4 }, children: "\u0627\u0644\u0631\u0635\u062F" }), _jsxs("p", { style: { color: colors.textMuted, marginTop: 0 }, children: [assignment.subject, " \u2014 ", classNameFor(classId)] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), _jsx("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.md }, children: _jsxs("form", { onSubmit: handleOpenOrCreate, children: [_jsxs("div", { style: { display: 'grid', gridTemplateColumns: '1fr 150px', gap: 8 }, children: [_jsxs("select", { value: name, onChange: e => setName(e.target.value), required: true, style: { padding: 10 }, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u0627\u0631\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639" }), SCHOOL_WEEK_NAMES.map((n) => _jsx("option", { value: n, children: n }, n))] }), _jsxs("select", { value: type, onChange: e => setType(e.target.value), required: true, style: { padding: 10, fontWeight: 'bold' }, children: [_jsx("option", { value: "measurement", children: "\u0642\u064A\u0627\u0633" }), _jsx("option", { value: "remediation", children: "\u0645\u0639\u0627\u0644\u062C\u0629" })] })] }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }, children: [_jsx("button", { type: "submit", disabled: opening || !name, style: { padding: '10px 18px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontWeight: 'bold' }, children: opening ? 'جارٍ الفتح...' : 'فتح / إنشاء الأسبوع' }), _jsxs("button", { type: "button", onClick: () => setShowCopy(v => !v), style: { padding: '10px 18px', background: '#fff', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: radius.button, fontWeight: 'bold' }, children: ["\u0646\u0633\u062E \u0623\u0633\u0628\u0648\u0639 \u0633\u0627\u0628\u0642 ", showCopy ? '▲' : '▼'] })] })] }) }), showCopy && _jsxs("div", { style: { border: `1px solid ${colors.primary}`, background: colors.primaryTint, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.lg }, children: [_jsx("h3", { style: { marginTop: 0, fontFamily: font.family }, children: "\u0646\u0633\u062E \u0623\u0633\u0628\u0648\u0639 \u0633\u0627\u0628\u0642" }), _jsx("p", { style: { fontSize: 12, color: colors.textMuted }, children: "\u064A\u0646\u0633\u062E \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u060C \u0648\u0644\u0627 \u064A\u0646\u0633\u062E \u0627\u0644\u062E\u0637\u0637 \u0627\u0644\u0639\u0644\u0627\u062C\u064A\u0629. \u0644\u0643\u0644 \u0641\u0635\u0644 \u0646\u0633\u062E\u062A\u0647 \u0627\u0644\u0645\u0633\u062A\u0642\u0644\u0629." }), _jsxs("form", { onSubmit: handleCopy, children: [_jsxs("select", { value: copySourceId, onChange: e => setCopySourceId(e.target.value), required: true, style: { width: '100%', padding: 9, marginBottom: 8 }, children: [_jsx("option", { value: "", children: "\u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u0645\u0635\u062F\u0631" }), weeks.map(w => _jsxs("option", { value: w.id, children: [w.name, " \u2014 ", TYPE_LABELS[w.type]] }, w.id))] }), _jsxs("div", { style: { display: 'grid', gridTemplateColumns: '1fr 150px', gap: 8, marginBottom: 8 }, children: [_jsxs("select", { value: copyName, onChange: e => setCopyName(e.target.value), required: true, style: { padding: 9 }, children: [_jsx("option", { value: "", children: "\u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u062C\u062F\u064A\u062F" }), SCHOOL_WEEK_NAMES.map((n) => _jsx("option", { value: n, children: n }, n))] }), _jsxs("select", { value: copyType, onChange: e => setCopyType(e.target.value), style: { padding: 9, fontWeight: 'bold' }, children: [_jsx("option", { value: "measurement", children: "\u0642\u064A\u0627\u0633" }), _jsx("option", { value: "remediation", children: "\u0645\u0639\u0627\u0644\u062C\u0629" })] })] }), _jsxs("div", { style: { background: '#fff', borderRadius: 8, padding: 8, marginBottom: 8 }, children: [_jsx("strong", { style: { fontSize: 13 }, children: "\u0627\u0644\u0641\u0635\u0648\u0644 \u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641\u0629" }), sameSubjectAssignments.map((a) => _jsxs("label", { style: { display: 'flex', gap: 6, alignItems: 'center', padding: '4px 0', fontSize: 13 }, children: [_jsx("input", { type: "checkbox", checked: copyTargetIds.has(a.id), onChange: () => toggleCopyTarget(a.id) }), classNameFor(a.classId), " ", a.id === assignment.id ? '(الحالي)' : ''] }, a.id))] }), _jsx("button", { type: "submit", disabled: copying || !copyTargetIds.size, style: { padding: '9px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: copying ? 'جارٍ النسخ...' : 'نسخ للفصول المحددة' })] }), copyResults && _jsx("div", { style: { marginTop: 10, fontSize: 12 }, children: copyResults.map((r) => { const a = sameSubjectAssignments.find((x) => x.id === r.assignmentId); return _jsxs("div", { style: { color: r.ok ? '#0b5c33' : colors.red }, children: [classNameFor(a?.classId), ": ", r.ok ? 'تم النسخ بنجاح' : r.error] }, r.assignmentId); }) })] }), _jsxs("h3", { style: { fontFamily: font.family, marginBottom: 8 }, children: ["\u0627\u0644\u0623\u0633\u0627\u0628\u064a\u0639 \u0627\u0644\u062f\u0631\u0627\u0633\u064a\u0629 (", weeks.length, ")"] }), weeks.length === 0 ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0623\u0633\u0627\u0628\u064A\u0639 \u0628\u0639\u062F." }) : weeks.map(w => _jsx("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.button, marginBottom: 8, padding: spacing.md }, children: _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }, children: [_jsxs("button", { onClick: () => setSelectedWeekId(w.id), style: { background: 'none', border: 'none', color: colors.ink, fontWeight: 'bold', fontSize: 15, textAlign: 'right' }, children: [w.name, " ", _jsx("span", { style: { fontSize: 11, padding: '2px 7px', borderRadius: 999, background: w.type === 'remediation' ? colors.amberTint : colors.primaryTint, color: w.type === 'remediation' ? colors.amber : '#0b5c33' }, children: TYPE_LABELS[w.type] })] }), _jsx("button", { onClick: () => handleDelete(w), disabled: deletingId === w.id, style: { padding: '5px 10px', background: colors.redTint, border: `1px solid ${colors.redBorder}`, borderRadius: 6, fontSize: 11, color: colors.red }, children: deletingId === w.id ? 'جارٍ الحذف...' : 'حذف' })] }) }, w.id))] });
}
