import React, { useEffect, useMemo, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import { listWeeksForClass } from '../lib/weeksApi.js';
import { buildClassWeekReportData, buildClassRangeReportData } from '../lib/reportsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
import ClassWeekReportDocument from './ClassWeekReportDocument.js';
import ClassRangeReportDocument from './ClassRangeReportDocument.js';
import TreatmentImpactPanel from './TreatmentImpactPanel.jsx';

function weekTypeLabel(week){if(!week)return'—';if(week.type!=='remediation')return'قياس';return`معالجة ${Math.max(1,Number(week.remediationStage)||1)}`;}
async function downloadBlob(blob,filename){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);}

export default function ClassReport({ schoolId,classId,teacherUid,assignmentId,className,subject,teacherName,onBack,defaultWeekId=null,defaultWeekName=null }){
  const [weeks,setWeeks]=useState([]);const [loading,setLoading]=useState(true);const [error,setError]=useState('');const [mode,setMode]=useState('single');const [weekId,setWeekId]=useState('');const [fromWeekId,setFromWeekId]=useState('');const [toWeekId,setToWeekId]=useState('');const [generating,setGenerating]=useState(false);const [weekReport,setWeekReport]=useState(null);const [rangeReport,setRangeReport]=useState(null);
  useEffect(()=>{(async()=>{setLoading(true);setError('');try{setWeeks(await listWeeksForClass(schoolId,classId,teacherUid,assignmentId));}catch(err){setError(err.message||'تعذّر تحميل الأسابيع الدراسية.');}finally{setLoading(false);}})();},[schoolId,classId,teacherUid,assignmentId]);
  const selectedWeek=weeks.find(w=>w.id===weekId)||null;
  const hasLinkedRemediation=useMemo(()=>!!(selectedWeek?.type==='measurement'&&weeks.some(w=>w.type==='remediation'&&w.sourceMeasurementWeekId===selectedWeek.id)),[weeks,selectedWeek]);
  const assignment={id:assignmentId,classId,teacherUid,subject,teacherName};
  function reportTypeLabelFor(data){const base=data.weekTypeLabel==='قياس'?'تقرير قياس المهارات':`تقرير ${data.weekTypeLabel} للمهارات`;return`${base} للصف ${data.className}`;}
  async function downloadWeekReportPdf(data){const blob=await pdf(<ClassWeekReportDocument data={data} reportTypeLabel={reportTypeLabelFor(data)}/>).toBlob();await downloadBlob(blob,`تقرير-فصل-${data.weekName}.pdf`);}
  async function downloadRangeReportPdf(data){const blob=await pdf(<ClassRangeReportDocument data={data}/>).toBlob();await downloadBlob(blob,`تقرير-فصل-مدى-أسابيع-${data.className}.pdf`);}
  async function generateSingleWeekReport(targetWeekId,{download=true}={}){const week=weeks.find(w=>w.id===targetWeekId);if(!week)return;setGenerating(true);setError('');try{const data=await buildClassWeekReportData(schoolId,{classId,teacherUid,assignmentId,className,subject,teacherName,weekId:targetWeekId,weekName:week.name,weekTypeLabel:weekTypeLabel(week),enrichmentLink:week.enrichmentLink||''});setWeekReport(data);setRangeReport(null);if(download)await downloadWeekReportPdf(data);}catch(err){setError(err.message||'تعذّر توليد التقرير.');}finally{setGenerating(false);}}
  useEffect(()=>{if(loading||weeks.length===0||(!defaultWeekId&&!defaultWeekName))return;const match=(defaultWeekId&&weeks.find(w=>w.id===defaultWeekId))||(defaultWeekName&&weeks.find(w=>w.name===defaultWeekName));if(match){setWeekId(match.id);generateSingleWeekReport(match.id,{download:false});}},[loading,weeks,defaultWeekId,defaultWeekName]);
  async function handleGenerate(e){e.preventDefault();setError('');setGenerating(true);try{if(mode==='single'){if(!weekId)return;await generateSingleWeekReport(weekId,{download:true});}else{if(!fromWeekId||!toWeekId)return;const data=await buildClassRangeReportData(schoolId,{classId,teacherUid,assignmentId,className,subject,teacherName,fromWeekId,toWeekId});setRangeReport(data);setWeekReport(null);await downloadRangeReportPdf(data);}}catch(err){setError(err.message||'تعذّر توليد التقرير.');}finally{setGenerating(false);}}
  async function handleDownloadCurrent(){setGenerating(true);try{if(weekReport)await downloadWeekReportPdf(weekReport);else if(rangeReport)await downloadRangeReportPdf(rangeReport);}catch(err){setError(err.message||'تعذّر تحميل التقرير.');}finally{setGenerating(false);}}
  if(loading)return <p style={{textAlign:'center',marginTop:60}}>جارٍ التحميل...</p>;
  const currentReportName=weekReport?weekReport.weekName:rangeReport?`${rangeReport.fromWeekName} — ${rangeReport.toWeekName}`:'';
  return <div style={{maxWidth:650,margin:'20px auto',padding:spacing.lg}} dir="rtl">
    {onBack&&<button onClick={onBack} style={{background:'none',border:'none',color:colors.primary,marginBottom:spacing.sm}}>← العودة</button>}
    <h1 style={{fontFamily:font.family,color:colors.ink}}>تقرير الفصل</h1><p style={{color:colors.textMuted,fontSize:13}}>{className} — {subject}</p>
    {error&&<div style={{background:colors.redTint,color:colors.red,padding:10,borderRadius:radius.button,marginBottom:spacing.md}}>{error}</div>}
    {(weekReport||rangeReport)&&<div style={{background:colors.primaryTint,border:`1px solid ${colors.primary}`,color:'#0b5c33',borderRadius:radius.button,padding:spacing.sm,marginBottom:spacing.md,fontSize:13,display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:8}}><span>✓ تقرير {currentReportName} جاهز.</span><button onClick={handleDownloadCurrent} disabled={generating} style={{padding:'6px 14px',background:colors.primary,color:'#fff',border:'none',borderRadius:radius.button,fontSize:12}}>{generating?'...':'تحميل PDF'}</button></div>}
    <form onSubmit={handleGenerate} style={{border:`1px solid ${colors.border}`,borderRadius:radius.card,padding:spacing.lg}}>
      <label>نوع التقرير</label><select value={mode} onChange={e=>setMode(e.target.value)} style={{width:'100%',padding:spacing.sm,marginBottom:spacing.sm}}><option value="single">أسبوع محدد</option><option value="range">مدى أسابيع (ملخص إحصائي)</option></select>
      {mode==='single'?<><label>الأسبوع</label><select value={weekId} onChange={e=>{setWeekId(e.target.value);setWeekReport(null);}} style={{width:'100%',padding:spacing.sm,marginBottom:spacing.sm}} required><option value="">اختيار أسبوع</option>{weeks.map(w=><option key={w.id} value={w.id}>{w.name} ({weekTypeLabel(w)})</option>)}</select></>:<><label>من أسبوع</label><select value={fromWeekId} onChange={e=>setFromWeekId(e.target.value)} style={{width:'100%',padding:spacing.sm,marginBottom:spacing.sm}} required><option value="">اختيار أسبوع</option>{weeks.map(w=><option key={w.id} value={w.id}>{w.name} ({weekTypeLabel(w)})</option>)}</select><label>إلى أسبوع</label><select value={toWeekId} onChange={e=>setToWeekId(e.target.value)} style={{width:'100%',padding:spacing.sm,marginBottom:spacing.sm}} required><option value="">اختيار أسبوع</option>{weeks.map(w=><option key={w.id} value={w.id}>{w.name} ({weekTypeLabel(w)})</option>)}</select></>}
      <button type="submit" disabled={generating} style={{width:'100%',padding:'10px 14px',background:colors.primary,color:'#fff',border:'none',borderRadius:radius.button,fontWeight:'bold'}}>{generating?'جارٍ التوليد...':'توليد التقرير وتحميله'}</button>
    </form>
    {mode==='single'&&hasLinkedRemediation&&selectedWeek&&<TreatmentImpactPanel key={selectedWeek.id} schoolId={schoolId} assignment={assignment} measurementWeekId={selectedWeek.id} className={className} teacherName={teacherName}/>} 
  </div>;
}
