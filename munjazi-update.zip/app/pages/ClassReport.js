import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import { listWeeksForClass } from '../lib/weeksApi.js';
import { buildClassWeekReportData, buildClassRangeReportData } from '../lib/reportsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
import ClassWeekReportDocument from './ClassWeekReportDocument.js';
import ClassRangeReportDocument from './ClassRangeReportDocument.js';
async function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
export default function ClassReport({ schoolId, classId, teacherUid, assignmentId, className, subject, teacherName, onBack, defaultWeekId = null, defaultWeekName = null, }) {
    const [weeks, setWeeks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [mode, setMode] = useState('single');
    const [weekId, setWeekId] = useState('');
    const [fromWeekId, setFromWeekId] = useState('');
    const [toWeekId, setToWeekId] = useState('');
    const [generating, setGenerating] = useState(false);
    const [weekReport, setWeekReport] = useState(null);
    const [rangeReport, setRangeReport] = useState(null);
    useEffect(() => {
        (async () => {
            setLoading(true);
            setError('');
            try {
                const rows = await listWeeksForClass(schoolId, classId, teacherUid, assignmentId);
                setWeeks(rows);
            }
            catch (err) {
                setError(err.message || 'تعذّر تحميل الأسابيع الدراسية.');
            }
            finally {
                setLoading(false);
            }
        })();
    }, [schoolId, classId, teacherUid, assignmentId]);
    function reportTypeLabelFor(data) {
        const base = data.weekTypeLabel === 'قياس' ? 'تقرير قياس المهارات' : 'تقرير معالجة المهارات';
        return `${base} للصف ${data.className}`;
    }
    async function downloadWeekReportPdf(data) {
        const blob = await pdf(_jsx(ClassWeekReportDocument, { data: data, reportTypeLabel: reportTypeLabelFor(data) })).toBlob();
        await downloadBlob(blob, `تقرير-فصل-${data.weekName}.pdf`);
    }
    async function downloadRangeReportPdf(data) {
        const blob = await pdf(_jsx(ClassRangeReportDocument, { data: data })).toBlob();
        await downloadBlob(blob, `تقرير-فصل-مدى-أسابيع-${data.className}.pdf`);
    }
    async function generateSingleWeekReport(targetWeekId, { download } = { download: true }) {
        const week = weeks.find((w) => w.id === targetWeekId);
        if (!week)
            return;
        setGenerating(true);
        setError('');
        try {
            const data = await buildClassWeekReportData(schoolId, {
                classId,
                teacherUid,
                assignmentId,
                className,
                subject,
                teacherName,
                weekId: targetWeekId,
                weekName: week.name,
                weekTypeLabel: week.type === 'remediation' ? 'معالجة' : 'قياس',
                enrichmentLink: week.enrichmentLink || '',
            });
            setWeekReport(data);
            setRangeReport(null);
            if (download)
                await downloadWeekReportPdf(data);
        }
        catch (err) {
            setError(err.message || 'تعذّر توليد التقرير.');
        }
        finally {
            setGenerating(false);
        }
    }
    useEffect(() => {
        if (loading || weeks.length === 0 || (!defaultWeekId && !defaultWeekName))
            return;
        const match = (defaultWeekId && weeks.find((w) => w.id === defaultWeekId))
            || (defaultWeekName && weeks.find((w) => w.name === defaultWeekName));
        if (match) {
            setWeekId(match.id);
            generateSingleWeekReport(match.id, { download: false });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [loading, weeks, defaultWeekId, defaultWeekName]);
    async function handleGenerate(e) {
        e.preventDefault();
        setError('');
        setGenerating(true);
        try {
            if (mode === 'single') {
                if (!weekId)
                    return;
                await generateSingleWeekReport(weekId, { download: true });
            }
            else {
                if (!fromWeekId || !toWeekId)
                    return;
                const data = await buildClassRangeReportData(schoolId, {
                    classId,
                    teacherUid,
                    assignmentId,
                    className,
                    subject,
                    teacherName,
                    fromWeekId,
                    toWeekId,
                });
                setRangeReport(data);
                setWeekReport(null);
                await downloadRangeReportPdf(data);
            }
        }
        catch (err) {
            setError(err.message || 'تعذّر توليد التقرير.');
        }
        finally {
            setGenerating(false);
        }
    }
    async function handleDownloadCurrent() {
        setGenerating(true);
        try {
            if (weekReport)
                await downloadWeekReportPdf(weekReport);
            else if (rangeReport)
                await downloadRangeReportPdf(rangeReport);
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل التقرير.');
        }
        finally {
            setGenerating(false);
        }
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    const currentReportName = weekReport ? weekReport.weekName : rangeReport ? `${rangeReport.fromWeekName} — ${rangeReport.toWeekName}` : '';
    return (_jsxs("div", { style: { maxWidth: 600, margin: '20px auto', padding: spacing.lg }, dir: "rtl", children: [onBack && _jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629" }), _jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u062A\u0642\u0631\u064A\u0631 \u0627\u0644\u0641\u0635\u0644" }), _jsxs("p", { style: { color: colors.textMuted, fontSize: 13 }, children: [className, " \u2014 ", subject] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), (weekReport || rangeReport) && (_jsxs("div", { style: { background: colors.primaryTint, border: `1px solid ${colors.primary}`, color: '#0b5c33', borderRadius: radius.button, padding: spacing.sm, marginBottom: spacing.md, fontSize: 13, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }, children: [_jsxs("span", { children: ["\u2713 \u062A\u0642\u0631\u064A\u0631 ", currentReportName, " \u062C\u0627\u0647\u0632."] }), _jsx("button", { onClick: handleDownloadCurrent, disabled: generating, style: { padding: '6px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontSize: 12 }, children: generating ? '...' : 'تحميل PDF' })] })), _jsxs("form", { onSubmit: handleGenerate, style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg }, children: [_jsx("label", { children: "\u0646\u0648\u0639 \u0627\u0644\u062A\u0642\u0631\u064A\u0631" }), _jsxs("select", { value: mode, onChange: (e) => setMode(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, children: [_jsx("option", { value: "single", children: "\u0623\u0633\u0628\u0648\u0639 \u0645\u062D\u062F\u062F" }), _jsx("option", { value: "range", children: "\u0645\u062F\u0649 \u0623\u0633\u0627\u0628\u064A\u0639 (\u0645\u0644\u062E\u0635 \u0625\u062D\u0635\u0627\u0626\u064A)" })] }), mode === 'single' ? (_jsxs(_Fragment, { children: [_jsx("label", { children: "\u0627\u0644\u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: weekId, onChange: (e) => setWeekId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0623\u0633\u0628\u0648\u0639" }), weeks.map((w) => _jsxs("option", { value: w.id, children: [w.name, " (", w.type === 'remediation' ? 'معالجة' : 'قياس', ")"] }, w.id))] })] })) : (_jsxs(_Fragment, { children: [_jsx("label", { children: "\u0645\u0646 \u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: fromWeekId, onChange: (e) => setFromWeekId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0623\u0633\u0628\u0648\u0639" }), weeks.map((w) => _jsxs("option", { value: w.id, children: [w.name, " (", w.type === 'remediation' ? 'معالجة' : 'قياس', ")"] }, w.id))] }), _jsx("label", { children: "\u0625\u0644\u0649 \u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: toWeekId, onChange: (e) => setToWeekId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0623\u0633\u0628\u0648\u0639" }), weeks.map((w) => _jsxs("option", { value: w.id, children: [w.name, " (", w.type === 'remediation' ? 'معالجة' : 'قياس', ")"] }, w.id))] })] })), _jsx("button", { type: "submit", disabled: generating, style: { padding: '10px 16px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: generating ? '...جارٍ التوليد' : 'توليد التقرير وتحميله' })] })] }));
}
