export { default } from './ClassReportEnhanced.jsx';
