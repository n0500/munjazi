import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import StudentReport from './StudentReport.js';
import ClassReport from './ClassReport.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
export default function TeacherReports({ schoolId, teacherUid, teacherName, assignments, classNameFor }) {
    const [assignmentId, setAssignmentId] = useState(assignments[0]?.id || '');
    const [mode, setMode] = useState(null);
    const assignment = assignments.find((a) => a.id === assignmentId) || null;
    useEffect(() => {
        setAssignmentId((current) => assignments.some((a) => a.id === current) ? current : assignments[0]?.id || '');
        setMode(null);
    }, [assignments]);
    if (mode === 'student' && assignment) {
        return (_jsx(StudentReport, { schoolId: schoolId, classId: assignment.classId, teacherUid: teacherUid, assignmentId: assignment.id, className: classNameFor(assignment.classId), subject: assignment.subject || '', teacherName: teacherName, onBack: () => setMode(null) }));
    }
    if (mode === 'class' && assignment) {
        return (_jsx(ClassReport, { schoolId: schoolId, classId: assignment.classId, teacherUid: teacherUid, assignmentId: assignment.id, className: classNameFor(assignment.classId), subject: assignment.subject || '', teacherName: teacherName, onBack: () => setMode(null) }));
    }
    return (_jsxs("div", { style: { maxWidth: 700, margin: '0 auto' }, dir: "rtl", children: [_jsx("h2", { style: { fontFamily: font.family, color: colors.ink }, children: "\u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631" }), assignments.length === 0 ? (_jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0633\u0646\u0627\u062F\u0627\u062A \u0646\u0634\u0637\u0629 \u0644\u0625\u0639\u062F\u0627\u062F \u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631." })) : (_jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg }, children: [_jsx("label", { children: "\u0627\u0644\u0645\u0627\u062F\u0629 \u0648\u0627\u0644\u0641\u0635\u0644" }), _jsx("select", { value: assignmentId, onChange: (e) => setAssignmentId(e.target.value), style: { width: '100%', padding: 10, margin: '6px 0 16px' }, children: assignments.map((a) => (_jsxs("option", { value: a.id, children: [a.subject || 'بدون مادة', " \u2014 ", classNameFor(a.classId)] }, a.id))) }), _jsxs("div", { style: { display: 'flex', gap: 10, flexWrap: 'wrap' }, children: [_jsx("button", { onClick: () => setMode('student'), style: { flex: '1 1 180px', padding: '12px 16px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: "\u062A\u0642\u0631\u064A\u0631 \u0637\u0627\u0644\u0628\u0629" }), _jsx("button", { onClick: () => setMode('class'), style: { flex: '1 1 180px', padding: '12px 16px', background: colors.ink, color: '#fff', border: 'none', borderRadius: radius.button }, children: "\u062A\u0642\u0631\u064A\u0631 \u0627\u0644\u0641\u0635\u0644" })] }), _jsx("p", { style: { fontSize: 12, color: colors.textMuted, marginBottom: 0, marginTop: 12 }, children: "\u062A\u0635\u0645\u064A\u0645 \u0645\u0644\u0641\u0627\u062A PDF \u0648\u0642\u0648\u0627\u0644\u0628\u0647\u0627 \u0644\u0645 \u064A\u062A\u063A\u064A\u0631\u061B \u0627\u0644\u062A\u062D\u062F\u064A\u062B \u064A\u062E\u0635 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0635\u062D\u064A\u062D\u0629 \u0644\u0644\u0645\u0627\u062F\u0629 \u0648\u0627\u0644\u0641\u062A\u0631\u0629 \u0641\u0642\u0637." })] }))] }));
}
