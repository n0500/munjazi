import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from 'react';
import { collection, query, where, getDocs, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase.js';
import { listWeeksForClass } from '../lib/weeksApi.js';
import { listSkillsForWeek } from '../lib/skillsApi.js';
import { colors, spacing, radius } from '../lib/theme.js';
export default function ScanActions({ schoolId }) {
    const [scanning, setScanning] = useState(false);
    const [suspicious, setSuspicious] = useState(null);
    const [selected, setSelected] = useState(new Set());
    const [deleting, setDeleting] = useState(false);
    const [message, setMessage] = useState('');
    async function runScan() {
        setScanning(true);
        setMessage('');
        setSuspicious(null);
        setSelected(new Set());
        try {
            const actionsQ = query(collection(db, 'schools', schoolId, 'actions'), where('status', '==', 'active'));
            const actionsSnap = await getDocs(actionsQ);
            const actions = actionsSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
            // نبني ذاكرة تخزين مؤقت: لكل (classId + teacherUid) نجمع كل عناوين المهارات
            // اللي سبق للمعلمة رصدها في أي أسبوع من أسابيعها بهذا الفصل
            const teacherSkillsCache = {};
            async function getTeacherSkillTitles(classId, teacherUid) {
                const cacheKey = `${classId}__${teacherUid}`;
                if (teacherSkillsCache[cacheKey])
                    return teacherSkillsCache[cacheKey];
                const weeks = await listWeeksForClass(schoolId, classId, teacherUid);
                const titlesSet = new Set();
                for (const week of weeks) {
                    // eslint-disable-next-line no-await-in-loop
                    const skills = await listSkillsForWeek(schoolId, week.id);
                    skills.forEach((s) => titlesSet.add(s.title.trim()));
                }
                teacherSkillsCache[cacheKey] = titlesSet;
                return titlesSet;
            }
            const flagged = [];
            for (const action of actions) {
                // eslint-disable-next-line no-await-in-loop
                const teacherTitles = await getTeacherSkillTitles(action.classId, action.teacherUid);
                const affected = action.affectedSkillTitles || [];
                const matchesAny = affected.some((t) => teacherTitles.has((t || '').trim()));
                if (affected.length > 0 && !matchesAny) {
                    flagged.push(action);
                }
            }
            setSuspicious(flagged);
            if (flagged.length === 0)
                setMessage('لم يتم العثور على أي إجراءات مشبوهة. البيانات نظيفة.');
        }
        catch (err) {
            setMessage('خطأ أثناء الفحص: ' + (err.message || err));
        }
        finally {
            setScanning(false);
        }
    }
    function toggleSelect(id) {
        setSelected((prev) => {
            const next = new Set(prev);
            if (next.has(id))
                next.delete(id);
            else
                next.add(id);
            return next;
        });
    }
    function selectAll() {
        setSelected(new Set(suspicious.map((a) => a.id)));
    }
    async function deleteSelected() {
        if (selected.size === 0)
            return;
        setDeleting(true);
        setMessage('');
        try {
            for (const actionId of selected) {
                // eslint-disable-next-line no-await-in-loop
                await deleteDoc(doc(db, 'schools', schoolId, 'actions', actionId));
            }
            setSuspicious((prev) => prev.filter((a) => !selected.has(a.id)));
            setMessage(`تم حذف ${selected.size} إجراء بنجاح.`);
            setSelected(new Set());
        }
        catch (err) {
            setMessage('خطأ أثناء الحذف: ' + (err.message || err));
        }
        finally {
            setDeleting(false);
        }
    }
    return (_jsxs("div", { style: { maxWidth: 700, margin: '0 auto', padding: spacing.lg }, dir: "rtl", children: [_jsx("h2", { children: "\u0623\u062F\u0627\u0629 \u0641\u062D\u0635 \u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u062A\u0639\u0627\u0631\u0636\u0629" }), _jsx("p", { style: { color: colors.textMuted, fontSize: 13 }, children: "\u062A\u0641\u062D\u0635 \u0647\u0630\u064A \u0627\u0644\u0623\u062F\u0627\u0629 \u0643\u0644 \u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0646\u0634\u0637\u0629 \u0628\u0645\u062F\u0631\u0633\u062A\u0643\u060C \u0648\u062A\u0643\u0634\u0641 \u0623\u064A \u0625\u062C\u0631\u0627\u0621 \u0645\u0647\u0627\u0631\u0627\u062A\u0647 \u0627\u0644\u0645\u0630\u0643\u0648\u0631\u0629 \u0644\u0627 \u062A\u0646\u062A\u0645\u064A \u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u0629 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u0629 \u0639\u0646\u0647." }), _jsx("button", { onClick: runScan, disabled: scanning, style: { padding: '10px 20px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, marginBottom: spacing.md }, children: scanning ? '...جارٍ الفحص' : 'بدء الفحص' }), message && (_jsx("div", { style: { background: colors.primaryTint, color: '#0b5c33', padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: message })), suspicious && suspicious.length > 0 && (_jsxs(_Fragment, { children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm }, children: [_jsxs("span", { children: ["\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 ", suspicious.length, " \u0625\u062C\u0631\u0627\u0621 \u0645\u0634\u0628\u0648\u0647"] }), _jsxs("div", { style: { display: 'flex', gap: 8 }, children: [_jsx("button", { onClick: selectAll, style: { background: 'none', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: '6px 12px', fontSize: 12 }, children: "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0643\u0644" }), _jsx("button", { onClick: deleteSelected, disabled: deleting || selected.size === 0, style: { background: colors.red, color: '#fff', border: 'none', borderRadius: radius.button, padding: '6px 12px', fontSize: 12 }, children: deleting ? '...جارٍ الحذف' : `حذف المحدد (${selected.size})` })] })] }), suspicious.map((a) => (_jsx("div", { style: { border: `1px solid ${colors.redBorder}`, background: colors.redTint, borderRadius: radius.card, padding: spacing.md, marginBottom: spacing.sm }, children: _jsxs("label", { style: { display: 'flex', gap: 10, alignItems: 'flex-start', cursor: 'pointer' }, children: [_jsx("input", { type: "checkbox", checked: selected.has(a.id), onChange: () => toggleSelect(a.id), style: { marginTop: 4 } }), _jsxs("div", { style: { fontSize: 13 }, children: [_jsxs("div", { children: [_jsx("strong", { children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629:" }), " ", a.studentName] }), _jsxs("div", { children: [_jsx("strong", { children: "\u0627\u0644\u0646\u0648\u0639:" }), " ", a.type === 'remedial' ? 'علاجي' : 'إثرائي'] }), _jsxs("div", { children: [_jsx("strong", { children: "\u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0630\u0643\u0648\u0631\u0629:" }), " ", (a.affectedSkillTitles || []).join('، ')] }), _jsxs("div", { style: { color: colors.textMuted, fontSize: 11, marginTop: 4 }, children: ["Action ID: ", a.id, " \u2014 Teacher: ", a.teacherUid, " \u2014 Class: ", a.classId] })] })] }) }, a.id)))] }))] }));
}
