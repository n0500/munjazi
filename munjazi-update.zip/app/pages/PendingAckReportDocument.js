import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';
Font.register({
    family: 'Plex',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf',
});
Font.register({
    family: 'Plex-Bold',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf',
});
// امنع تقطيع أي كلمة داخل أسطر تقارير PDF، سواء كانت عربية أو إنجليزية.
Font.registerHyphenationCallback((word) => [word]);
const HEADER_BG = '#14261e';
const HEADER_DIVIDER = '#3a4a42';
const ROW_BORDER = '#e0e0e0';
const COL_BORDER = '#cfcfcf';
const styles = StyleSheet.create({
    // زدنا المساحة العلوية المحجوزة لضمان عدم ازدحام أول صف بالجدول مع عناوين الأعمدة الثابتة
    page: { fontFamily: 'Plex', paddingTop: 148, paddingBottom: 40, paddingHorizontal: 24, fontSize: 9 },
    fixedHeaderBlock: { position: 'absolute', top: 14, left: 24, right: 24 },
    reportLogo: { position: 'absolute', top: 0, right: 0, width: 62, height: 28, objectFit: 'contain' },
    // اسم المدرسة أصغر بدرجة واحدة من العنوان الأحمر (13 بدل 14)، مع مسافة أكبر أسفله
    schoolName: { fontFamily: 'Plex-Bold', fontSize: 13, color: '#14261e', textAlign: 'center', lineHeight: 1.3 },
    reportTitle: { fontFamily: 'Plex-Bold', fontSize: 14, color: '#a10000', textAlign: 'center', marginTop: 10, lineHeight: 1.3 },
    metaLine: { fontSize: 9, color: '#555', textAlign: 'center', marginTop: 4, lineHeight: 1.3 },
    scopeLine: { fontSize: 9, color: '#0b7a4b', fontFamily: 'Plex-Bold', textAlign: 'center', marginTop: 5 },
    countLine: { fontSize: 9, color: '#a10000', textAlign: 'center', marginTop: 7, marginBottom: 10, fontFamily: 'Plex-Bold' },
    tableHeaderRow: { flexDirection: 'row-reverse', backgroundColor: HEADER_BG, paddingVertical: 6 },
    headerCell: {
        fontFamily: 'Plex-Bold', fontSize: 8.5, textAlign: 'center', color: '#ffffff',
        borderLeftWidth: 0.75, borderLeftColor: HEADER_DIVIDER, paddingHorizontal: 3,
    },
    headerCellFirst: { textAlign: 'right', paddingRight: 6 },
    // زيادة طفيفة بالارتفاع الأدنى والحشوة الرأسية لأول صف وكل الصفوف، لتفادي شعور الازدحام
    row: {
        flexDirection: 'row-reverse', minHeight: 24, alignItems: 'center',
        borderLeftWidth: 1, borderRightWidth: 1, borderBottomWidth: 0.75, borderColor: ROW_BORDER,
    },
    rowEven: { backgroundColor: '#fafafa' },
    cell: { fontSize: 8, textAlign: 'right', paddingHorizontal: 5, paddingVertical: 5, borderLeftWidth: 0.75, borderLeftColor: COL_BORDER },
    repeatedBadge: {
        backgroundColor: '#fdecea', borderColor: '#c62828', borderWidth: 1, borderRadius: 4,
        paddingHorizontal: 5, paddingVertical: 1.5, alignSelf: 'center',
    },
    repeatedBadgeText: { fontSize: 7.5, color: '#a10000', fontFamily: 'Plex-Bold' },
    footer: {
        position: 'absolute', bottom: 14, left: 24, right: 24,
        flexDirection: 'row-reverse', justifyContent: 'space-between',
        fontSize: 8, color: '#333', borderTop: 0.5, borderTopColor: '#ccc', paddingTop: 6,
    },
});
const COL_WIDTHS = { student: 18, teacher: 15, subjectClass: 20, skill: 22, date: 13, repeated: 12 };
export default function PendingAckReportDocument({ rows, schoolName, scopeLabel, generatedDate }) {
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", style: styles.page, children: [_jsxs(View, { style: styles.fixedHeaderBlock, fixed: true, children: [_jsx(ReportLogo, { style: styles.reportLogo }), _jsx(Text, { style: styles.schoolName, children: schoolName }), _jsx(Text, { style: styles.reportTitle, children: "\u062A\u0642\u0631\u064A\u0631: \u0623\u0648\u0644\u064A\u0627\u0621 \u0623\u0645\u0648\u0631 \u0644\u0645 \u064A\u0637\u0651\u0644\u0639\u0648\u0627 \u0639\u0644\u0649 \u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0646\u0634\u0637\u0629" }), _jsxs(Text, { style: styles.metaLine, children: ["\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0642\u0631\u064A\u0631: ", generatedDate] }), _jsxs(Text, { style: styles.scopeLine, children: ["\u0627\u0644\u0646\u0637\u0627\u0642: ", scopeLabel] }), _jsxs(Text, { style: styles.countLine, children: ["\u0639\u062F\u062F \u0627\u0644\u062D\u0627\u0644\u0627\u062A: ", rows.length] }), _jsxs(View, { style: styles.tableHeaderRow, children: [_jsx(Text, { style: [styles.headerCell, styles.headerCellFirst, { width: `${COL_WIDTHS.student}%` }], children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }), _jsx(Text, { style: [styles.headerCell, { width: `${COL_WIDTHS.teacher}%` }], children: "\u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629" }), _jsx(Text, { style: [styles.headerCell, { width: `${COL_WIDTHS.subjectClass}%` }], children: "\u0627\u0644\u0645\u0627\u062F\u0629 / \u0627\u0644\u0641\u0635\u0644" }), _jsx(Text, { style: [styles.headerCell, { width: `${COL_WIDTHS.skill}%` }], children: "\u0627\u0644\u0645\u0647\u0627\u0631\u0629" }), _jsx(Text, { style: [styles.headerCell, { width: `${COL_WIDTHS.date}%` }], children: "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0641\u0639\u064A\u0644" }), _jsx(Text, { style: [styles.headerCell, { width: `${COL_WIDTHS.repeated}%` }], children: "\u0645\u062A\u0643\u0631\u0631\u0629\u061F" })] })] }), rows.map((r, i) => (_jsxs(View, { style: [styles.row, i % 2 === 1 && styles.rowEven], wrap: false, children: [_jsx(Text, { style: [styles.cell, { width: `${COL_WIDTHS.student}%` }], children: r.studentName }), _jsx(Text, { style: [styles.cell, { width: `${COL_WIDTHS.teacher}%` }], children: r.teacherName }), _jsxs(Text, { style: [styles.cell, { width: `${COL_WIDTHS.subjectClass}%` }], children: [r.subject, " \u2014 ", r.className] }), _jsx(Text, { style: [styles.cell, { width: `${COL_WIDTHS.skill}%` }], children: r.skillTitles }), _jsx(Text, { style: [styles.cell, { width: `${COL_WIDTHS.date}%`, textAlign: 'center' }], children: r.activatedDate }), _jsx(View, { style: [styles.cell, { width: `${COL_WIDTHS.repeated}%` }], children: r.repeated ? (_jsx(View, { style: styles.repeatedBadge, children: _jsx(Text, { style: styles.repeatedBadgeText, children: "\u0645\u062A\u0643\u0631\u0631\u0629" }) })) : (_jsx(Text, { style: { fontSize: 8, textAlign: 'center', color: '#999' }, children: "\u2014" })) })] }, i))), _jsxs(View, { style: styles.footer, fixed: true, children: [_jsx(Text, {}), _jsx(Text, { render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` })] })] }) }));
}
