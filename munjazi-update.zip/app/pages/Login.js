import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { loginOwner, loginAdmin, loginTeacher, loginParent, requestPasswordReset } from '../lib/auth.js';
import { registerTeacher } from '../lib/teachersApi.js';
import Logo from '../components/Logo.js';
import Footer from '../components/Footer.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const TABS = [
    { key: 'admin', label: 'الإدارة' },
    { key: 'teacher', label: 'المعلّمة' },
    { key: 'parent', label: 'ولي الأمر' },
];
const UI_LOGIN_TIMEOUT_MS = 12000;
function withUiTimeout(promise) {
    let timer;
    const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('تأخر تسجيل الدخول. تحققي من الاتصال ثم حاولي مرة أخرى.')), UI_LOGIN_TIMEOUT_MS);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
export default function Login() {
    const params = new URLSearchParams(window.location.search);
    const directParentLink = params.get('role') === 'parent';
    const [tab, setTab] = useState(directParentLink ? 'parent' : 'admin');
    const [ownerMode, setOwnerMode] = useState(false);
    const [registerMode, setRegisterMode] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [schoolCode, setSchoolCode] = useState('');
    const [nationalId, setNationalId] = useState('');
    const [regName, setRegName] = useState('');
    const [error, setError] = useState('');
    const [successMsg, setSuccessMsg] = useState('');
    const [busy, setBusy] = useState(false);
    const [resetBusy, setResetBusy] = useState(false);
    function resetMsgs() {
        setError('');
        setSuccessMsg('');
    }
    async function handleStaffSubmit(e) {
        e.preventDefault();
        resetMsgs();
        if (!email.trim() || !password || busy)
            return;
        setBusy(true);
        try {
            if (ownerMode) {
                await withUiTimeout(loginOwner(email, password));
            }
            else if (tab === 'admin') {
                await withUiTimeout(loginAdmin(email, password));
            }
            else if (tab === 'teacher') {
                await withUiTimeout(loginTeacher(email, password));
            }
        }
        catch (err) {
            setError(err.message || 'تعذّر تسجيل الدخول.');
        }
        finally {
            setBusy(false);
        }
    }
    async function handleForgotPassword() {
        resetMsgs();
        if (resetBusy)
            return;
        if (!email.trim()) {
            setError('أدخلي البريد الإلكتروني أولًا، ثم اختاري «نسيت كلمة المرور؟».');
            return;
        }
        setResetBusy(true);
        try {
            await requestPasswordReset(email);
            setSuccessMsg('تم إرسال رابط إعادة تعيين كلمة المرور إلى البريد الإلكتروني. يُرجى التحقق من الوارد والرسائل غير المرغوب فيها.');
        }
        catch (err) {
            if (err?.code === 'auth/user-not-found') {
                setSuccessMsg('إذا كان البريد الإلكتروني مسجلاً في منجزي فسيصل إليه رابط إعادة تعيين كلمة المرور.');
            }
            else if (err?.code === 'auth/invalid-email') {
                setError('البريد الإلكتروني غير صحيح.');
            }
            else if (err?.code === 'auth/too-many-requests') {
                setError('تم إرسال عدة طلبات خلال وقت قصير. يُرجى المحاولة لاحقًا.');
            }
            else {
                setError(err.message || 'تعذّر إرسال رابط إعادة تعيين كلمة المرور.');
            }
        }
        finally {
            setResetBusy(false);
        }
    }
    // تسجيل حساب جديد متاح للمعلّمات فقط. حسابات الإدارة تُنشأ حصرًا من لوحة المالكة،
    // وتُسلَّم بيانات الدخول للمديرة مباشرة — لا يوجد مسار تسجيل عام لحساب إدارة.
    async function handleRegister(e) {
        e.preventDefault();
        resetMsgs();
        if (!schoolCode.trim() || !email.trim() || !password || busy)
            return;
        setBusy(true);
        try {
            const { schoolName } = await registerTeacher({ schoolCode, displayName: regName, email, password });
            setSuccessMsg(`تم إنشاء حساب معلّمة "${schoolName}" وتسجيل الدخول بنجاح.`);
        }
        catch (err) {
            setError(err.message || 'تعذّر إنشاء الحساب.');
        }
        finally {
            setBusy(false);
        }
    }
    async function handleParentSubmit(e) {
        e.preventDefault();
        resetMsgs();
        if (!nationalId.trim() || busy)
            return;
        setBusy(true);
        try {
            await loginParent(nationalId);
        }
        catch (err) {
            setError(err.message || 'تعذّر تسجيل الدخول.');
        }
        finally {
            setBusy(false);
        }
    }
    const inputStyle = { width: '100%', padding: 10, marginBottom: 10, borderRadius: radius.button, border: `1px solid ${colors.border}`, boxSizing: 'border-box' };
    const submitStyle = { width: '100%', padding: 12, background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button };
    const linkStyle = { background: 'none', border: 'none', color: colors.primary, textDecoration: 'underline' };
    const linkStyleMuted = { background: 'none', border: 'none', color: colors.textMuted, textDecoration: 'underline' };
    const forgotPasswordButton = (_jsx("button", { type: "button", onClick: handleForgotPassword, disabled: resetBusy, style: { ...linkStyle, fontSize: 13, opacity: resetBusy ? 0.6 : 1 }, children: resetBusy ? '...جارٍ الإرسال' : 'نسيت كلمة المرور؟' }));
    return (_jsxs("div", { children: [_jsxs("div", { style: { maxWidth: 420, margin: '40px auto 0', padding: spacing.lg }, dir: "rtl", children: [_jsxs("div", { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: spacing.xl }, children: [_jsx(Logo, { size: "lg" }), _jsx("p", { style: { fontFamily: font.family, fontSize: 13, color: colors.textMuted, marginTop: spacing.sm, marginBottom: 0 }, children: "\u0646\u0638\u0627\u0645 \u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0623\u062F\u0627\u0621 \u0627\u0644\u062F\u0631\u0627\u0633\u064A" })] }), !ownerMode && !directParentLink && (_jsx("div", { style: { display: 'flex', gap: 8, marginBottom: spacing.lg }, children: TABS.map((t) => (_jsx("button", { type: "button", onClick: () => { setTab(t.key); resetMsgs(); setRegisterMode(false); }, style: {
                                flex: 1, padding: 10, fontWeight: tab === t.key ? 'bold' : 'normal',
                                background: tab === t.key ? colors.ink : '#f2f2f2', color: tab === t.key ? '#fff' : '#000',
                                border: 'none', borderRadius: radius.button, fontFamily: font.family, fontSize: 16,
                            }, children: t.label }, t.key))) })), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), successMsg && _jsx("div", { style: { background: colors.primaryTint, color: '#0b5c33', padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: successMsg }), !ownerMode && tab === 'admin' && (_jsxs("form", { onSubmit: handleStaffSubmit, children: [_jsx("label", { children: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A" }), _jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), style: inputStyle, required: true }), _jsx("label", { children: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" }), _jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), style: inputStyle, required: true }), _jsx("button", { type: "submit", disabled: busy, style: submitStyle, children: busy ? 'جارٍ الدخول…' : 'تسجيل الدخول' }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.sm, marginBottom: 0 }, children: forgotPasswordButton }), _jsx("p", { style: { textAlign: 'center', marginTop: 4 }, children: _jsx("button", { type: "button", onClick: () => setOwnerMode(true), style: linkStyleMuted, children: "\u062F\u062E\u0648\u0644 \u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u0627\u0644\u0643" }) })] })), !ownerMode && tab === 'teacher' && !registerMode && (_jsxs("form", { onSubmit: handleStaffSubmit, children: [_jsx("label", { children: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A" }), _jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), style: inputStyle, required: true }), _jsx("label", { children: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" }), _jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), style: inputStyle, required: true }), _jsx("button", { type: "submit", disabled: busy, style: submitStyle, children: busy ? 'جارٍ الدخول…' : 'تسجيل الدخول' }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.sm, marginBottom: 0 }, children: forgotPasswordButton }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.md }, children: _jsx("button", { type: "button", onClick: () => { setRegisterMode(true); resetMsgs(); }, style: linkStyle, children: "\u0625\u0646\u0634\u0627\u0621 \u062D\u0633\u0627\u0628 \u0645\u0639\u0644\u0651\u0645\u0629 \u062C\u062F\u064A\u062F\u0629" }) })] })), !ownerMode && tab === 'teacher' && registerMode && (_jsxs("form", { onSubmit: handleRegister, children: [_jsx("label", { children: "\u0631\u0645\u0632 \u0627\u0644\u0645\u062F\u0631\u0633\u0629" }), _jsx("input", { type: "text", value: schoolCode, onChange: (e) => setSchoolCode(e.target.value), style: inputStyle, required: true }), _jsx("label", { children: "\u0627\u0644\u0627\u0633\u0645" }), _jsx("input", { type: "text", value: regName, onChange: (e) => setRegName(e.target.value), style: inputStyle }), _jsx("label", { children: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A" }), _jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), style: inputStyle, required: true }), _jsx("label", { children: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" }), _jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), style: inputStyle, required: true, minLength: 6 }), _jsx("button", { type: "submit", disabled: busy, style: submitStyle, children: busy ? '...' : 'إنشاء الحساب' }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.md }, children: _jsx("button", { type: "button", onClick: () => { setRegisterMode(false); resetMsgs(); }, style: linkStyleMuted, children: "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644" }) })] })), ownerMode && (_jsxs("form", { onSubmit: handleStaffSubmit, children: [_jsx("label", { children: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A" }), _jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), style: inputStyle, required: true }), _jsx("label", { children: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" }), _jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), style: inputStyle, required: true }), _jsx("button", { type: "submit", disabled: busy, style: submitStyle, children: busy ? 'جارٍ الدخول…' : 'تسجيل الدخول' }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.sm, marginBottom: 0 }, children: forgotPasswordButton }), _jsx("p", { style: { textAlign: 'center', marginTop: spacing.md }, children: _jsx("button", { type: "button", onClick: () => setOwnerMode(false), style: linkStyleMuted, children: "\u0639\u0648\u062F\u0629" }) })] })), !ownerMode && tab === 'parent' && (_jsxs("form", { onSubmit: handleParentSubmit, children: [_jsx("label", { children: "\u0631\u0642\u0645 \u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0645\u062F\u0646\u064A (\u0639\u0634\u0631\u0629 \u0623\u0631\u0642\u0627\u0645)" }), _jsx("input", { type: "text", inputMode: "numeric", value: nationalId, onChange: (e) => setNationalId(e.target.value), style: inputStyle, required: true, autoFocus: true }), _jsx("button", { type: "submit", disabled: busy, style: submitStyle, children: busy ? 'جارٍ الدخول…' : 'تسجيل الدخول' })] }))] }), _jsx(Footer, {})] }));
}
