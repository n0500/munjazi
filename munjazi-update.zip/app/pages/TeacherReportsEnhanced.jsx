import React, { useEffect, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import StudentReport from './StudentReport.js';
import ClassReport from './ClassReport.js';
import TeacherAllClassesReportDocument from './TeacherAllClassesReportDocument.jsx';
import ImpactReportDocument from './ImpactReportDocument.jsx';
import { buildAllClassesAnalysisData, buildImpactReportData, loadPeriodContext } from '../lib/impactReportsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';

function saveBlob(blob, name) { const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }

export default function TeacherReports({ schoolId, teacherUid, teacherName, assignments, classNameFor }) {
  const [assignmentId,setAssignmentId]=useState(assignments[0]?.id||'');
  const [mode,setMode]=useState(null);
  const [periodContext,setPeriodContext]=useState({weekLists:{},periodOptions:[]});
  const [fromWeekName,setFromWeekName]=useState('');
  const [toWeekName,setToWeekName]=useState('');
  const [periodLoading,setPeriodLoading]=useState(true);
  const [generating,setGenerating]=useState('');
  const [error,setError]=useState('');
  const assignment=assignments.find(a=>a.id===assignmentId)||null;

  useEffect(()=>{setAssignmentId(current=>assignments.some(a=>a.id===current)?current:assignments[0]?.id||'');setMode(null);},[assignments]);
  useEffect(()=>{(async()=>{setPeriodLoading(true);setError('');try{const ctx=await loadPeriodContext(schoolId,assignments);setPeriodContext(ctx);const opts=ctx.periodOptions;setFromWeekName(v=>opts.includes(v)?v:(opts[0]||''));setToWeekName(v=>opts.includes(v)?v:(opts[opts.length-1]||''));}catch(err){setError(err.message||'تعذّر تحميل فترة التقارير.');}finally{setPeriodLoading(false);}})();},[schoolId,assignments]);

  if(mode==='student'&&assignment)return <StudentReport schoolId={schoolId} classId={assignment.classId} teacherUid={teacherUid} assignmentId={assignment.id} className={classNameFor(assignment.classId)} subject={assignment.subject||''} teacherName={teacherName} onBack={()=>setMode(null)}/>;
  if(mode==='class'&&assignment)return <ClassReport schoolId={schoolId} classId={assignment.classId} teacherUid={teacherUid} assignmentId={assignment.id} className={classNameFor(assignment.classId)} subject={assignment.subject||''} teacherName={teacherName} onBack={()=>setMode(null)}/>;

  async function downloadAllClasses(){if(generating||!fromWeekName||!toWeekName)return;setGenerating('classes');setError('');try{const data=await buildAllClassesAnalysisData(schoolId,{assignments,classes:assignments.map(a=>({id:a.classId,name:classNameFor(a.classId)})),teacherName,fromWeekName,toWeekName,periodContext});const blob=await pdf(<TeacherAllClassesReportDocument data={data}/>).toBlob();saveBlob(blob,`تحليل-نتائج-جميع-الفصول-${fromWeekName}-${toWeekName}.pdf`);}catch(err){setError(err.message||'تعذّر توليد تحليل جميع الفصول.');}finally{setGenerating('');}}
  async function downloadImpact(){if(generating||!fromWeekName||!toWeekName)return;setGenerating('impact');setError('');try{const data=await buildImpactReportData(schoolId,{assignments,classes:assignments.map(a=>({id:a.classId,name:classNameFor(a.classId)})),teacherName,fromWeekName,toWeekName,periodContext,audience:'teacher'});const blob=await pdf(<ImpactReportDocument data={data}/>).toBlob();saveBlob(blob,`تقرير-الأثر-العام-${fromWeekName}-${toWeekName}.pdf`);}catch(err){setError(err.message||'تعذّر توليد تقرير الأثر العام.');}finally{setGenerating('');}}

  const opts=periodContext.periodOptions||[];
  return <div style={{maxWidth:760,margin:'0 auto'}} dir="rtl">
    <h2 style={{fontFamily:font.family,color:colors.ink}}>التقارير</h2>
    {error&&<div style={{background:colors.redTint,color:colors.red,padding:10,borderRadius:radius.button,marginBottom:spacing.md}}>{error}</div>}
    {assignments.length===0?<p style={{color:colors.textMuted}}>لا توجد إسنادات نشطة لإعداد التقارير.</p>:<>
      <div style={{border:`1px solid ${colors.border}`,borderRadius:radius.card,padding:spacing.lg,marginBottom:spacing.md}}>
        <h3 style={{marginTop:0,fontFamily:font.family}}>التقارير الشاملة</h3>
        <p style={{fontSize:12,color:colors.textMuted,marginTop:0}}>حددي الفترة مرة واحدة، ثم اختاري التقرير المطلوب.</p>
        {periodLoading?<p style={{color:colors.textMuted,fontSize:13}}>جارٍ تحميل الأسابيع...</p>:opts.length===0?<p style={{color:colors.textMuted,fontSize:13}}>لا توجد أسابيع متاحة لإعداد التقارير الشاملة.</p>:<>
          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
            <label style={{flex:'1 1 170px',fontSize:13}}>من أسبوع<select value={fromWeekName} onChange={e=>setFromWeekName(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}>{opts.map(n=><option key={`f-${n}`} value={n}>{n}</option>)}</select></label>
            <label style={{flex:'1 1 170px',fontSize:13}}>إلى أسبوع<select value={toWeekName} onChange={e=>setToWeekName(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}>{opts.map(n=><option key={`t-${n}`} value={n}>{n}</option>)}</select></label>
          </div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <button onClick={downloadAllClasses} disabled={!!generating} style={{flex:'1 1 210px',padding:'10px 14px',background:colors.ink,color:'#fff',border:'none',borderRadius:radius.button,fontWeight:'bold'}}>{generating==='classes'?'جارٍ التوليد...':'تحليل نتائج جميع الفصول'}</button>
            <button onClick={downloadImpact} disabled={!!generating} style={{flex:'1 1 210px',padding:'10px 14px',background:colors.primary,color:'#fff',border:'none',borderRadius:radius.button,fontWeight:'bold'}}>{generating==='impact'?'جارٍ التوليد...':'تقرير الأثر العام'}</button>
          </div>
          <p style={{fontSize:11,color:colors.textMuted,marginBottom:0,marginTop:8}}>تقرير الأثر العام يضم القياس والمعالجة والتوصيات والخطط العلاجية ومؤشرات التحسن، ومهيأ للاستخدام كشاهد مهني.</p>
        </>}
      </div>
      <div style={{border:`1px solid ${colors.border}`,borderRadius:radius.card,padding:spacing.lg}}>
        <h3 style={{marginTop:0,fontFamily:font.family}}>تقارير الفصل والطالبة</h3>
        <label>المادة والفصل</label>
        <select value={assignmentId} onChange={e=>setAssignmentId(e.target.value)} style={{width:'100%',padding:10,margin:'6px 0 16px'}}>{assignments.map(a=><option key={a.id} value={a.id}>{a.subject||'بدون مادة'} — {classNameFor(a.classId)}</option>)}</select>
        <div style={{display:'flex',gap:10,flexWrap:'wrap'}}><button onClick={()=>setMode('student')} style={{flex:'1 1 180px',padding:'12px 16px',background:colors.primary,color:'#fff',border:'none',borderRadius:radius.button}}>تقرير طالبة</button><button onClick={()=>setMode('class')} style={{flex:'1 1 180px',padding:'12px 16px',background:colors.ink,color:'#fff',border:'none',borderRadius:radius.button}}>تقرير الفصل</button></div>
      </div>
    </>}
  </div>;
}
