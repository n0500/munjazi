import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from 'react';
import { exportSchoolBackupAsExcelBlob, exportSchoolBackupAsJsonBlob, downloadBlobAsFile } from '../lib/backupApi.js';
import { runSchoolIntegrityCheck } from '../lib/integrityApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';

function severityLabel(severity) {
    if (severity === 'critical') return 'حرجة';
    if (severity === 'warning') return 'تحتاج مراجعة';
    return 'معلومة';
}

function severityStyle(severity) {
    if (severity === 'critical') return { background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}` };
    if (severity === 'warning') return { background: '#fff8e5', color: '#7a5600', border: '1px solid #ead28d' };
    return { background: colors.primaryTint, color: '#0b5c33', border: `1px solid ${colors.border}` };
}

export default function AdminSafety({ schoolId, schoolName = '' }) {
    const [busy, setBusy] = useState('');
    const [error, setError] = useState('');
    const [msg, setMsg] = useState('');
    const [result, setResult] = useState(null);

    async function exportBackup(kind) {
        if (busy) return;
        setBusy(kind);
        setError('');
        setMsg('');
        try {
            const dateStr = new Date().toISOString().slice(0, 10);
            if (kind === 'json') {
                const blob = await exportSchoolBackupAsJsonBlob(schoolId);
                downloadBlobAsFile(blob, `منجزي-نسخة-احتياطية-${schoolName || 'المدرسة'}-${dateStr}.json`);
                setMsg('تم إنشاء نسخة JSON كاملة مخصصة للاستعادة الآمنة.');
            }
            else {
                const blob = await exportSchoolBackupAsExcelBlob(schoolId);
                downloadBlobAsFile(blob, `منجزي-نسخة-مراجعة-${schoolName || 'المدرسة'}-${dateStr}.xlsx`);
                setMsg('تم إنشاء نسخة Excel للمراجعة والاحتفاظ.');
            }
        }
        catch (err) {
            setError(err.message || 'تعذر إنشاء النسخة الاحتياطية.');
        }
        finally {
            setBusy('');
        }
    }

    async function runCheck() {
        if (busy) return;
        setBusy('scan');
        setError('');
        setMsg('');
        try {
            const check = await runSchoolIntegrityCheck(schoolId);
            setResult(check);
            if (check.counts.critical === 0 && check.counts.warning === 0)
                setMsg('اكتمل الفحص ولم يكتشف مشكلات في العلاقات الأساسية للبيانات.');
            else
                setMsg('اكتمل الفحص. النتائج أدناه للمراجعة فقط ولم يتم تعديل أي بيانات.');
        }
        catch (err) {
            setError(err.message || 'تعذر تنفيذ فحص سلامة البيانات.');
        }
        finally {
            setBusy('');
        }
    }

    const checkedAt = result?.checkedAt
        ? new Date(result.checkedAt).toLocaleString('ar-SA', { dateStyle: 'medium', timeStyle: 'short' })
        : '';

    return (_jsxs("div", { children: [
        _jsx("h2", { style: { fontFamily: font.family, marginTop: 0, color: colors.ink }, children: "النسخ الاحتياطي وسلامة البيانات" }),
        _jsx("p", { style: { color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "هذا القسم مخصص لحماية بيانات منجزي قبل أي توسع جديد. الفحص للقراءة فقط ولا يحذف أو يصلح أي سجل تلقائيًا." }),

        error && _jsx("div", { style: { background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}`, padding: 11, borderRadius: radius.button, marginBottom: spacing.md }, children: error }),
        msg && _jsx("div", { style: { background: colors.primaryTint, color: '#0b5c33', padding: 11, borderRadius: radius.button, marginBottom: spacing.md }, children: msg }),

        _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.lg, background: '#fff' }, children: [
            _jsx("h3", { style: { marginTop: 0, marginBottom: 6, fontFamily: font.family }, children: "1. نسخة احتياطية للمدرسة" }),
            _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "نسخة JSON هي النسخة المخصصة للاستعادة عند الحاجة، ونسخة Excel مناسبة للمراجعة البشرية. تشمل النسخة بيانات الرصد والخطط واطلاع أولياء الأمور وفهرس الدخول." }),
            _jsx("div", { style: { background: '#fff8e5', color: '#6f5100', border: '1px solid #ead28d', borderRadius: radius.button, padding: 10, fontSize: 12, marginBottom: spacing.md, lineHeight: 1.7 }, children: "تنبيه: النسخة الاحتياطية تحتوي على بيانات حساسة للطالبات، بما فيها السجل المدني عند توفره. احفظيها في مكان آمن ولا تشاركيها عبر قنوات عامة." }),
            _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: [
                _jsx("button", { onClick: () => exportBackup('json'), disabled: !!busy, style: { padding: '10px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontFamily: font.family }, children: busy === 'json' ? 'جارٍ الإنشاء...' : 'تنزيل نسخة JSON الآمنة' }),
                _jsx("button", { onClick: () => exportBackup('excel'), disabled: !!busy, style: { padding: '10px 14px', background: '#fff', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: radius.button, fontFamily: font.family }, children: busy === 'excel' ? 'جارٍ الإنشاء...' : 'تنزيل نسخة Excel' })
            ] }),
            _jsx("p", { style: { fontSize: 11, color: colors.textMuted, marginBottom: 0, lineHeight: 1.7 }, children: "لا تتضمن النسخة كلمات مرور Firebase Authentication. الاستعادة الآمنة لا تحذف ملفات حسابات المستخدمين الحالية." })
        ] }),

        _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, background: '#fff' }, children: [
            _jsx("h3", { style: { marginTop: 0, marginBottom: 6, fontFamily: font.family }, children: "2. فحص سلامة البيانات" }),
            _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "يفحص الإسنادات المكررة، الطالبات والفصول، الأسابيع والمهارات والرصد، الخطط العلاجية، سجلات اطلاع أولياء الأمور، وفهرس السجل المدني." }),
            _jsx("button", { onClick: runCheck, disabled: !!busy, style: { padding: '10px 16px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontFamily: font.family }, children: busy === 'scan' ? 'جارٍ فحص البيانات...' : 'فحص سلامة البيانات الآن' }),

            result && _jsxs(_Fragment, { children: [
                _jsx("div", { style: { marginTop: spacing.md, fontSize: 11, color: colors.textMuted }, children: `آخر فحص: ${checkedAt}` }),
                _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: spacing.sm }, children: [
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${result.counts.critical ? colors.redBorder : colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: result.counts.critical ? colors.red : '#0b5c33' }, children: result.counts.critical }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "مشكلة حرجة" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: result.counts.warning ? '#8a6500' : '#0b5c33' }, children: result.counts.warning }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "تحتاج مراجعة" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: colors.ink }, children: result.recordCounts.assessments }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "سجل رصد تم فحصه" })
                    ] })
                ] }),

                result.findings.length === 0
                    ? _jsx("div", { style: { marginTop: spacing.md, padding: 12, borderRadius: radius.button, background: colors.primaryTint, color: '#0b5c33' }, children: "✅ لم يكتشف الفحص أي تعارض أو سجل يتيم في العلاقات الأساسية." })
                    : _jsxs("div", { style: { marginTop: spacing.md }, children: [
                        _jsx("h4", { style: { marginBottom: 8, fontFamily: font.family }, children: "نتائج تحتاج المراجعة" }),
                        result.findings.map((item, index) => (_jsxs("div", { style: { ...severityStyle(item.severity), borderRadius: radius.button, padding: 10, marginBottom: 8 }, children: [
                            _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center', flexWrap: 'wrap' }, children: [
                                _jsx("strong", { style: { fontSize: 13 }, children: item.title }),
                                _jsx("span", { style: { fontSize: 10, fontWeight: 'bold' }, children: severityLabel(item.severity) })
                            ] }),
                            _jsx("div", { style: { fontSize: 12, marginTop: 4, lineHeight: 1.7 }, children: item.detail })
                        ] }, `${item.code}-${index}`)))
                    ] }),
                _jsx("p", { style: { marginBottom: 0, marginTop: spacing.md, fontSize: 11, color: colors.textMuted, lineHeight: 1.7 }, children: "الفحص لا يغيّر البيانات تلقائيًا. أي نتيجة تظهر نراجعها أولًا ثم نقرر إن كانت تحتاج إصلاحًا فعليًا." })
            ] })
        ] })
    ] }));
}
