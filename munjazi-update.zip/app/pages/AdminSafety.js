import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from 'react';
import { exportSchoolBackupAsExcelBlob, exportSchoolBackupAsJsonBlob, downloadBlobAsFile } from '../lib/backupApi.js';
import { runSchoolIntegrityCheck } from '../lib/integrityApi.js';
import { previewNationalIndexRepair, repairNationalIndex, exportNationalIndexSafetyBackupBlob } from '../lib/nationalIndexRepairApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';

function severityLabel(severity) {
    if (severity === 'critical') return 'حرجة';
    if (severity === 'warning') return 'تحتاج مراجعة';
    return 'معلومة';
}

function severityStyle(severity) {
    if (severity === 'critical') return { background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}` };
    if (severity === 'warning') return { background: '#fff8e5', color: '#7a5600', border: '1px solid #ead28d' };
    return { background: colors.primaryTint, color: '#0b5c33', border: `1px solid ${colors.border}` };
}

export default function AdminSafety({ schoolId, schoolName = '' }) {
    const [busy, setBusy] = useState('');
    const [error, setError] = useState('');
    const [msg, setMsg] = useState('');
    const [result, setResult] = useState(null);
    const [indexPreview, setIndexPreview] = useState(null);
    const [indexRepairResult, setIndexRepairResult] = useState(null);

    async function exportBackup(kind) {
        if (busy) return;
        setBusy(kind);
        setError('');
        setMsg('');
        try {
            const dateStr = new Date().toISOString().slice(0, 10);
            if (kind === 'json') {
                const blob = await exportSchoolBackupAsJsonBlob(schoolId);
                downloadBlobAsFile(blob, `منجزي-نسخة-احتياطية-${schoolName || 'المدرسة'}-${dateStr}.json`);
                setMsg('تم إنشاء نسخة JSON كاملة مخصصة للاستعادة الآمنة.');
            }
            else {
                const blob = await exportSchoolBackupAsExcelBlob(schoolId);
                downloadBlobAsFile(blob, `منجزي-نسخة-مراجعة-${schoolName || 'المدرسة'}-${dateStr}.xlsx`);
                setMsg('تم إنشاء نسخة Excel للمراجعة والاحتفاظ.');
            }
        }
        catch (err) {
            setError(err.message || 'تعذر إنشاء النسخة الاحتياطية.');
        }
        finally {
            setBusy('');
        }
    }

    async function runCheck() {
        if (busy) return;
        setBusy('scan');
        setError('');
        setMsg('');
        try {
            const check = await runSchoolIntegrityCheck(schoolId);
            setResult(check);
            if (check.counts.critical === 0 && check.counts.warning === 0)
                setMsg('اكتمل الفحص ولم يكتشف مشكلات في العلاقات الأساسية للبيانات.');
            else
                setMsg('اكتمل الفحص. النتائج أدناه للمراجعة فقط ولم يتم تعديل أي بيانات.');
        }
        catch (err) {
            setError(err.message || 'تعذر تنفيذ فحص سلامة البيانات.');
        }
        finally {
            setBusy('');
        }
    }


    async function previewIndexRepair() {
        if (busy) return;
        setBusy('index-preview');
        setError('');
        setMsg('');
        setIndexRepairResult(null);
        try {
            const preview = await previewNationalIndexRepair(schoolId);
            setIndexPreview(preview);
            if (preview.canApply) {
                if (preview.counts.create + preview.counts.update + preview.counts.remove === 0)
                    setMsg('فهرس السجل المدني مطابق حاليًا لبيانات الطالبات ولا يحتاج إصلاحًا.');
                else
                    setMsg('تمت المعاينة فقط. لم يتم تعديل أي بيانات بعد.');
            }
            else {
                setMsg('تمت المعاينة. يوجد تعارض يمنع الإصلاح التلقائي حتى تتم مراجعته.');
            }
        }
        catch (err) {
            setError(err.message || 'تعذر معاينة فهرس السجل المدني.');
        }
        finally {
            setBusy('');
        }
    }

    async function applyIndexRepair() {
        if (busy || !indexPreview?.canApply) return;

        const changes = indexPreview.counts.create + indexPreview.counts.update + indexPreview.counts.remove;
        if (changes === 0) {
            setMsg('الفهرس لا يحتاج أي تعديل.');
            return;
        }

        const ok = window.confirm(
            `سيتم إصلاح فهرس دخول أولياء الأمور فقط.\n\n` +
            `إضافة فهارس مفقودة: ${indexPreview.counts.create}\n` +
            `تصحيح فهارس: ${indexPreview.counts.update}\n` +
            `حذف فهارس قديمة/يتيمة: ${indexPreview.counts.remove}\n\n` +
            `لن يتم تعديل الطالبات أو الرصد أو المهارات أو الأسابيع أو المعلمات.\n\n` +
            `هل تريدين المتابعة؟`
        );
        if (!ok) return;

        setBusy('index-repair');
        setError('');
        setMsg('');
        try {
            // نسخة أمان صغيرة ومخصصة للفهرس قبل أي كتابة.
            const backupBlob = await exportNationalIndexSafetyBackupBlob(schoolId);
            const dateStr = new Date().toISOString().slice(0, 10);
            downloadBlobAsFile(
                backupBlob,
                `منجزي-نسخة-أمان-فهرس-السجل-${schoolName || 'المدرسة'}-${dateStr}.json`
            );

            const repaired = await repairNationalIndex(schoolId);
            setIndexRepairResult(repaired);
            setIndexPreview(repaired.after);

            if (repaired.verified) {
                setMsg(
                    `تم إصلاح فهرس السجل المدني والتحقق منه بنجاح: ` +
                    `${repaired.writes.updated} تصحيح، ${repaired.writes.created} إضافة، ` +
                    `${repaired.writes.removed} حذف لفهرس قديم. لم يتم تعديل بيانات الرصد أو الطالبات.`
                );
            }
            else {
                setMsg('تم تنفيذ الإصلاح، لكن ما زالت هناك نتيجة تحتاج مراجعة. شغّلي المعاينة مرة أخرى قبل أي إجراء إضافي.');
            }
        }
        catch (err) {
            if (err.preview) setIndexPreview(err.preview);
            setError(err.message || 'تعذر إصلاح فهرس السجل المدني.');
        }
        finally {
            setBusy('');
        }
    }

    const checkedAt = result?.checkedAt
        ? new Date(result.checkedAt).toLocaleString('ar-SA', { dateStyle: 'medium', timeStyle: 'short' })
        : '';

    return (_jsxs("div", { children: [
        _jsx("h2", { style: { fontFamily: font.family, marginTop: 0, color: colors.ink }, children: "النسخ الاحتياطي وسلامة البيانات" }),
        _jsx("p", { style: { color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "هذا القسم مخصص لحماية بيانات منجزي قبل أي توسع جديد. الفحص للقراءة فقط ولا يحذف أو يصلح أي سجل تلقائيًا." }),

        error && _jsx("div", { style: { background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}`, padding: 11, borderRadius: radius.button, marginBottom: spacing.md }, children: error }),
        msg && _jsx("div", { style: { background: colors.primaryTint, color: '#0b5c33', padding: 11, borderRadius: radius.button, marginBottom: spacing.md }, children: msg }),

        _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.lg, background: '#fff' }, children: [
            _jsx("h3", { style: { marginTop: 0, marginBottom: 6, fontFamily: font.family }, children: "1. نسخة احتياطية للمدرسة" }),
            _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "نسخة JSON هي النسخة المخصصة للاستعادة عند الحاجة، ونسخة Excel مناسبة للمراجعة البشرية. تشمل النسخة بيانات الرصد والخطط واطلاع أولياء الأمور وفهرس الدخول." }),
            _jsx("div", { style: { background: '#fff8e5', color: '#6f5100', border: '1px solid #ead28d', borderRadius: radius.button, padding: 10, fontSize: 12, marginBottom: spacing.md, lineHeight: 1.7 }, children: "تنبيه: النسخة الاحتياطية تحتوي على بيانات حساسة للطالبات، بما فيها السجل المدني عند توفره. احفظيها في مكان آمن ولا تشاركيها عبر قنوات عامة." }),
            _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: [
                _jsx("button", { onClick: () => exportBackup('json'), disabled: !!busy, style: { padding: '10px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontFamily: font.family }, children: busy === 'json' ? 'جارٍ الإنشاء...' : 'تنزيل نسخة JSON الآمنة' }),
                _jsx("button", { onClick: () => exportBackup('excel'), disabled: !!busy, style: { padding: '10px 14px', background: '#fff', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: radius.button, fontFamily: font.family }, children: busy === 'excel' ? 'جارٍ الإنشاء...' : 'تنزيل نسخة Excel' })
            ] }),
            _jsx("p", { style: { fontSize: 11, color: colors.textMuted, marginBottom: 0, lineHeight: 1.7 }, children: "لا تتضمن النسخة كلمات مرور Firebase Authentication. الاستعادة الآمنة لا تحذف ملفات حسابات المستخدمين الحالية." })
        ] }),

        _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, background: '#fff' }, children: [
            _jsx("h3", { style: { marginTop: 0, marginBottom: 6, fontFamily: font.family }, children: "2. فحص سلامة البيانات" }),
            _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "يفحص الإسنادات المكررة، الطالبات والفصول، الأسابيع والمهارات والرصد، الخطط العلاجية، سجلات اطلاع أولياء الأمور، وفهرس السجل المدني." }),
            _jsx("button", { onClick: runCheck, disabled: !!busy, style: { padding: '10px 16px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontFamily: font.family }, children: busy === 'scan' ? 'جارٍ فحص البيانات...' : 'فحص سلامة البيانات الآن' }),

            result && _jsxs(_Fragment, { children: [
                _jsx("div", { style: { marginTop: spacing.md, fontSize: 11, color: colors.textMuted }, children: `آخر فحص: ${checkedAt}` }),
                _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: spacing.sm }, children: [
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${result.counts.critical ? colors.redBorder : colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: result.counts.critical ? colors.red : '#0b5c33' }, children: result.counts.critical }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "مشكلة حرجة" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: result.counts.warning ? '#8a6500' : '#0b5c33' }, children: result.counts.warning }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "تحتاج مراجعة" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 120px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 10, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 23, fontWeight: 'bold', color: colors.ink }, children: result.recordCounts.assessments }),
                        _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: "سجل رصد تم فحصه" })
                    ] })
                ] }),

                result.findings.length === 0
                    ? _jsx("div", { style: { marginTop: spacing.md, padding: 12, borderRadius: radius.button, background: colors.primaryTint, color: '#0b5c33' }, children: "✅ لم يكتشف الفحص أي تعارض أو سجل يتيم في العلاقات الأساسية." })
                    : _jsxs("div", { style: { marginTop: spacing.md }, children: [
                        _jsx("h4", { style: { marginBottom: 8, fontFamily: font.family }, children: "نتائج تحتاج المراجعة" }),
                        result.findings.map((item, index) => (_jsxs("div", { style: { ...severityStyle(item.severity), borderRadius: radius.button, padding: 10, marginBottom: 8 }, children: [
                            _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center', flexWrap: 'wrap' }, children: [
                                _jsx("strong", { style: { fontSize: 13 }, children: item.title }),
                                _jsx("span", { style: { fontSize: 10, fontWeight: 'bold' }, children: severityLabel(item.severity) })
                            ] }),
                            _jsx("div", { style: { fontSize: 12, marginTop: 4, lineHeight: 1.7 }, children: item.detail })
                        ] }, `${item.code}-${index}`)))
                    ] }),
                _jsx("p", { style: { marginBottom: 0, marginTop: spacing.md, fontSize: 11, color: colors.textMuted, lineHeight: 1.7 }, children: "الفحص لا يغيّر البيانات تلقائيًا. أي نتيجة تظهر نراجعها أولًا ثم نقرر إن كانت تحتاج إصلاحًا فعليًا." })
            ] })
        ] }),

        _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, background: '#fff', marginTop: spacing.lg }, children: [
            _jsx("h3", { style: { marginTop: 0, marginBottom: 6, fontFamily: font.family }, children: "3. إصلاح فهرس السجل المدني" }),
            _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.8 }, children: "هذه الأداة تصلح دليل دخول ولي الأمر فقط (studentsByNationalId). لا تعدل سجل الطالبة، الفصل، الرصد، المهارات، الأسابيع، التقارير أو حسابات المعلمات." }),
            _jsx("div", { style: { background: '#fff8e5', color: '#6f5100', border: '1px solid #ead28d', borderRadius: radius.button, padding: 10, fontSize: 12, marginBottom: spacing.md, lineHeight: 1.8 }, children: "ابدئي بالمعاينة. الإصلاح لا يتاح إذا وجد سجل مدني مكرر أو غير صالح أو مرتبط بمدرسة أخرى. وقبل التنفيذ تُنزّل نسخة أمان صغيرة تلقائيًا." }),
            _jsx("button", {
                onClick: previewIndexRepair,
                disabled: !!busy,
                style: { padding: '10px 16px', background: '#fff', color: colors.primary, border: `1px solid ${colors.primary}`, borderRadius: radius.button, fontFamily: font.family },
                children: busy === 'index-preview' ? 'جارٍ تجهيز المعاينة...' : 'معاينة إصلاح الفهرس'
            }),

            indexPreview && _jsxs(_Fragment, { children: [
                _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: spacing.md }, children: [
                    _jsxs("div", { style: { flex: '1 1 105px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 9, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 21, fontWeight: 'bold', color: '#0b5c33' }, children: indexPreview.counts.unchanged }),
                        _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: "سليم كما هو" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 105px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 9, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 21, fontWeight: 'bold', color: colors.primary }, children: indexPreview.counts.create }),
                        _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: "فهرس مفقود" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 105px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 9, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 21, fontWeight: 'bold', color: '#8a6500' }, children: indexPreview.counts.update }),
                        _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: "سيتم تصحيحه" })
                    ] }),
                    _jsxs("div", { style: { flex: '1 1 105px', border: `1px solid ${colors.border}`, borderRadius: radius.button, padding: 9, textAlign: 'center' }, children: [
                        _jsx("div", { style: { fontSize: 21, fontWeight: 'bold', color: colors.red }, children: indexPreview.counts.remove }),
                        _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: "فهرس قديم سيحذف" })
                    ] })
                ] }),

                indexPreview.blockers.length > 0 && _jsxs("div", { style: { marginTop: spacing.md }, children: [
                    _jsx("strong", { style: { color: colors.red, fontSize: 13 }, children: "تعارضات تمنع الإصلاح التلقائي:" }),
                    indexPreview.blockers.map((item, i) => _jsx("div", {
                        style: { background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}`, borderRadius: radius.button, padding: 9, marginTop: 6, fontSize: 12, lineHeight: 1.7 },
                        children: item.text
                    }, `blocker-${i}`))
                ] }),

                indexPreview.warnings.length > 0 && _jsxs("details", { style: { marginTop: spacing.md }, children: [
                    _jsx("summary", { style: { cursor: 'pointer', color: '#7a5600', fontWeight: 600, fontSize: 12 }, children: `ملاحظات غير مانعة (${indexPreview.warnings.length})` }),
                    _jsx("div", { style: { marginTop: 6 }, children: indexPreview.warnings.slice(0, 25).map((item, i) => _jsx("div", {
                        style: { background: '#fff8e5', color: '#6f5100', border: '1px solid #ead28d', borderRadius: radius.button, padding: 8, marginTop: 5, fontSize: 11, lineHeight: 1.7 },
                        children: item.text
                    }, `warning-${i}`)) })
                ] }),

                (indexPreview.create.length > 0 || indexPreview.update.length > 0) && _jsxs("details", { style: { marginTop: spacing.md }, children: [
                    _jsx("summary", { style: { cursor: 'pointer', color: colors.ink, fontWeight: 600, fontSize: 12 }, children: "عرض أمثلة من الفهارس التي ستُنشأ أو تُصحح" }),
                    _jsx("div", { style: { marginTop: 6 }, children: [...indexPreview.update, ...indexPreview.create].slice(0, 30).map((item, i) => _jsxs("div", {
                        style: { borderBottom: `1px solid ${colors.border}`, padding: '7px 2px', fontSize: 11, lineHeight: 1.6 },
                        children: [
                            _jsx("strong", { children: item.studentName }),
                            _jsx("span", { style: { color: colors.textMuted, marginRight: 6 }, children: ` — ${item.nationalIdMasked}` })
                        ]
                    }, `change-${i}`)) })
                ] }),

                _jsx("button", {
                    onClick: applyIndexRepair,
                    disabled: !!busy || !indexPreview.canApply || (indexPreview.counts.create + indexPreview.counts.update + indexPreview.counts.remove === 0),
                    style: {
                        marginTop: spacing.md,
                        padding: '10px 16px',
                        background: indexPreview.canApply ? colors.primary : '#bbb',
                        color: '#fff',
                        border: 'none',
                        borderRadius: radius.button,
                        fontFamily: font.family,
                        opacity: (indexPreview.counts.create + indexPreview.counts.update + indexPreview.counts.remove === 0) ? 0.6 : 1
                    },
                    children: busy === 'index-repair' ? 'جارٍ الإصلاح والتحقق...' : 'إصلاح فهرس السجل المدني الآن'
                }),

                indexRepairResult?.verified && _jsx("div", {
                    style: { marginTop: spacing.md, background: colors.primaryTint, color: '#0b5c33', borderRadius: radius.button, padding: 10, fontSize: 12, lineHeight: 1.8 },
                    children: "✓ تم التحقق بعد التنفيذ: الفهارس الحالية مطابقة لبيانات الطالبات. يمكنك الآن تشغيل فحص سلامة البيانات مرة أخرى لتحديث العدد الأحمر."
                })
            ] })
        ] })
    ] }));
}
