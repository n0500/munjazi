import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { listActionsForTeacher } from '../lib/actionEngine.js';
import { listClasses, listTeacherAssignments } from '../lib/classesApi.js';
import { normalizeSubject } from '../lib/dataLogic.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const TYPE_LABEL = {
    remedial: { icon: '⚠', text: 'علاجي' },
    enrichment: { icon: '⭐', text: 'إثرائي' },
};
function formatDate(value) {
    if (!value)
        return '—';
    try {
        const date = value.toDate ? value.toDate() : new Date(value);
        return date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' });
    }
    catch {
        return '—';
    }
}
function formatDateTime(value) {
    if (!value)
        return null;
    try {
        const date = value.toDate ? value.toDate() : new Date(value);
        return date.toLocaleString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }
    catch {
        return null;
    }
}
function StatCard({ value, label, bg, border, text }) {
    return (_jsxs("div", { style: { flex: '1 1 90px', textAlign: 'center', border: `1px solid ${border}`, borderRadius: radius.card, padding: '10px 4px', background: bg }, children: [_jsx("div", { style: { fontSize: 20, fontWeight: 'bold', color: text }, children: value }), _jsx("div", { style: { fontSize: 11, color: text }, children: label })] }));
}
export default function AckTracking({ schoolId, teacherUid, onBack = null }) {
    const [actions, setActions] = useState([]);
    const [classNames, setClassNames] = useState({});
    const [assignments, setAssignments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [filter, setFilter] = useState('all');
    useEffect(() => {
        (async () => {
            setLoading(true);
            setError('');
            try {
                const [actionRows, classRows, assignRows] = await Promise.all([
                    listActionsForTeacher(schoolId, teacherUid),
                    listClasses(schoolId),
                    listTeacherAssignments(schoolId, teacherUid, { includeInactive: true }),
                ]);
                const activeOnly = actionRows.filter((a) => a.status === 'active');
                activeOnly.sort((a, b) => (b.activatedAt?.seconds || 0) - (a.activatedAt?.seconds || 0));
                setActions(activeOnly);
                setAssignments(assignRows);
                setClassNames(Object.fromEntries(classRows.map((c) => [c.id, c.name])));
            }
            catch (err) {
                setError(err.message || 'تعذر تحميل بيانات المتابعة.');
            }
            finally {
                setLoading(false);
            }
        })();
    }, [schoolId, teacherUid]);
    function subjectForAction(a) {
        if (a.subject)
            return a.subject;
        if (a.assignmentId)
            return assignments.find((x) => x.id === a.assignmentId)?.subject || 'مادة غير محددة';
        const sameClass = assignments.filter((x) => x.classId === a.classId);
        const distinctSubjects = new Map();
        sameClass.forEach((x) => {
            const key = normalizeSubject(x.subject);
            if (!distinctSubjects.has(key))
                distinctSubjects.set(key, x.subject || 'بدون مادة');
        });
        return distinctSubjects.size === 1 ? [...distinctSubjects.values()][0] : 'مادة غير محددة';
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    const isRepeated = (a) => (a.followUpLog?.length || 0) > 0;
    const remedialActions = actions.filter((a) => a.type === 'remedial');
    const viewedCount = remedialActions.filter((a) => a.parentAcknowledgment?.viewedAt).length;
    const pendingCount = remedialActions.length - viewedCount;
    const viewRate = remedialActions.length > 0 ? Math.round((viewedCount / remedialActions.length) * 100) : null;
    const repeatedPendingCount = remedialActions.filter((a) => isRepeated(a) && !a.parentAcknowledgment?.viewedAt).length;
    const filteredActions = actions.filter((a) => {
        if (filter === 'remedial')
            return a.type === 'remedial';
        if (filter === 'pending')
            return a.type === 'remedial' && !a.parentAcknowledgment?.viewedAt;
        if (filter === 'repeatedPending')
            return a.type === 'remedial' && isRepeated(a) && !a.parentAcknowledgment?.viewedAt;
        return true;
    });
    return (_jsxs("div", { style: { maxWidth: 760, margin: '0 auto', padding: spacing.lg }, dir: "rtl", children: [onBack && _jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629" }), _jsx("h2", { style: { fontFamily: font.family, color: colors.ink }, children: "اطلاع ولي الأمر على الخطط العلاجية" }), _jsx("p", { style: { color: colors.textMuted, fontSize: 13 }, children: "هذا القسم خاص بالخطط العلاجية التي أنشأتها المعلمة. أما المهارات غير المتقنة والتي تحتاج متابعة فتظهر في القسم أعلاه." }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), remedialActions.length > 0 && (_jsxs("div", { style: { display: 'flex', gap: spacing.sm, flexWrap: 'wrap', marginBottom: spacing.lg }, children: [_jsx(StatCard, { value: viewedCount, label: "\u0627\u0637\u0644\u0639\u0648\u0627", bg: colors.primaryTint, border: colors.primary, text: "#0b5c33" }), _jsx(StatCard, { value: pendingCount, label: "\u0644\u0645 \u064A\u0637\u0644\u0639\u0648\u0627 \u0628\u0639\u062F", bg: colors.redTint, border: colors.redBorder, text: colors.red }), _jsx(StatCard, { value: viewRate !== null ? `${viewRate}٪` : '—', label: "\u0646\u0633\u0628\u0629 \u0627\u0644\u0627\u0637\u0644\u0627\u0639", bg: "#eef2f7", border: "#a9c0d9", text: "#3d5a80" })] })), repeatedPendingCount > 0 && (_jsxs("div", { style: { background: colors.redTint, border: `1px solid ${colors.redBorder}`, color: colors.red, borderRadius: radius.button, padding: spacing.md, marginBottom: spacing.lg, fontSize: 13 }, children: [_jsx("strong", { children: "\u26A0 \u0623\u0648\u0644\u0648\u064A\u0629:" }), " \u062A\u0648\u062C\u062F ", repeatedPendingCount, " \u062D\u0627\u0644\u0627\u062A \u0645\u062A\u0643\u0631\u0631\u0629 \u0644\u0645 \u064A\u0637\u0644\u0639 \u0648\u0644\u064A \u0623\u0645\u0631\u0647\u0627 \u0628\u0639\u062F."] })), _jsx("div", { style: { display: 'flex', gap: 6, marginBottom: spacing.lg, flexWrap: 'wrap' }, children: [
                    { key: 'all', label: `الكل (${actions.length})` },
                    { key: 'remedial', label: 'علاجي فقط' },
                    { key: 'pending', label: `لم يطلع بعد (${pendingCount})` },
                    { key: 'repeatedPending', label: `متكررة ولم يطلع (${repeatedPendingCount})` },
                ].map((f) => (_jsx("button", { onClick: () => setFilter(f.key), style: { padding: '6px 14px', borderRadius: radius.pill, fontSize: 12, border: filter === f.key ? 'none' : `1px solid ${colors.border}`, background: filter === f.key ? colors.primary : '#fff', color: filter === f.key ? '#fff' : '#555' }, children: f.label }, f.key))) }), filteredActions.length === 0 ? _jsx("p", { style: { color: colors.textMuted, textAlign: 'center' }, children: "لا توجد خطط علاجية تطابق هذا الفلتر." }) : (_jsx("div", { style: { overflowX: 'auto' }, children: _jsxs("table", { style: { width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: 680 }, children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { style: { textAlign: 'right', borderBottom: `2px solid ${colors.border}`, padding: 8 }, children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }), _jsx("th", { style: { textAlign: 'right', borderBottom: `2px solid ${colors.border}`, padding: 8 }, children: "\u0627\u0644\u0645\u0627\u062F\u0629 \u0648\u0627\u0644\u0641\u0635\u0644" }), _jsx("th", { style: { textAlign: 'right', borderBottom: `2px solid ${colors.border}`, padding: 8 }, children: "\u0627\u0644\u0625\u062C\u0631\u0627\u0621" }), _jsx("th", { style: { textAlign: 'right', borderBottom: `2px solid ${colors.border}`, padding: 8 }, children: "\u0627\u0644\u062A\u0641\u0639\u064A\u0644" }), _jsx("th", { style: { textAlign: 'right', borderBottom: `2px solid ${colors.border}`, padding: 8 }, children: "\u0627\u0644\u0627\u0637\u0644\u0627\u0639" })] }) }), _jsx("tbody", { children: filteredActions.map((a) => {
                                const label = TYPE_LABEL[a.type];
                                const ackAt = formatDateTime(a.parentAcknowledgment?.viewedAt);
                                const repeated = isRepeated(a);
                                const urgent = a.type === 'remedial' && repeated && !ackAt;
                                return (_jsxs("tr", { style: { borderBottom: '1px solid #f0f0f0', background: urgent ? colors.redTint : 'transparent' }, children: [_jsx("td", { style: { padding: 8 }, children: a.studentName }), _jsxs("td", { style: { padding: 8 }, children: [subjectForAction(a), " \u2014 ", classNames[a.classId] || '؟'] }), _jsxs("td", { style: { padding: 8 }, children: [label.icon, " ", a.affectedSkillTitles?.join('، '), " ", repeated && a.type === 'remedial' ? _jsx("span", { style: { fontSize: 10, background: colors.red, color: '#fff', borderRadius: 4, padding: '1px 5px' }, children: "\u0645\u062A\u0643\u0631\u0631\u0629" }) : null] }), _jsx("td", { style: { padding: 8 }, children: formatDate(a.activatedAt) }), _jsx("td", { style: { padding: 8 }, children: a.type !== 'remedial' ? '—' : ackAt ? _jsxs("span", { style: { color: '#0b5c33' }, children: ["\u2713 ", ackAt] }) : _jsx("span", { style: { color: colors.red }, children: "\u23F3 \u0644\u0645 \u064A\u0637\u0644\u0639 \u0628\u0639\u062F" }) })] }, a.id));
                            }) })] }) }))] }));
}
