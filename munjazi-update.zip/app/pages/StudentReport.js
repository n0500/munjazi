import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import { listWeeksForClass } from '../lib/weeksApi.js';
import { buildStudentReportData, listHistoricalStudentsForAssignment } from '../lib/reportsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
import StudentReportDocument from './StudentReportDocument.js';
async function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
export default function StudentReport({ schoolId, classId, teacherUid, assignmentId, className, subject, teacherName, onBack, }) {
    const [students, setStudents] = useState([]);
    const [weeks, setWeeks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [studentId, setStudentId] = useState('');
    const [fromWeekId, setFromWeekId] = useState('');
    const [toWeekId, setToWeekId] = useState('');
    const [generating, setGenerating] = useState(false);
    useEffect(() => {
        (async () => {
            setLoading(true);
            setError('');
            try {
                const [studentRows, weekRows] = await Promise.all([
                    listHistoricalStudentsForAssignment(schoolId, { classId, teacherUid, assignmentId, subject }),
                    listWeeksForClass(schoolId, classId, teacherUid, assignmentId),
                ]);
                setStudents(studentRows);
                setWeeks(weekRows);
            }
            catch (err) {
                setError(err.message || 'تعذّر تحميل البيانات.');
            }
            finally {
                setLoading(false);
            }
        })();
    }, [schoolId, classId, teacherUid, assignmentId, subject]);
    async function handleGenerate(e) {
        e.preventDefault();
        setError('');
        if (!studentId || !fromWeekId || !toWeekId)
            return;
        setGenerating(true);
        try {
            const student = students.find((s) => s.id === studentId);
            const data = await buildStudentReportData(schoolId, {
                classId,
                teacherUid,
                assignmentId,
                student,
                className,
                subject,
                teacherName,
                fromWeekId,
                toWeekId,
            });
            const blob = await pdf(_jsx(StudentReportDocument, { data: data })).toBlob();
            await downloadBlob(blob, `تقرير-${student.name}.pdf`);
        }
        catch (err) {
            setError(err.message || 'تعذّر توليد التقرير.');
        }
        finally {
            setGenerating(false);
        }
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    return (_jsxs("div", { style: { maxWidth: 600, margin: '20px auto', padding: spacing.lg }, dir: "rtl", children: [onBack && _jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629" }), _jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u062A\u0642\u0631\u064A\u0631 \u0637\u0627\u0644\u0628\u0629" }), _jsxs("p", { style: { color: colors.textMuted, fontSize: 13 }, children: [className, " \u2014 ", subject] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), _jsxs("form", { onSubmit: handleGenerate, style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg }, children: [_jsx("label", { children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }), _jsxs("select", { value: studentId, onChange: (e) => setStudentId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0637\u0627\u0644\u0628\u0629" }), students.map((s) => _jsx("option", { value: s.id, children: s.name }, s.id))] }), _jsx("label", { children: "\u0645\u0646 \u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: fromWeekId, onChange: (e) => setFromWeekId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0623\u0633\u0628\u0648\u0639" }), weeks.map((w) => _jsxs("option", { value: w.id, children: [w.name, " (", w.type === 'remediation' ? 'معالجة' : 'قياس', ")"] }, w.id))] }), _jsx("label", { children: "\u0625\u0644\u0649 \u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: toWeekId, onChange: (e) => setToWeekId(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm }, required: true, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0623\u0633\u0628\u0648\u0639" }), weeks.map((w) => _jsxs("option", { value: w.id, children: [w.name, " (", w.type === 'remediation' ? 'معالجة' : 'قياس', ")"] }, w.id))] }), _jsx("button", { type: "submit", disabled: generating, style: { padding: '10px 16px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: generating ? '...جارٍ التوليد' : 'توليد التقرير وتحميله' })] })] }));
}
