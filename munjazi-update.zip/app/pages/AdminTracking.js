import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { useEffect, useMemo, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import * as XLSX from 'xlsx';
import { listWeeksForAssignmentGroup } from '../lib/weeksApi.js';
import { getWeekSummaryLight } from '../lib/overviewApi.js';
import TrackingReportDocument from './TrackingReportDocument.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const TYPE_LABELS = { measurement: 'قياس', remediation: 'معالجة' };
const weekKey = (w) => `${w?.name || ''}__${w?.type || ''}`;
function statusFor(row) { if (!row.week || !row.summary || row.summary.completionPercent === 0)
    return 'لم يتم الرصد'; if (row.summary.completionPercent < 100)
    return 'جاري الرصد'; return 'مكتمل'; }
function masteryFor(summary) { if (!summary)
    return null; const c = summary.counts || {}; const assessed = (c.mastered || 0) + (c.needsSupport || 0) + (c.notMastered || 0); return assessed ? Math.round((c.mastered || 0) / assessed * 100) : null; }
function saveBlob(blob, name) { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }
export default function AdminTracking({ schoolId, assignments, classes, schoolName, onReport }) {
    const [weekLists, setWeekLists] = useState({});
    const [selectedWeekKey, setSelectedWeekKey] = useState('latest');
    const [statusFilter, setStatusFilter] = useState('all');
    const [search, setSearch] = useState('');
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [exporting, setExporting] = useState(false);
    const classNameFor = (id) => classes.find((c) => c.id === id)?.name || '؟';
    useEffect(() => { (async () => { setLoading(true); setError(''); try {
        const entries = await Promise.all(assignments.map(async (a) => [a.id, await listWeeksForAssignmentGroup(schoolId, a)]));
        setWeekLists(Object.fromEntries(entries));
    }
    catch (err) {
        setError(err.message || 'تعذّر تحميل أسابيع المتابعة.');
    }
    finally {
        setLoading(false);
    } })(); }, [schoolId, assignments]);
    const weekOptions = useMemo(() => { const map = new Map(); Object.values(weekLists).flat().forEach((w) => { if (w.archived)
        return; const k = weekKey(w); if (!map.has(k))
        map.set(k, { key: k, name: w.name, type: w.type }); }); return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'ar')); }, [weekLists]);
    useEffect(() => { if (loading)
        return; (async () => { setLoading(true); setError(''); try {
        const out = await Promise.all(assignments.map(async (a) => { const list = (weekLists[a.id] || []).filter((w) => !w.archived); const week = selectedWeekKey === 'latest' ? (list[0] || null) : (list.find((w) => weekKey(w) === selectedWeekKey) || null); const summary = week ? await getWeekSummaryLight(schoolId, a.classId, week) : null; return { assignment: a, week, summary, className: classNameFor(a.classId), masteryPercent: masteryFor(summary) }; }));
        setRows(out);
    }
    catch (err) {
        setError(err.message || 'تعذّر تحميل متابعة الرصد.');
    }
    finally {
        setLoading(false);
    } })(); }, [selectedWeekKey, weekLists, assignments]);
    const filtered = useMemo(() => rows.filter(r => { const st = statusFor(r); if (statusFilter !== 'all' && st !== statusFilter)
        return false; const q = search.trim().toLowerCase(); if (q && !`${r.assignment.teacherName || ''} ${r.assignment.subject || ''} ${r.className}`.toLowerCase().includes(q))
        return false; return true; }), [rows, statusFilter, search]);
    const grouped = useMemo(() => { const map = new Map(); filtered.forEach(r => { const key = r.assignment.teacherUid || r.assignment.teacherName || 'unknown'; if (!map.has(key))
        map.set(key, []); map.get(key).push(r); }); return [...map.entries()].map(([key, items]) => ({ key, teacherName: items[0]?.assignment.teacherName || 'معلمة', items })).sort((a, b) => a.teacherName.localeCompare(b.teacherName, 'ar')); }, [filtered]);
    const selectedLabel = selectedWeekKey === 'latest' ? 'آخر أسبوع لكل فصل' : (weekOptions.find(w => w.key === selectedWeekKey) ? `${weekOptions.find(w => w.key === selectedWeekKey).name} — ${TYPE_LABELS[weekOptions.find(w => w.key === selectedWeekKey).type]}` : 'كل الأسابيع');
    const reportRows = filtered.map(r => ({ assignmentId: r.assignment.id, teacherName: r.assignment.teacherName || '—', subject: r.assignment.subject || 'بدون مادة', className: r.className, weekName: r.week?.name || '—', weekTypeLabel: r.week ? TYPE_LABELS[r.week.type] : '—', completionPercent: r.summary?.completionPercent || 0, masteryPercent: r.masteryPercent, trackingStatus: statusFor(r) }));
    async function exportPdf() { if (!reportRows.length)
        return; setExporting(true); try {
        const blob = await pdf(_jsx(TrackingReportDocument, { schoolName: schoolName, rows: reportRows, filterLabel: `${selectedLabel} · ${statusFilter === 'all' ? 'كل حالات الرصد' : statusFilter}`, generatedDate: new Date().toLocaleDateString('ar-SA') })).toBlob();
        saveBlob(blob, `تقرير_متابعة_الرصد_${new Date().toISOString().slice(0, 10)}.pdf`);
    }
    finally {
        setExporting(false);
    } }
    function exportExcel() { if (!reportRows.length)
        return; const data = reportRows.map((r, i) => ({ 'م': i + 1, 'المعلمة': r.teacherName, 'المادة': r.subject, 'الفصل': r.className, 'الأسبوع': r.weekName, 'النوع': r.weekTypeLabel, 'اكتمال الرصد': `${r.completionPercent}%`, 'نسبة الإتقان': r.masteryPercent == null ? '—' : `${r.masteryPercent}%`, 'الحالة': r.trackingStatus })); const ws = XLSX.utils.json_to_sheet(data); ws['!cols'] = [{ wch: 5 }, { wch: 22 }, { wch: 18 }, { wch: 16 }, { wch: 16 }, { wch: 10 }, { wch: 16 }, { wch: 16 }, { wch: 16 }]; const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'متابعة الرصد'); XLSX.writeFile(wb, `تقرير_متابعة_الرصد_${new Date().toISOString().slice(0, 10)}.xlsx`); }
    return _jsxs("div", { dir: "rtl", children: [_jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'end', marginBottom: spacing.md }, children: [_jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 12, color: colors.textMuted, marginBottom: 4 }, children: "\u0627\u0644\u0623\u0633\u0628\u0648\u0639" }), _jsxs("select", { value: selectedWeekKey, onChange: e => setSelectedWeekKey(e.target.value), style: { padding: '8px 10px', border: `1px solid ${colors.border}`, borderRadius: 8, minWidth: 190 }, children: [_jsx("option", { value: "latest", children: "\u0622\u062E\u0631 \u0623\u0633\u0628\u0648\u0639 \u0644\u0643\u0644 \u0641\u0635\u0644" }), weekOptions.map(w => _jsxs("option", { value: w.key, children: [w.name, " \u2014 ", TYPE_LABELS[w.type]] }, w.key))] })] }), _jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 12, color: colors.textMuted, marginBottom: 4 }, children: "\u062D\u0627\u0644\u0629 \u0627\u0644\u0631\u0635\u062F" }), _jsxs("select", { value: statusFilter, onChange: e => setStatusFilter(e.target.value), style: { padding: '8px 10px', border: `1px solid ${colors.border}`, borderRadius: 8 }, children: [_jsx("option", { value: "all", children: "\u0627\u0644\u0643\u0644" }), _jsx("option", { value: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0631\u0635\u062F", children: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0631\u0635\u062F" }), _jsx("option", { value: "\u062C\u0627\u0631\u064A \u0627\u0644\u0631\u0635\u062F", children: "\u062C\u0627\u0631\u064A \u0627\u0644\u0631\u0635\u062F" }), _jsx("option", { value: "\u0645\u0643\u062A\u0645\u0644", children: "\u0645\u0643\u062A\u0645\u0644" })] })] }), _jsxs("div", { style: { flex: '1 1 180px' }, children: [_jsx("label", { style: { display: 'block', fontSize: 12, color: colors.textMuted, marginBottom: 4 }, children: "\u0628\u062D\u062B" }), _jsx("input", { value: search, onChange: e => setSearch(e.target.value), placeholder: "\u0645\u0639\u0644\u0645\u0629\u060C \u0645\u0627\u062F\u0629 \u0623\u0648 \u0641\u0635\u0644", style: { width: '100%', padding: '8px 10px', boxSizing: 'border-box', border: `1px solid ${colors.border}`, borderRadius: 8 } })] }), _jsx("button", { onClick: exportPdf, disabled: exporting || !reportRows.length, style: { padding: '8px 12px', background: colors.primary, color: '#fff', border: 'none', borderRadius: 8 }, children: exporting ? '...' : 'PDF تقرير المتابعة' }), _jsx("button", { onClick: exportExcel, disabled: !reportRows.length, style: { padding: '8px 12px', background: '#fff', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: 8 }, children: "Excel" })] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), loading ? _jsx("p", { style: { textAlign: 'center', color: colors.textMuted }, children: "\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629..." }) : grouped.length === 0 ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0646\u062A\u0627\u0626\u062C \u0645\u0637\u0627\u0628\u0642\u0629." }) : grouped.map(group => _jsxs("section", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, marginBottom: spacing.md, overflow: 'hidden' }, children: [_jsx("div", { style: { background: '#f6f7f7', padding: '10px 12px', fontFamily: font.family, fontWeight: 'bold', color: colors.ink }, children: group.teacherName }), _jsx("div", { style: { overflowX: 'auto' }, children: _jsxs("table", { style: { width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: 650 }, children: [_jsx("thead", { children: _jsx("tr", { children: ['المادة والفصل', 'الأسبوع', 'اكتمال الرصد', 'نسبة الإتقان', ''].map((h, i) => _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: h }, i)) }) }), _jsx("tbody", { children: group.items.map((r) => _jsxs("tr", { style: { borderBottom: '1px solid #f0f0f0' }, children: [_jsxs("td", { style: { padding: 8 }, children: [_jsx("strong", { children: r.assignment.subject || 'بدون مادة' }), _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: r.className })] }), _jsx("td", { style: { padding: 8 }, children: r.week ? _jsxs(_Fragment, { children: [_jsx("div", { children: r.week.name }), _jsx("span", { style: { fontSize: 10, padding: '2px 6px', borderRadius: 999, background: r.week.type === 'remediation' ? colors.amberTint : colors.primaryTint, color: r.week.type === 'remediation' ? colors.amber : '#0b5c33' }, children: TYPE_LABELS[r.week.type] })] }) : _jsx("strong", { style: { color: colors.red }, children: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0631\u0635\u062F" }) }), _jsxs("td", { style: { padding: 8 }, children: [_jsxs("strong", { children: [r.summary?.completionPercent || 0, "\u066A"] }), _jsx("div", { style: { fontSize: 10, color: statusFor(r) === 'لم يتم الرصد' ? colors.red : colors.textMuted }, children: statusFor(r) })] }), _jsx("td", { style: { padding: 8, fontWeight: 'bold' }, children: r.masteryPercent == null ? '—' : `${r.masteryPercent}٪` }), _jsx("td", { style: { padding: 8 }, children: _jsx("button", { onClick: () => onReport({ assignmentId: r.assignment.id, classId: r.assignment.classId, teacherUid: r.assignment.teacherUid, className: r.className, subject: r.assignment.subject, teacherName: r.assignment.teacherName, weekId: r.week?.id || null, weekName: r.week?.name || null }), disabled: !r.week, style: { padding: '5px 11px', background: r.week ? colors.primaryTint : '#f2f2f2', color: r.week ? '#0b5c33' : '#999', border: r.week ? `1px solid ${colors.primary}` : '1px solid #ddd', borderRadius: 6, fontWeight: 'bold' }, children: "\u062A\u0642\u0631\u064A\u0631" }) })] }, r.assignment.id)) })] }) })] }, group.key))] });
}
