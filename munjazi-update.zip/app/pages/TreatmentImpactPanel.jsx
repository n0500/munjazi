import React, { useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import { buildRemediationImpactData } from '../lib/impactReportsApi.js';
import TreatmentImpactDocument from './TreatmentImpactDocument.jsx';
import { colors, font, radius, spacing } from '../lib/theme.js';

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

export default function TreatmentImpactPanel({ schoolId, assignment, measurementWeekId, className, teacherName }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [open, setOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  async function load() {
    if (data) { setOpen((v) => !v); return; }
    setLoading(true); setError('');
    try {
      const result = await buildRemediationImpactData(schoolId, { assignment, measurementWeekId, className, teacherName });
      setData(result); setOpen(true);
    } catch (err) { setError(err.message || 'تعذّر حساب أثر المعالجة.'); }
    finally { setLoading(false); }
  }

  async function downloadPdf() {
    if (!data?.hasImpact) return;
    setExporting(true);
    try {
      const blob = await pdf(<TreatmentImpactDocument data={data} />).toBlob();
      saveBlob(blob, `أثر-المعالجة-${className}-${data.measurementWeekName}.pdf`);
    } catch (err) { setError(err.message || 'تعذّر تحميل تقرير أثر المعالجة.'); }
    finally { setExporting(false); }
  }

  return <div style={{ marginTop: spacing.md }}>
    <button type="button" onClick={load} disabled={loading} style={{ padding:'7px 12px', background:'#fff', color:colors.primary, border:`1px solid ${colors.primary}`, borderRadius:radius.button, fontSize:12, fontWeight:'bold' }}>
      {loading ? 'جارٍ الحساب...' : open ? 'إخفاء أثر المعالجة' : 'عرض أثر المعالجة'}
    </button>
    {error && <div style={{ marginTop:8, color:colors.red, fontSize:12 }}>{error}</div>}
    {open && data && <div style={{ marginTop:10, border:`1px solid ${colors.border}`, borderRadius:radius.card, padding:spacing.md, background:'#fff' }}>
      {!data.hasImpact ? <p style={{ margin:0, color:colors.textMuted, fontSize:13 }}>لا توجد بيانات معالجة مرتبطة تسمح بحساب الأثر.</p> : <>
        <div style={{ display:'flex', justifyContent:'space-between', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          <h3 style={{ margin:0, fontFamily:font.family, color:colors.ink, fontSize:17 }}>أثر المعالجة</h3>
          <button type="button" onClick={downloadPdf} disabled={exporting} style={{ padding:'6px 11px', background:colors.primary, color:'#fff', border:'none', borderRadius:radius.button, fontSize:12 }}>{exporting?'...':'تحميل PDF'}</button>
        </div>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginTop:10 }}>
          {[['قبل المعالجة',`${data.baselineMasteryPercent}٪`],['آخر معالجة',`${data.latestMasteryPercent}٪`],['التحسن',`${data.improvementPoints>0?'+':''}${data.improvementPoints} نقطة`],['طالبات تحسن مستواهن',data.improvedStudentKeys.length]].map(([label,value])=><div key={label} style={{ flex:'1 1 130px', padding:9, border:`1px solid ${colors.border}`, borderRadius:8, textAlign:'center' }}><strong style={{ display:'block', fontSize:18, color:colors.ink }}>{value}</strong><span style={{ fontSize:11, color:colors.textMuted }}>{label}</span></div>)}
        </div>
        <div style={{ overflowX:'auto', marginTop:10 }}>
          <table style={{ width:'100%', borderCollapse:'collapse', minWidth:540, fontSize:12 }}>
            <thead><tr><th style={{ textAlign:'right', padding:7, borderBottom:`2px solid ${colors.border}` }}>المهارة</th><th style={{ padding:7, borderBottom:`2px solid ${colors.border}` }}>القياس</th>{data.remediationWeeks.map(w=><th key={w.id} style={{ padding:7, borderBottom:`2px solid ${colors.border}` }}>{w.label}</th>)}<th style={{ padding:7, borderBottom:`2px solid ${colors.border}` }}>التحسن</th></tr></thead>
            <tbody>{data.skills.map(skill=><tr key={skill.skillId}><td style={{ padding:7, borderBottom:'1px solid #eee', fontWeight:'bold' }}>{skill.title}</td><td style={{ padding:7, borderBottom:'1px solid #eee', textAlign:'center' }}>{skill.stages[0]?.masteryPercent ?? '—'}٪</td>{data.remediationWeeks.map((w)=>{const s=skill.stages.find(x=>x.weekId===w.id);return <td key={w.id} style={{ padding:7, borderBottom:'1px solid #eee', textAlign:'center' }}>{s?`${s.masteryPercent}٪`:'—'}</td>})}<td style={{ padding:7, borderBottom:'1px solid #eee', textAlign:'center', fontWeight:'bold' }}>{skill.improvementPoints>0?'+':''}{skill.improvementPoints}</td></tr>)}</tbody>
          </table>
        </div>
      </>}
    </div>}
  </div>;
}
