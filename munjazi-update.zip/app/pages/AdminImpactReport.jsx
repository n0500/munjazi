import React, { useEffect, useMemo, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import { buildImpactReportData, loadPeriodContext } from '../lib/impactReportsApi.js';
import ImpactReportDocument from './ImpactReportDocument.jsx';
import { colors, font, radius, spacing } from '../lib/theme.js';

function saveBlob(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);}

export default function AdminImpactReport({ schoolId, assignments, classes, teachers }){
  const [teacherUid,setTeacherUid]=useState('all');
  const [classId,setClassId]=useState('all');
  const [context,setContext]=useState({weekLists:{},periodOptions:[]});
  const [fromWeekName,setFromWeekName]=useState('');
  const [toWeekName,setToWeekName]=useState('');
  const [loading,setLoading]=useState(true);
  const [generating,setGenerating]=useState(false);
  const [error,setError]=useState('');
  useEffect(()=>{(async()=>{setLoading(true);setError('');try{const ctx=await loadPeriodContext(schoolId,assignments);setContext(ctx);const opts=ctx.periodOptions;setFromWeekName(opts[0]||'');setToWeekName(opts[opts.length-1]||'');}catch(err){setError(err.message||'تعذّر تحميل بيانات الأثر.');}finally{setLoading(false);}})();},[schoolId,assignments]);
  const filteredAssignments=useMemo(()=>assignments.filter(a=>(teacherUid==='all'||a.teacherUid===teacherUid)&&(classId==='all'||a.classId===classId)),[assignments,teacherUid,classId]);
  const teacherName=teacherUid==='all'?'':(teachers.find(t=>t.uid===teacherUid)?.displayName||filteredAssignments[0]?.teacherName||'');
  const className=classId==='all'?'':(classes.find(c=>c.id===classId)?.name||'');
  const scopeParts=[];if(teacherName)scopeParts.push(`المعلمة: ${teacherName}`);if(className)scopeParts.push(`الفصل: ${className}`);const scopeLabel=scopeParts.length?scopeParts.join(' — '):'نطاق التقرير: المدرسة كاملة';
  async function generate(){if(generating||!fromWeekName||!toWeekName||!filteredAssignments.length)return;setGenerating(true);setError('');try{const data=await buildImpactReportData(schoolId,{assignments:filteredAssignments,classes,teacherName,fromWeekName,toWeekName,periodContext:context,audience:'admin',scopeLabel});const blob=await pdf(<ImpactReportDocument data={data}/>).toBlob();saveBlob(blob,`تقرير-الأثر-العام-الإدارة-${fromWeekName}-${toWeekName}.pdf`);}catch(err){setError(err.message||'تعذّر توليد تقرير الأثر العام.');}finally{setGenerating(false);}}
  const opts=context.periodOptions||[];
  return <div dir="rtl">
    <h2 style={{fontFamily:font.family,color:colors.ink,marginBottom:4}}>تقرير الأثر العام</h2>
    <p style={{color:colors.textMuted,fontSize:13,marginTop:0}}>تقرير إشرافي يجمع القياس والمعالجة والخطط العلاجية والتوصيات ومؤشرات التحسن، مع التصفية حسب المعلمة أو الفصل.</p>
    {error&&<div style={{background:colors.redTint,color:colors.red,padding:10,borderRadius:radius.button,marginBottom:spacing.md}}>{error}</div>}
    <div style={{border:`1px solid ${colors.border}`,borderRadius:radius.card,padding:spacing.lg}}>
      {loading?<p style={{color:colors.textMuted}}>جارٍ تحميل الفترات...</p>:opts.length===0?<p style={{color:colors.textMuted}}>لا توجد أسابيع متاحة لإعداد التقرير.</p>:<>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',gap:8,marginBottom:10}}>
          <label style={{fontSize:13}}>المعلمة<select value={teacherUid} onChange={e=>setTeacherUid(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}><option value="all">كل المعلمات</option>{teachers.map(t=><option key={t.uid} value={t.uid}>{t.displayName}</option>)}</select></label>
          <label style={{fontSize:13}}>الفصل<select value={classId} onChange={e=>setClassId(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}><option value="all">كل الفصول</option>{classes.filter(c=>!c.archived).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label style={{fontSize:13}}>من أسبوع<select value={fromWeekName} onChange={e=>setFromWeekName(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}>{opts.map(n=><option key={`f-${n}`} value={n}>{n}</option>)}</select></label>
          <label style={{fontSize:13}}>إلى أسبوع<select value={toWeekName} onChange={e=>setToWeekName(e.target.value)} style={{width:'100%',padding:9,marginTop:4}}>{opts.map(n=><option key={`t-${n}`} value={n}>{n}</option>)}</select></label>
        </div>
        <div style={{fontSize:12,color:colors.textMuted,marginBottom:10}}>{scopeLabel} — {filteredAssignments.length} إسناد مشمول.</div>
        <button onClick={generate} disabled={generating||!filteredAssignments.length} style={{padding:'10px 16px',background:colors.primary,color:'#fff',border:'none',borderRadius:radius.button,fontWeight:'bold'}}>{generating?'جارٍ التوليد...':'تحميل تقرير الأثر العام PDF'}</button>
      </>}
    </div>
  </div>;
}
