import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font, Link } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';
Font.register({
    family: 'Plex',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf',
});
Font.register({
    family: 'Plex-Bold',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf',
});
Font.registerHyphenationCallback((word) => [word]);
const STATUS_STYLE = {
    mastered: { bg: '#eaf6ee', text: '#0b5c33', border: '#0b7a4b' },
    needsSupport: { bg: '#fff7e0', text: '#8a6d00', border: '#d9b400' },
    notMastered: { bg: '#fdecea', text: '#a10000', border: '#c62828' },
    absent: { bg: '#f2f2f2', text: '#666', border: '#ccc' },
};
const HEADER_BG = '#14261e';
const HEADER_DIVIDER = '#3a4a42';
const ROW_BORDER = '#e0e0e0';
const COL_BORDER = '#cfcfcf';
const styles = StyleSheet.create({
    page: { fontFamily: 'Plex', paddingTop: 100, paddingBottom: 40, paddingHorizontal: 26, fontSize: 9 },
    fixedHeaderBlock: { position: 'absolute', top: 14, left: 26, right: 26 },
    reportLogo: { position: 'absolute', top: 0, right: 0, width: 72, height: 33, objectFit: 'contain' },
    schoolName: { fontFamily: 'Plex-Bold', fontSize: 13, color: '#14261e', textAlign: 'center', lineHeight: 1.3 },
    reportTitle: { fontFamily: 'Plex-Bold', fontSize: 14, color: '#0b7a4b', textAlign: 'center', marginTop: 8, lineHeight: 1.3 },
    metaLine: { fontSize: 9, color: '#555', textAlign: 'center', marginTop: 4, lineHeight: 1.3 },
    // القسم الأسبوعي بالكامل عاد يسمح بالانقسام الطبيعي بين الصفحات (لا يوجد wrap={false} هنا)
    weekBlock: { borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 10, marginBottom: 12 },
    weekTitleBlock: { marginBottom: 6 },
    weekTitle: { fontFamily: 'Plex-Bold', fontSize: 11, marginBottom: 4, textAlign: 'right' },
    weekLink: { fontSize: 8, color: '#0b7a4b', textDecoration: 'underline' },
    noSkillsText: { fontSize: 8.5, color: '#999' },
    tableHeaderRow: { flexDirection: 'row-reverse', backgroundColor: HEADER_BG, paddingVertical: 4 },
    headerCell: {
        fontFamily: 'Plex-Bold', fontSize: 7.5, color: '#fff', textAlign: 'center',
        borderLeftWidth: 0.5, borderLeftColor: HEADER_DIVIDER,
    },
    headerCellFirst: { textAlign: 'right', paddingRight: 5 },
    englishHeader: { direction: 'ltr', textAlign: 'center' },
    // كل صف طالبة على حدة يبقى محميًا من القطع بمنتصفه (wrap={false} على الصف نفسه فقط)
    skillRow: { flexDirection: 'row-reverse', minHeight: 18, alignItems: 'flex-start', borderBottomWidth: 0.5, borderBottomColor: ROW_BORDER },
    skillCell: { fontSize: 7.5, paddingHorizontal: 4, paddingVertical: 4, borderLeftWidth: 0.5, borderLeftColor: COL_BORDER },
    nameCell: { fontFamily: 'Plex', fontSize: 8, textAlign: 'right' },
    recCell: { fontSize: 7, textAlign: 'right', lineHeight: 1.35 },
    badge: { paddingHorizontal: 5, paddingVertical: 1.5, borderRadius: 4, borderWidth: 1, alignSelf: 'flex-start', minWidth: 38, alignItems: 'center', marginTop: 1 },
    badgeText: { fontSize: 7.5, fontFamily: 'Plex-Bold' },
    actionsCell: { fontSize: 6.5 },
    summaryBox: { borderWidth: 1, borderColor: '#0b7a4b', borderRadius: 6, padding: 10, marginTop: 4, marginBottom: 10 },
    summaryTitle: { fontFamily: 'Plex-Bold', fontSize: 10, marginBottom: 4, color: '#0b5c33', textAlign: 'right' },
    summaryRow: { flexDirection: 'row', justifyContent: 'center', gap: 12, fontSize: 9 },
    footer: {
        position: 'absolute', bottom: 14, left: 26, right: 26,
        flexDirection: 'row-reverse',
        fontSize: 8, color: '#333', borderTop: 0.5, borderTopColor: '#ccc', paddingTop: 6,
    },
    footerColRight: { flex: 1, textAlign: 'right' },
    footerColCenter: { flex: 1, textAlign: 'center' },
    footerColLeft: { flex: 1, textAlign: 'left' },
});
function StatusBadge({ status, statusLabel }) {
    const s = STATUS_STYLE[status] || { bg: '#f2f2f2', text: '#666', border: '#ccc' };
    return (_jsx(View, { style: [styles.badge, { backgroundColor: s.bg, borderColor: s.border }], children: _jsx(Text, { style: [styles.badgeText, { color: s.text }], children: statusLabel }) }));
}
const STATUS_KEYS = [
    { key: 'mastered', label: 'متقنة' },
    { key: 'needsSupport', label: 'تحتاج متابعة' },
    { key: 'notMastered', label: 'غير متقنة' },
    { key: 'absent', label: 'غائبة' },
    { key: 'unassessed', label: 'غير مرصودة' },
];
function weekColumnWidths(skillCount, includeActions) {
    const nameW = 24;
    const recW = 19;
    const actionW = includeActions ? 15 : 0;
    const remaining = 100 - nameW - recW - actionW;
    const skillW = remaining / Math.max(skillCount, 1);
    return { nameW, recW, actionW, skillW };
}
export default function ClassRangeReportDocument({ data }) {
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", orientation: "landscape", style: styles.page, children: [_jsxs(View, { style: styles.fixedHeaderBlock, fixed: true, children: [_jsx(ReportLogo, { style: styles.reportLogo }), _jsx(Text, { style: styles.schoolName, children: data.schoolName }), _jsxs(Text, { style: styles.reportTitle, children: ["\u062A\u0642\u0631\u064A\u0631 \u0641\u0635\u0644 \u2014 \u0645\u062F\u0649 \u0623\u0633\u0627\u0628\u064A\u0639 \u2014 ", data.className] }), _jsxs(Text, { style: styles.metaLine, children: ["\u0627\u0644\u0645\u0627\u062F\u0629: ", data.subject || 'غير محددة'] }), _jsxs(Text, { style: styles.metaLine, children: ["\u0645\u0646 ", data.fromWeekName, " \u0625\u0644\u0649 ", data.toWeekName] })] }), data.weeks.map((w, wIdx) => {
                    const includeActions = w.rows.some((row) => (row.activeActions || []).length > 0);
                    const { nameW, recW, actionW, skillW } = weekColumnWidths(w.skillTitles.length, includeActions);
                    return (_jsxs(View, { style: styles.weekBlock, minPresenceAhead: 76, children: [_jsxs(View, { style: styles.weekTitleBlock, wrap: false, minPresenceAhead: 54, children: [_jsxs(Text, { style: styles.weekTitle, children: [w.name, " \u2014 ", w.typeLabel] }), w.enrichmentLink && (_jsx(Text, { style: styles.weekLink, children: _jsx(Link, { src: w.enrichmentLink, style: styles.weekLink, children: "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0625\u062B\u0631\u0627\u0626\u064A" }) }))] }), w.skillTitles.length === 0 ? (_jsx(Text, { style: styles.noSkillsText, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0647\u0627\u0631\u0627\u062A \u0645\u0633\u062C\u064E\u0651\u0644\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639." })) : (_jsxs(_Fragment, { children: [_jsxs(View, { style: styles.tableHeaderRow, fixed: true, children: [_jsx(Text, { style: [styles.headerCell, styles.headerCellFirst, { width: `${nameW}%` }], children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }), w.skillTitles.map((t, i) => (_jsx(Text, { style: [styles.headerCell, styles.englishHeader, { width: `${skillW}%` }], children: t }, i))), _jsx(Text, { style: [styles.headerCell, { width: `${recW}%` }], children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0629" }), includeActions && (_jsx(Text, { style: [styles.headerCell, { width: `${actionW}%` }], children: "\u0627\u0644\u0625\u062C\u0631\u0627\u0621" }))] }), w.rows.map((row, i) => (_jsxs(View, { style: styles.skillRow, wrap: false, children: [_jsx(Text, { style: [styles.skillCell, styles.nameCell, { width: `${nameW}%` }], children: row.name }), row.cells.map((c, j) => (_jsx(View, { style: [styles.skillCell, { width: `${skillW}%`, alignItems: 'center' }], children: _jsx(StatusBadge, { status: c.status, statusLabel: c.statusLabel }) }, j))), _jsx(Text, { style: [styles.skillCell, styles.recCell, { width: `${recW}%` }], children: row.recommendation }), includeActions && (_jsx(View, { style: [styles.skillCell, { width: `${actionW}%` }], children: (row.activeActions || []).map((a, k) => (_jsxs(Text, { style: [styles.actionsCell, { color: a.type === 'remedial' ? '#8a5a00' : '#0b5c33' }], children: [a.type === 'remedial' ? '⚠' : '⭐', " ", a.affectedSkillTitles.join('، '), ": ", a.text] }, k))) }))] }, i)))] }))] }, w.id));
                }), _jsxs(View, { style: styles.summaryBox, wrap: false, children: [_jsx(Text, { style: styles.summaryTitle, children: "حالة الطالبات في آخر أسبوع ضمن النطاق" }), _jsx(View, { style: styles.summaryRow, children: [_jsxs(Text, { children: ["إجمالي الطالبات: ", Object.values(data.classCounts || {}).reduce((sum, n) => sum + (Number(n) || 0), 0)] }), ...STATUS_KEYS.map((s) => (_jsxs(Text, { children: [s.label, ": ", data.classCounts[s.key] || 0] }, s.key)))] })] }), _jsxs(View, { style: styles.footer, fixed: true, children: [_jsxs(Text, { style: styles.footerColRight, children: ["\u0645\u062F\u064A\u0631\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629: ", data.principalName || '—'] }), _jsxs(Text, { style: styles.footerColCenter, children: ["\u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629: ", data.teacherName] }), _jsx(Text, { style: styles.footerColLeft, render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` })] })] }) }));
}
