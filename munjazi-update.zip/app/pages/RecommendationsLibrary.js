import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { STATUS_LABELS, DEFAULT_RECOMMENDATIONS, listCustomRecommendations, addCustomRecommendation, deleteCustomRecommendation, } from '../lib/recommendationsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const EDITABLE_STATUSES = ['needsSupport', 'notMastered', 'absent'];
export default function RecommendationsLibrary({ schoolId, teacherUid, onBack }) {
    const [customByStatus, setCustomByStatus] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [newText, setNewText] = useState({});
    const [adding, setAdding] = useState({});
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const map = {};
            await Promise.all(EDITABLE_STATUSES.map(async (status) => {
                map[status] = await listCustomRecommendations(schoolId, teacherUid, status);
            }));
            setCustomByStatus(map);
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل مكتبة التوصيات.');
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    async function handleAdd(status) {
        setError('');
        const text = (newText[status] || '').trim();
        if (!text || adding[status])
            return;
        setAdding((prev) => ({ ...prev, [status]: true }));
        try {
            await addCustomRecommendation(schoolId, teacherUid, status, text);
            setNewText((prev) => ({ ...prev, [status]: '' }));
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر إضافة التوصية.');
        }
        finally {
            setAdding((prev) => ({ ...prev, [status]: false }));
        }
    }
    async function handleDelete(id) {
        setError('');
        try {
            await deleteCustomRecommendation(schoolId, id);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر حذف التوصية.');
        }
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    return (_jsxs("div", { style: { maxWidth: 600, margin: '20px auto', padding: spacing.lg }, dir: "rtl", children: [_jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0644\u0648\u062D\u0629 \u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629" }), _jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u0645\u0643\u062A\u0628\u0629 \u0627\u0644\u062A\u0648\u0635\u064A\u0627\u062A" }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), EDITABLE_STATUSES.map((status) => (_jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.lg }, children: [_jsx("h3", { style: { marginTop: 0, fontFamily: font.family }, children: STATUS_LABELS[status] }), _jsx("p", { style: { fontSize: 13, color: colors.textMuted, marginBottom: 6 }, children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0627\u062A \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629:" }), (DEFAULT_RECOMMENDATIONS[status] || []).map((text, i) => (_jsx("div", { style: { padding: '6px 0', borderBottom: '1px solid #f2f2f2', fontSize: 14, color: colors.text }, children: text }, i))), _jsx("p", { style: { fontSize: 13, color: colors.textMuted, marginTop: 12, marginBottom: 6 }, children: "\u062A\u0648\u0635\u064A\u0627\u062A\u064A \u0627\u0644\u062E\u0627\u0635\u0629:" }), (customByStatus[status] || []).length === 0 ? (_jsx("p", { style: { fontSize: 13, color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u062A\u0648\u0635\u064A\u0627\u062A \u0645\u0636\u0627\u0641\u0629 \u0628\u0639\u062F." })) : (customByStatus[status].map((rec) => (_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid #f2f2f2' }, children: [_jsx("span", { style: { fontSize: 14 }, children: rec.text }), _jsx("button", { onClick: () => handleDelete(rec.id), style: { padding: '2px 8px', background: colors.red, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12 }, children: "\u062D\u0630\u0641" })] }, rec.id)))), _jsxs("div", { style: { display: 'flex', gap: 8, marginTop: spacing.sm }, children: [_jsx("input", { type: "text", placeholder: "\u0625\u0636\u0627\u0641\u0629 \u062A\u0648\u0635\u064A\u0629 \u062C\u062F\u064A\u062F\u0629", value: newText[status] || '', onChange: (e) => setNewText((prev) => ({ ...prev, [status]: e.target.value })), style: { flex: 1, padding: 8 } }), _jsx("button", { onClick: () => handleAdd(status), disabled: adding[status], style: { padding: '8px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: adding[status] ? '...' : 'إضافة' })] })] }, status)))] }));
}
