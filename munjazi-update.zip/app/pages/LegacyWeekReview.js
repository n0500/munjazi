import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { listAmbiguousLegacyWeeks, linkLegacyWeekToAssignment } from '../lib/weeksApi.js';
import { colors, radius, spacing } from '../lib/theme.js';
export default function LegacyWeekReview({ schoolId, teacherUid, classNameFor, onChanged }) {
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [choiceByWeek, setChoiceByWeek] = useState({});
    const [savingId, setSavingId] = useState(null);
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            setRows(await listAmbiguousLegacyWeeks(schoolId, teacherUid));
        }
        catch (err) {
            setError(err.message || 'تعذر فحص الأسابيع القديمة.');
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [schoolId, teacherUid]);
    async function handleLink(week) {
        const assignmentId = choiceByWeek[week.id];
        if (!assignmentId)
            return;
        setSavingId(week.id);
        setError('');
        try {
            await linkLegacyWeekToAssignment(schoolId, week.id, assignmentId);
            await refresh();
            if (onChanged)
                onChanged();
        }
        catch (err) {
            setError(err.message || 'تعذر ربط الأسبوع بالمادة.');
        }
        finally {
            setSavingId(null);
        }
    }
    if (loading)
        return null;
    if (rows.length === 0 && !error)
        return null;
    return (_jsxs("div", { style: { border: `1px solid ${colors.amberBorder}`, background: colors.amberTint, borderRadius: radius.card, padding: spacing.md, marginBottom: spacing.lg }, dir: "rtl", children: [_jsx("strong", { style: { color: colors.amber }, children: "\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0642\u062F\u064A\u0645\u0629" }), _jsx("p", { style: { fontSize: 12, color: colors.amber }, children: "\u062A\u0648\u062C\u062F \u0623\u0633\u0627\u0628\u064A\u0639 \u0642\u062F\u064A\u0645\u0629 \u0623\u0646\u0634\u0626\u062A \u0642\u0628\u0644 \u0641\u0635\u0644 \u0627\u0644\u0645\u0648\u0627\u062F. \u0644\u0627 \u064A\u0646\u0633\u0628 \u0627\u0644\u0646\u0638\u0627\u0645 \u0647\u0630\u0647 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0644\u0645\u0627\u062F\u0629 \u0628\u0627\u0644\u062A\u062E\u0645\u064A\u0646\u061B \u0627\u062E\u062A\u0627\u0631\u064A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0635\u062D\u064A\u062D\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0642\u0637." }), error && _jsx("div", { style: { color: colors.red, fontSize: 12, marginBottom: 8 }, children: error }), rows.map((week) => (_jsxs("div", { style: { background: '#fff', borderRadius: radius.button, padding: 8, marginBottom: 7 }, children: [_jsxs("div", { style: { fontSize: 13, fontWeight: 'bold' }, children: [week.name, " (", week.type === 'remediation' ? 'معالجة' : 'قياس', ") \u2014 ", classNameFor(week.classId)] }), _jsxs("div", { style: { display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap' }, children: [_jsxs("select", { value: choiceByWeek[week.id] || '', onChange: (e) => setChoiceByWeek((prev) => ({ ...prev, [week.id]: e.target.value })), style: { flex: 1, minWidth: 180, padding: 6 }, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0645\u0627\u062F\u0629" }), week.possibleAssignments.map((a) => _jsx("option", { value: a.id, children: a.subject || 'بدون مادة' }, a.id))] }), _jsx("button", { onClick: () => handleLink(week), disabled: !choiceByWeek[week.id] || savingId === week.id, style: { padding: '6px 12px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: savingId === week.id ? '...' : 'اعتماد المادة' })] })] }, week.id)))] }));
}
