import React from 'react';
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';

Font.register({ family: 'Plex', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf' });
Font.register({ family: 'Plex-Bold', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf' });
Font.registerHyphenationCallback((word) => [word]);

const styles = StyleSheet.create({
  page: { fontFamily: 'Plex', paddingTop: 96, paddingBottom: 38, paddingHorizontal: 26, fontSize: 8.5, color: '#14261e' },
  header: { position: 'absolute', top: 14, left: 26, right: 26 },
  logo: { position: 'absolute', top: 0, right: 0, width: 72, height: 33, objectFit: 'contain' },
  school: { fontFamily: 'Plex-Bold', fontSize: 13, textAlign: 'center' },
  title: { fontFamily: 'Plex-Bold', fontSize: 15, color: '#0b7a4b', textAlign: 'center', marginTop: 7 },
  meta: { fontSize: 8.5, color: '#555', textAlign: 'center', marginTop: 3 },
  cards: { flexDirection: 'row-reverse', gap: 8, marginBottom: 12 },
  card: { flex: 1, borderWidth: 1, borderColor: '#d7dfdb', borderRadius: 6, padding: 8, alignItems: 'center' },
  cardValue: { fontFamily: 'Plex-Bold', fontSize: 15, color: '#0b5c33' },
  cardLabel: { fontSize: 7.5, color: '#666', marginTop: 2 },
  note: { borderWidth: 1, borderColor: '#dfe9e3', backgroundColor: '#fbfdfc', borderRadius: 6, padding: 8, marginBottom: 10, lineHeight: 1.55, textAlign: 'right' },
  table: { borderWidth: 1, borderColor: '#d7d7d7' },
  row: { flexDirection: 'row-reverse', borderBottomWidth: 0.5, borderBottomColor: '#ddd', minHeight: 27, alignItems: 'center' },
  head: { backgroundColor: '#14261e' },
  cell: { paddingHorizontal: 4, paddingVertical: 5, textAlign: 'center', borderLeftWidth: 0.5, borderLeftColor: '#ddd' },
  headText: { color: '#fff', fontFamily: 'Plex-Bold', fontSize: 7.2 },
  classCell: { width: '18%', textAlign: 'right' },
  subjectCell: { width: '14%' },
  weekCell: { width: '16%' },
  pctCell: { width: '11%' },
  changeCell: { width: '10%' },
  analysisCell: { width: '20%', fontSize: 6.6, textAlign: 'right', lineHeight: 1.35 },
  footer: { position: 'absolute', bottom: 13, left: 26, right: 26, borderTopWidth: 0.5, borderTopColor: '#ccc', paddingTop: 5, flexDirection: 'row-reverse', fontSize: 7.5, color: '#444' },
  f1: { flex: 1, textAlign: 'right' }, f2: { flex: 1, textAlign: 'center' }, f3: { flex: 1, textAlign: 'left' },
});

function value(v) { return Number.isFinite(Number(v)) ? Number(v) : 0; }
function changeText(v) { const n = value(v); return n > 0 ? `+${n}` : `${n}`; }

export default function TeacherAllClassesReportDocument({ data }) {
  return (
    <Document>
      <Page size="A4" orientation="landscape" style={styles.page}>
        <View style={styles.header} fixed>
          <ReportLogo style={styles.logo} />
          <Text style={styles.school}>{data.schoolName}</Text>
          <Text style={styles.title}>تحليل نتائج جميع الفصول</Text>
          <Text style={styles.meta}>المعلّمة: {data.teacherName} — الفترة: من {data.fromWeekName} إلى {data.toWeekName}</Text>
          <Text style={styles.meta}>تاريخ التقرير: {data.generatedDate}</Text>
        </View>

        <View style={styles.cards} wrap={false}>
          <View style={styles.card}><Text style={styles.cardValue}>{data.classes.length}</Text><Text style={styles.cardLabel}>إجمالي الفصول</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{data.classesWithData}</Text><Text style={styles.cardLabel}>فصول لديها رصد</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{data.overallMasteryPercent}٪</Text><Text style={styles.cardLabel}>الإتقان الإجمالي في آخر رصد</Text></View>
        </View>

        <Text style={styles.note}>يعرض التقرير خلاصة أداء جميع الفصول المسندة خلال الفترة، مع مقارنة أول وآخر رصد داخل النطاق. نسبة الإتقان تحسب من النتائج المرصودة فعليًا، ويعرض التغير بالنقاط المئوية.</Text>

        <View style={styles.table}>
          <View style={[styles.row, styles.head]} fixed>
            <Text style={[styles.cell, styles.classCell, styles.headText]}>الفصل</Text>
            <Text style={[styles.cell, styles.subjectCell, styles.headText]}>المادة</Text>
            <Text style={[styles.cell, styles.weekCell, styles.headText]}>آخر رصد</Text>
            <Text style={[styles.cell, styles.pctCell, styles.headText]}>الإتقان</Text>
            <Text style={[styles.cell, styles.pctCell, styles.headText]}>تحتاج متابعة</Text>
            <Text style={[styles.cell, styles.pctCell, styles.headText]}>الغياب</Text>
            <Text style={[styles.cell, styles.changeCell, styles.headText]}>التغير</Text>
            <Text style={[styles.cell, styles.analysisCell, styles.headText]}>الخلاصة</Text>
          </View>
          {data.classes.map((row, i) => (
            <View key={row.assignmentId || i} style={styles.row} wrap={false}>
              <Text style={[styles.cell, styles.classCell]}>{row.className}</Text>
              <Text style={[styles.cell, styles.subjectCell]}>{row.subject}</Text>
              <Text style={[styles.cell, styles.weekCell]}>{row.latest ? `${row.latest.weekName} — ${row.latest.weekTypeLabel}` : 'لا يوجد رصد'}</Text>
              <Text style={[styles.cell, styles.pctCell]}>{row.latest ? `${row.latest.masteryPercent}٪` : '—'}</Text>
              <Text style={[styles.cell, styles.pctCell]}>{row.latest ? `${row.latest.attentionPercent}٪` : '—'}</Text>
              <Text style={[styles.cell, styles.pctCell]}>{row.latest ? `${row.latest.absencePercent}٪` : '—'}</Text>
              <Text style={[styles.cell, styles.changeCell]}>{row.latest ? `${changeText(row.masteryChange)} نقطة` : '—'}</Text>
              <Text style={[styles.cell, styles.analysisCell]}>{row.analysis}</Text>
            </View>
          ))}
        </View>

        <View style={styles.footer} fixed>
          <Text style={styles.f1}>مديرة المدرسة: {data.principalName || '—'}</Text>
          <Text style={styles.f2}>المعلّمة: {data.teacherName}</Text>
          <Text style={styles.f3} render={({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}`} />
        </View>
      </Page>
    </Document>
  );
}
