import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font, PDFDownloadLink } from '@react-pdf/renderer';
Font.register({
    family: 'Amiri',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/amiri/Amiri-Regular.ttf',
});
const styles = StyleSheet.create({
    page: { fontFamily: 'Amiri', padding: 30, paddingTop: 60, paddingBottom: 50, fontSize: 12 },
    header: {
        position: 'absolute', top: 20, left: 30, right: 30,
        textAlign: 'center', fontSize: 18, borderBottom: 2, borderBottomColor: '#0b7a4b', paddingBottom: 8,
    },
    footer: {
        position: 'absolute', bottom: 20, left: 30, right: 30,
        textAlign: 'center', fontSize: 9, color: '#999',
    },
    row: { flexDirection: 'row-reverse', borderBottom: 1, borderBottomColor: '#eee', paddingVertical: 4 },
    cell: { flex: 1, textAlign: 'right' },
});
const baseNames = [
    'أميرة نافع غزاي الحري', 'الجوهره عبدالله عبدالعزيز الخليفه', 'العنود عبدالعزيز هلال الدحيان',
    'الينوف يوسف بن صالح الصويان', 'تالا عبدالعزيز عبدالرحمن البطي', 'تولين محمد الحميدي الحري',
    'جمانه خالد مهجي المطيري', 'داليا خليل حمدي الحري', 'دانة اسامه بن عبدالعزيز ابوعباة',
    'رهف راشد بن وديان المظيبري',
];
const dummyNames = Array.from({ length: 60 }, (_, i) => `${baseNames[i % baseNames.length]} ${Math.floor(i / baseNames.length) + 1}`);
function TestDocument() {
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", style: styles.page, children: [_jsx(Text, { style: styles.header, fixed: true, children: "\u0645\u0646\u062C\u0632\u064A \u2014 \u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u062E\u0637 \u0627\u0644\u0639\u0631\u0628\u064A \u0648\u0627\u0644\u0631\u0623\u0633 \u0627\u0644\u0645\u062A\u0643\u0631\u0631" }), dummyNames.map((name, i) => (_jsxs(View, { style: styles.row, children: [_jsx(Text, { style: styles.cell, children: name }), _jsx(Text, { style: styles.cell, children: "\u0645\u062A\u0642\u0646\u0629" })] }, i))), _jsx(Text, { style: styles.footer, fixed: true, render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` })] }) }));
}
export default function PdfTestPage() {
    return (_jsxs("div", { style: { maxWidth: 420, margin: '60px auto', padding: 16, textAlign: 'center' }, dir: "rtl", children: [_jsx("h2", { style: { fontFamily: 'sans-serif' }, children: "\u0635\u0641\u062D\u0629 \u0627\u062E\u062A\u0628\u0627\u0631 PDF \u0627\u0644\u0645\u0639\u0632\u0648\u0644\u0629" }), _jsx("p", { style: { fontFamily: 'sans-serif', fontSize: 13, color: '#666' }, children: "\u0647\u0630\u0627 \u0627\u062E\u062A\u0628\u0627\u0631 \u0645\u0633\u062A\u0642\u0644 \u062A\u0645\u0627\u0645\u064B\u0627\u060C \u0645\u0627 \u064A\u0645\u0633 \u0623\u064A \u062A\u0642\u0631\u064A\u0631 \u062D\u0627\u0644\u064A \u0628\u0627\u0644\u0646\u0638\u0627\u0645." }), _jsx(PDFDownloadLink, { document: _jsx(TestDocument, {}), fileName: "\u0627\u062E\u062A\u0628\u0627\u0631-\u0645\u0646\u062C\u0632\u064A.pdf", children: ({ loading }) => (_jsx("button", { style: { padding: '12px 24px', background: '#0b7a4b', color: '#fff', border: 'none', borderRadius: 8, fontSize: 15, marginTop: 16 }, children: loading ? '...جارٍ التجهيز' : 'تحميل ملف الاختبار' })) })] }));
}
