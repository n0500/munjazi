import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase.js';
import { getClass } from '../lib/classesApi.js';
import { buildParentOverviewData } from '../lib/reportsApi.js';
import { logParentAcknowledgment } from '../lib/actionEngine.js';
import { logParentReviewAcknowledgment } from '../lib/parentReviewAckApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const STATUS_COLORS = { mastered: { bg: colors.primaryTint, text: '#0b5c33', border: colors.primary }, needsSupport: { bg: '#fff7e0', text: '#8a6d00', border: '#d9b400' }, notMastered: { bg: colors.redTint, text: colors.red, border: colors.redBorder }, absent: { bg: '#f2f2f2', text: colors.textMuted, border: colors.border } };
function SkillBadge({ status, statusLabel }) { const c = STATUS_COLORS[status] || { bg: '#f2f2f2', text: colors.textMuted, border: colors.border }; return _jsx("span", { style: { background: c.bg, color: c.text, border: `1px solid ${c.border}`, borderRadius: 6, padding: '2px 8px', fontSize: 12, fontWeight: 'bold', whiteSpace: 'nowrap' }, children: statusLabel || 'غير مرصودة' }); }
function formatDate(seconds) { if (!seconds)
    return ''; try {
    return new Date(seconds * 1000).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' });
}
catch {
    return '';
} }
function summarize(rows = []) { const mastered = rows.filter(s => s.status === 'mastered').length; const attention = rows.filter(s => s.status === 'notMastered' || s.status === 'needsSupport').length; const absent = rows.filter(s => s.status === 'absent').length; const recorded = mastered + attention + absent; return { mastered, attention, absent, recorded, total: rows.length, unrecorded: rows.length - recorded, fullyMastered: rows.length > 0 && mastered === rows.length }; }

function subjectCardState(weekRows = [], pendingSkills = []) {
    const rows = weekRows || [];
    const pending = pendingSkills || [];

    const hasNotMastered =
        rows.some((row) => row.status === 'notMastered')
        || pending.some((row) => (row.lastRemediationStatus || row.sourceStatus) === 'notMastered');

    if (hasNotMastered) {
        return {
            key: 'notMastered',
            label: 'غير متقنة',
            bg: colors.redTint,
            border: colors.redBorder,
            text: colors.red,
        };
    }

    const hasNeedsSupport =
        rows.some((row) => row.status === 'needsSupport')
        || pending.some((row) => (row.lastRemediationStatus || row.sourceStatus) === 'needsSupport');

    if (hasNeedsSupport || pending.length > 0) {
        return {
            key: 'needsSupport',
            label: 'تحتاج متابعة',
            bg: colors.amberTint,
            border: colors.amberBorder,
            text: colors.amber,
        };
    }

    const hasUnrecorded = rows.some((row) => !row.status);
    if (hasUnrecorded) {
        return {
            key: 'unrecorded',
            label: 'غير مكتملة الرصد',
            bg: '#fffaf0',
            border: colors.amberBorder,
            text: colors.amber,
        };
    }

    const hasAbsent = rows.some((row) => row.status === 'absent');
    if (hasAbsent) {
        return {
            key: 'absent',
            label: 'يوجد غياب',
            bg: '#f5f5f5',
            border: colors.border,
            text: colors.textMuted,
        };
    }

    const fullyMastered = rows.length > 0 && rows.every((row) => row.status === 'mastered');
    if (fullyMastered) {
        return {
            key: 'mastered',
            label: 'متقنة',
            bg: colors.primaryTint,
            border: colors.primary,
            text: '#0b5c33',
        };
    }

    return {
        key: 'notTracked',
        label: 'لا يوجد رصد',
        bg: '#fff',
        border: colors.border,
        text: colors.textMuted,
    };
}
export default function ParentDashboard({ schoolId, profile, logout }) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [expanded, setExpanded] = useState(new Set());
    const [selectedWeeks, setSelectedWeeks] = useState({});
    useEffect(() => {
        let cancelled = false;

        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        async function loadOverview() {
            const studentSnap = await getDoc(doc(db, 'schools', schoolId, 'students', profile.studentId));
            if (!studentSnap.exists())
                throw new Error('لم يتم العثور على بيانات الطالبة.');

            const student = studentSnap.data();
            const classInfo = await getClass(schoolId, student.currentClassId);
            return await buildParentOverviewData(schoolId, {
                classId: student.currentClassId,
                className: classInfo.name,
                studentId: profile.studentId,
                studentName: student.name,
            });
        }

        (async () => {
            setLoading(true);
            setError('');

            let lastError = null;

            // أول دخول بعد تسجيل Firebase قد يسبق مزامنة Auth مع Firestore بجزء من الثانية.
            // نعالج ذلك داخل التطبيق: نجدد الرمز ثم نعيد الطلب تلقائيًا دون أن يرى ولي الأمر صفحة خطأ.
            for (let attempt = 0; attempt < 4; attempt += 1) {
                try {
                    if (attempt > 0) {
                        await auth.currentUser?.getIdToken(true).catch(() => {});
                        await sleep(350 * attempt);
                    }

                    const overview = await loadOverview();
                    if (cancelled)
                        return;

                    setData(overview);
                    const init = {};
                    overview.subjects.forEach((s) => {
                        const key = s.assignmentKey || s.assignmentId;
                        init[key] = s.weeksData?.[0]?.id || '';
                    });
                    setSelectedWeeks(init);
                    setError('');
                    setLoading(false);
                    return;
                }
                catch (err) {
                    lastError = err;
                    const transientAuthError =
                        err?.code === 'permission-denied'
                        || err?.code === 'unavailable'
                        || err?.code === 'unauthenticated';

                    if (!transientAuthError)
                        break;
                }
            }

            if (cancelled)
                return;

            const err = lastError || new Error('تعذّر تحميل بيانات المتابعة.');
            setError(
                err.code === 'permission-denied'
                    ? 'تعذر تحميل بيانات المتابعة بسبب صلاحيات الوصول. يرجى التواصل مع إدارة المدرسة.'
                    : err.message || 'تعذّر تحميل بيانات المتابعة.'
            );
            setLoading(false);
        })();

        return () => {
            cancelled = true;
        };
    }, [schoolId, profile.studentId, profile.uid]);
    function keyFor(s) { return s.assignmentKey || s.assignmentId || `${s.teacherUid}-${s.subject}`; }
    function selectedWeek(s) { const key = keyFor(s); return (s.weeksData || []).find((w) => w.id === selectedWeeks[key]) || s.weeksData?.[0] || null; }
    function acknowledgeWeek(s, w) { if (!w)
        return; const weak = (w.skillRows || []).some((sk) => sk.status === 'notMastered' || sk.status === 'needsSupport'); if (weak)
        logParentReviewAcknowledgment(schoolId, { weekId: w.id, studentId: profile.studentId, parentUid: profile.uid, assignmentId: s.assignmentId || null, classId: s.classId || null, teacherUid: s.teacherUid || null, subject: s.subject || '' }).catch(() => { }); }
    function toggleSubject(s) { const key = keyFor(s); setExpanded(prev => { const next = new Set(prev); if (next.has(key)) {
        next.delete(key);
        return next;
    } next.add(key); acknowledgeWeek(s, selectedWeek(s)); (s.activeActions || []).filter((a) => a.type === 'remedial').forEach((a) => logParentAcknowledgment(schoolId, { actionId: a.id, parentUid: profile.uid }).catch(() => { })); return next; }); }
    function changeWeek(s, id) { const key = keyFor(s); setSelectedWeeks((p) => ({ ...p, [key]: id })); const w = (s.weeksData || []).find((x) => x.id === id); acknowledgeWeek(s, w); }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644..." });
    if (error)
        return _jsxs("div", { dir: "rtl", style: { maxWidth: 420, margin: '60px auto', padding: spacing.lg, textAlign: 'center' }, children: [_jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.lg }, children: error }), _jsx("button", { onClick: logout, style: { padding: '10px 20px', background: colors.red, color: '#fff', border: 'none', borderRadius: radius.button }, children: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C" })] });
    const subjects = data.subjects || [];
    let mastered = 0, attention = 0, absent = 0, unrecorded = 0;
    subjects.forEach((s) => { const sm = summarize(s.weeksData?.[0]?.skillRows || []); mastered += sm.mastered; attention += sm.attention; absent += sm.absent; unrecorded += sm.unrecorded; });
    return _jsxs("div", { dir: "rtl", style: { maxWidth: 520, margin: '0 auto', padding: spacing.lg }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: 16 }, children: [_jsxs("div", { children: [_jsx("h1", { style: { fontSize: 20, margin: 0, fontFamily: font.family, color: colors.ink }, children: "\u0645\u0631\u062D\u0628\u064B\u0627" }), _jsxs("p", { style: { color: colors.textMuted, fontSize: 14, margin: '4px 0 0' }, children: ["\u0645\u062A\u0627\u0628\u0639\u0629 ", data.studentName, " \u2014 ", data.className, " \u2014 ", data.schoolName] }), data.lastUpdatedAt && _jsxs("p", { style: { color: colors.textMuted, fontSize: 11, margin: '2px 0 0' }, children: ["\u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B: ", formatDate(data.lastUpdatedAt)] })] }), _jsx("button", { onClick: logout, style: { padding: '6px 14px', background: colors.red, color: '#fff', border: 'none', borderRadius: radius.button, fontSize: 12 }, children: "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C" })] }), _jsx("div", { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6, margin: '20px 0' }, children: [[mastered, 'متقنة', '#0b5c33', colors.primaryTint], [attention, 'تحتاج متابعة', colors.red, colors.redTint], [absent, 'غياب', colors.textMuted, '#f2f2f2'], [unrecorded, 'غير مرصودة', colors.amber, colors.amberTint]].map(([v, l, c, b]) => _jsxs("div", { style: { textAlign: 'center', border: `1px solid ${c}`, borderRadius: radius.card, padding: '10px 3px', background: b }, children: [_jsx("div", { style: { fontSize: 18, fontWeight: 'bold', color: c }, children: v }), _jsx("div", { style: { fontSize: 10, color: c }, children: l })] }, l)) }), _jsx("h3", { style: { fontFamily: font.family, fontSize: 16 }, children: "\u0627\u0644\u0645\u0648\u0627\u062F \u0627\u0644\u062F\u0631\u0627\u0633\u064A\u0629" }), subjects.length === 0 ? _jsx("p", { style: { color: colors.textMuted, textAlign: 'center' }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0648\u0627\u062F \u0645\u0631\u0635\u0648\u062F\u0629 \u0628\u0639\u062F." }) : subjects.map((s) => {
                const key = keyFor(s);
                const open = expanded.has(key);
                const w = selectedWeek(s);
                const sm = summarize(w?.skillRows || []);
                const remedials = (s.activeActions || []).filter((a) => a.type === 'remedial');
                const pendingSubjectSkills = s.pendingSkills || [];
                const cardState = subjectCardState(w?.skillRows || [], pendingSubjectSkills);
                return _jsxs("div", { style: { border: `1.5px solid ${cardState.border}`, borderRadius: radius.card, marginBottom: spacing.sm, overflow: 'hidden', background: cardState.bg, boxShadow: `0 1px 4px ${cardState.border}33` }, children: [_jsxs("button", { onClick: () => toggleSubject(s), style: { width: '100%', background: cardState.bg, border: 'none', padding: spacing.md, display: 'flex', justifyContent: 'space-between', alignItems: 'center', textAlign: 'right' }, children: [
                    _jsx("span", { style: { fontSize: 12, color: cardState.text }, children: open ? '▲' : '▼' }),
                    _jsxs("div", { style: { flex: 1, marginRight: 10 }, children: [
                        _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }, children: [
                            _jsx("strong", { style: { fontFamily: font.family, color: colors.ink }, children: s.subject }),
                            _jsx("span", { style: { background: '#fff', color: cardState.text, border: `1px solid ${cardState.border}`, borderRadius: 999, padding: '2px 8px', fontSize: 10, fontWeight: 'bold', whiteSpace: 'nowrap' }, children: cardState.label })
                        ] }),
                        _jsx("div", { style: { fontSize: 11, color: cardState.text, marginTop: 3 }, children: w ? `${w.name} — ${w.typeLabel} · ${sm.mastered} متقنة · ${sm.attention} تحتاج متابعة${pendingSubjectSkills.length ? ` · ${pendingSubjectSkills.length} مهارة سابقة معلقة` : ''}` : (pendingSubjectSkills.length ? `${pendingSubjectSkills.length} مهارة سابقة تحتاج متابعة` : 'لا يوجد رصد بعد') })
                    ] })
                ] }), open && _jsxs("div", { style: { borderTop: `1px solid ${cardState.border}`, padding: spacing.md, background: '#fff' }, children: [_jsxs("div", { style: { fontSize: 11, color: colors.textMuted, marginBottom: 8 }, children: [_jsx("strong", { style: { color: colors.ink }, children: "معلمة المادة: " }), s.teacherName] }), (s.weeksData || []).length > 1 && _jsxs("div", { style: { marginBottom: 10 }, children: [_jsx("label", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0627\u0644\u0623\u0633\u0628\u0648\u0639" }), _jsx("select", { value: w?.id || '', onChange: e => changeWeek(s, e.target.value), style: { width: '100%', padding: 8, marginTop: 4 }, children: (s.weeksData || []).map((x) => _jsxs("option", { value: x.id, children: [x.name, " \u2014 ", x.typeLabel] }, x.id)) })] }), !w ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0631\u0635\u062F \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u0627\u062F\u0629 \u0628\u0639\u062F." }) : _jsxs(_Fragment, { children: [_jsx("div", { style: { display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 10 }, children: (w.skillRows || []).map((sk, i) => _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', fontSize: 13 }, children: [_jsx(SkillBadge, { status: sk.status, statusLabel: sk.statusLabel || 'غير مرصودة' }), _jsx("span", { children: sk.title })] }, `${sk.title}-${i}`)) }), pendingSubjectSkills.length > 0 && _jsxs("div", { style: { marginTop: 10, marginBottom: 10, background: colors.amberTint, border: `1px solid ${colors.amberBorder}`, borderRadius: radius.button, padding: '9px 10px' }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, marginBottom: 6 }, children: [_jsx("strong", { style: { color: colors.amber, fontSize: 12 }, children: "مهارات سابقة تحتاج متابعة" }), _jsx("span", { style: { minWidth: 25, textAlign: 'center', background: '#fff', color: colors.amber, border: `1px solid ${colors.amberBorder}`, borderRadius: 999, padding: '1px 7px', fontSize: 10, fontWeight: 'bold' }, children: pendingSubjectSkills.length })] }), _jsx("div", { style: { color: colors.textMuted, fontSize: 10, lineHeight: 1.6, marginBottom: 6 }, children: "تبقى المهارة هنا حتى يتحقق إتقانها في أسبوع معالجة." }), _jsx("div", { style: { display: 'flex', flexDirection: 'column', gap: 6 }, children: pendingSubjectSkills.map((skill, i) => _jsxs("div", { style: { background: '#fff', border: `1px solid ${colors.amberBorder}`, borderRadius: 6, padding: '7px 8px' }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }, children: [_jsx("span", { style: { fontSize: 11, color: colors.ink, fontWeight: 600 }, children: skill.title }), _jsx(SkillBadge, { status: skill.lastRemediationStatus || skill.sourceStatus, statusLabel: skill.lastRemediationStatusLabel || skill.sourceStatusLabel || 'تحتاج متابعة' })] }), _jsxs("div", { style: { color: colors.textMuted, fontSize: 9, marginTop: 3, lineHeight: 1.6 }, children: ["من ", skill.sourceWeekName, " — قياس", skill.lastRemediationWeekName ? ` · آخر معالجة: ${skill.lastRemediationWeekName}` : ' · لم تُغلق بالمعالجة بعد'] })] }, `${key}-pending-${skill.key}-${i}`)) })] }), w.weekRecommendation && _jsxs("div", { style: { background: '#eef2f7', border: '1px solid #a9c0d9', color: '#3d5a80', borderRadius: radius.button, padding: '9px 10px', fontSize: 12, marginBottom: 8 }, children: [_jsx("strong", { children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A\u0629:" }), " ", w.weekRecommendation] }), w.enrichmentLink && _jsx("a", { href: w.enrichmentLink, target: "_blank", rel: "noreferrer", style: { display: 'block', textAlign: 'center', background: colors.primary, color: '#fff', borderRadius: radius.button, padding: '10px', fontSize: 13, textDecoration: 'none', marginBottom: 8 }, children: "\u0641\u062A\u062D \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u062B\u0631\u0627\u0626\u064A\u0629" })] }), remedials.length > 0 && _jsxs("div", { style: { marginTop: 10, borderTop: `1px solid ${colors.border}`, paddingTop: 10 }, children: [_jsx("strong", { style: { fontSize: 13 }, children: "\u0627\u0644\u062E\u0637\u0637 \u0627\u0644\u0639\u0644\u0627\u062C\u064A\u0629" }), remedials.map((a) => _jsxs("div", { style: { background: colors.amberTint, border: `1px solid ${colors.amberBorder}`, color: colors.amber, borderRadius: radius.button, padding: '8px 10px', fontSize: 12, marginTop: 6 }, children: [a.text, a.enrichmentLink && _jsx("a", { href: a.enrichmentLink, target: "_blank", rel: "noreferrer", style: { display: 'block', marginTop: 5, color: colors.amber, fontWeight: 'bold' }, children: "\u0641\u062A\u062D \u0627\u0644\u0631\u0627\u0628\u0637" })] }, a.id))] })] })] }, key);
            })] });
}
