import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect, useState } from 'react';
import { listSchools } from '../lib/schoolsApi.js';
import { exportSchoolBackupAsExcelBlob, exportSchoolBackupAsJsonBlob, restoreSchoolBackup, downloadBlobAsFile } from '../lib/backupApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
export default function OwnerBackup({ onBack }) {
    const [schools, setSchools] = useState([]);
    const [schoolId, setSchoolId] = useState('');
    const [busy, setBusy] = useState('');
    const [error, setError] = useState('');
    const [msg, setMsg] = useState('');
    useEffect(() => { listSchools().then(rows => { setSchools(rows); setSchoolId(rows[0]?.id || ''); }).catch((e) => setError(e.message || 'تعذّر تحميل المدارس.')); }, []);
    const selected = schools.find(s => s.id === schoolId);
    async function exp(kind) { if (!schoolId)
        return; setBusy(kind); setError(''); setMsg(''); try {
        const blob = kind === 'json' ? await exportSchoolBackupAsJsonBlob(schoolId) : await exportSchoolBackupAsExcelBlob(schoolId);
        downloadBlobAsFile(blob, `Munjazi_Backup_${selected?.schoolCode || schoolId}_${new Date().toISOString().slice(0, 10)}.${kind === 'json' ? 'json' : 'xlsx'}`);
        setMsg('تم تجهيز النسخة الاحتياطية.');
    }
    catch (e) {
        setError(e.message || 'تعذّر إنشاء النسخة الاحتياطية.');
    }
    finally {
        setBusy('');
    } }
    async function restore(e) { const file = e.target.files?.[0]; e.target.value = ''; if (!file || !schoolId)
        return; const first = window.confirm('تحذير: الاستعادة ستستبدل بيانات المدرسة الحالية بمحتوى النسخة الاحتياطية. هل تريدين المتابعة؟'); if (!first)
        return; const typed = window.prompt('للتأكيد اكتبي: استعادة'); if (typed !== 'استعادة')
        return; setBusy('restore'); setError(''); setMsg(''); try {
        const text = await file.text();
        await restoreSchoolBackup(schoolId, text);
        setMsg('تمت الاستعادة بنجاح. يرجى مراجعة البيانات قبل متابعة العمل.');
    }
    catch (err) {
        setError(err.message || 'تعذّرت الاستعادة.');
    }
    finally {
        setBusy('');
    } }
    return _jsxs("div", { dir: "rtl", style: { maxWidth: 650, margin: '30px auto', padding: spacing.lg }, children: [_jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629" }), _jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0646\u0633\u062E \u0627\u0644\u0627\u062D\u062A\u064A\u0627\u0637\u064A" }), _jsx("p", { style: { color: colors.textMuted, fontSize: 13 }, children: "\u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u0644\u0645\u0627\u0644\u0643\u0629 \u0641\u0642\u0637\u060C \u0648\u0644\u064A\u0633\u062A \u0636\u0645\u0646 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u064A\u0648\u0645\u064A \u0644\u0644\u0645\u0639\u0644\u0645\u0629 \u0623\u0648 \u0627\u0644\u0625\u062F\u0627\u0631\u0629." }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: 10 }, children: error }), msg && _jsx("div", { style: { background: colors.primaryTint, color: '#0b5c33', padding: 10, borderRadius: radius.button, marginBottom: 10 }, children: msg }), _jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg }, children: [_jsx("label", { children: "\u0627\u0644\u0645\u062F\u0631\u0633\u0629" }), _jsx("select", { value: schoolId, onChange: e => setSchoolId(e.target.value), style: { width: '100%', padding: 10, margin: '6px 0 14px' }, children: schools.map(s => _jsxs("option", { value: s.id, children: [s.name, " \u2014 ", s.schoolCode || ''] }, s.id)) }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: [_jsx("button", { onClick: () => exp('json'), disabled: !!busy || !schoolId, style: { padding: '10px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: busy === 'json' ? '...' : 'تنزيل نسخة JSON للاستعادة' }), _jsx("button", { onClick: () => exp('excel'), disabled: !!busy || !schoolId, style: { padding: '10px 14px', background: '#fff', color: colors.ink, border: `1px solid ${colors.border}`, borderRadius: radius.button }, children: busy === 'excel' ? '...' : 'تنزيل نسخة Excel' }), _jsxs("label", { style: { padding: '10px 14px', background: colors.redTint, color: colors.red, border: `1px solid ${colors.redBorder}`, borderRadius: radius.button, cursor: 'pointer' }, children: [busy === 'restore' ? 'جارٍ الاستعادة...' : 'استعادة من JSON', _jsx("input", { type: "file", accept: "application/json,.json", onChange: restore, disabled: !!busy, style: { display: 'none' } })] })] }), _jsx("p", { style: { fontSize: 11, color: colors.textMuted, marginBottom: 0, marginTop: 12 }, children: "\u0627\u062D\u062A\u0641\u0638\u064A \u0628\u0645\u0644\u0641 JSON \u0641\u064A \u0645\u0643\u0627\u0646 \u0622\u0645\u0646. \u0627\u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0639\u0645\u0644\u064A\u0629 \u062D\u0633\u0627\u0633\u0629 \u0648\u062A\u062D\u062A\u0627\u062C \u062A\u0623\u0643\u064A\u062F\u064A\u0646 \u0642\u0628\u0644 \u0627\u0644\u062A\u0646\u0641\u064A\u0630." })] })] });
}
