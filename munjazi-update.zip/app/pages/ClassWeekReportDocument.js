import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Document, Page, Text, View, StyleSheet, Font, Link } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';
Font.register({
    family: 'Plex',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf',
});
Font.register({
    family: 'Plex-Bold',
    src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf',
});
Font.registerHyphenationCallback((word) => [word]);
const STATUS_STYLE = {
    mastered: { bg: '#eaf6ee', text: '#0b5c33', border: '#0b7a4b' },
    needsSupport: { bg: '#fff7e0', text: '#8a6d00', border: '#d9b400' },
    notMastered: { bg: '#fdecea', text: '#a10000', border: '#c62828' },
    absent: { bg: '#f2f2f2', text: '#666', border: '#ccc' },
};
const HEADER_BG = '#14261e';
const HEADER_DIVIDER = '#3a4a42';
const ROW_BORDER = '#e0e0e0';
const COL_BORDER = '#cfcfcf';
const styles = StyleSheet.create({
    page: { fontFamily: 'Plex', paddingTop: 168, paddingBottom: 40, paddingHorizontal: 24, fontSize: 9 },
    fixedHeaderBlock: {
        position: 'absolute', top: 14, left: 24, right: 24,
    },
    reportLogo: { position: 'absolute', top: 0, right: 0, width: 72, height: 33, objectFit: 'contain' },
    schoolName: { fontFamily: 'Plex-Bold', fontSize: 15, color: '#14261e', textAlign: 'center', lineHeight: 1.3 },
    headerLine: { fontSize: 9, color: '#555', textAlign: 'center', marginTop: 3, lineHeight: 1.3 },
    reportTitle: { fontFamily: 'Plex-Bold', fontSize: 14, color: '#0b7a4b', textAlign: 'center', marginTop: 8, marginBottom: 3 },
    metaLine: { fontSize: 8, color: '#666', textAlign: 'center', marginBottom: 2 },
    linkText: { color: '#0b7a4b', textDecoration: 'underline' },
    statsRow: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 8, fontSize: 8 },
    columnHeaderRow: {
        flexDirection: 'row-reverse',
        backgroundColor: HEADER_BG,
        borderWidth: 1, borderColor: HEADER_BG,
        paddingVertical: 5,
    },
    headerCellWrap: {
        borderLeftWidth: 0.75, borderLeftColor: HEADER_DIVIDER, paddingHorizontal: 3,
    },
    headerCell: {
        fontFamily: 'Plex-Bold', fontSize: 9, textAlign: 'center', color: '#ffffff', lineHeight: 1.35,
    },
    headerCellFirst: { textAlign: 'right', paddingRight: 6 },
    englishHeader: { direction: 'ltr', textAlign: 'center' },
    headerCellSource: {
        fontFamily: 'Plex', fontSize: 6.5, textAlign: 'center', color: '#b9c4bf', marginTop: 1,
    },
    row: {
        flexDirection: 'row-reverse', minHeight: 20, alignItems: 'center',
        borderLeftWidth: 1, borderRightWidth: 1, borderBottomWidth: 0.75,
        borderColor: ROW_BORDER,
    },
    rowEven: { backgroundColor: '#fafafa' },
    cell: {
        fontSize: 9, textAlign: 'right', paddingHorizontal: 4, paddingVertical: 3,
        borderLeftWidth: 0.75, borderLeftColor: COL_BORDER,
    },
    badge: {
        paddingHorizontal: 6, paddingVertical: 2.5, borderRadius: 4, borderWidth: 1,
        alignSelf: 'center', minWidth: 44, alignItems: 'center',
    },
    badgeText: { fontSize: 9, fontFamily: 'Plex-Bold' },
    footer: {
        position: 'absolute', bottom: 14, left: 24, right: 24,
        flexDirection: 'row-reverse',
        fontSize: 8, color: '#333', borderTop: 0.5, borderTopColor: '#ccc', paddingTop: 6,
    },
    footerColRight: { flex: 1, textAlign: 'right' },
    footerColCenter: { flex: 1, textAlign: 'center' },
    footerColLeft: { flex: 1, textAlign: 'left' },
});
const TYPE_LABELS_AR = { measurement: 'قياس', remediation: 'معالجة' };
function StatusBadge({ status, statusLabel }) {
    const s = STATUS_STYLE[status] || { bg: '#f2f2f2', text: '#666', border: '#ccc' };
    return (_jsx(View, { style: [styles.badge, { backgroundColor: s.bg, borderColor: s.border }], children: _jsx(Text, { style: [styles.badgeText, { color: s.text }], children: statusLabel }) }));
}
const STATUS_KEYS = [
    { key: 'mastered', label: 'متقنة' },
    { key: 'needsSupport', label: 'تحتاج متابعة' },
    { key: 'notMastered', label: 'غير متقنة' },
    { key: 'absent', label: 'غائبة' },
    { key: 'unassessed', label: 'غير مرصودة' },
];
function columnWidths(skillCount, includeActions) {
    const nameW = 14;
    const recW = includeActions ? 18 : 22;
    const actionW = includeActions ? 14 : 0;
    const remaining = 100 - nameW - recW - actionW;
    const skillW = remaining / Math.max(skillCount, 1);
    return { nameW, recW, actionW, skillW };
}
export default function ClassWeekReportDocument({ data, reportTypeLabel }) {
    const includeActions = data.rows.some((row) => (row.activeActions || []).length > 0);
    const { nameW, recW, actionW, skillW } = columnWidths(data.skillTitles.length, includeActions);
    const skillSources = data.skillSources || [];
    return (_jsx(Document, { children: _jsxs(Page, { size: "A4", orientation: "landscape", style: styles.page, children: [_jsxs(View, { style: styles.fixedHeaderBlock, fixed: true, children: [_jsx(ReportLogo, { style: styles.reportLogo }), _jsx(Text, { style: styles.schoolName, children: data.schoolName }), _jsxs(Text, { style: styles.headerLine, children: ["\u0627\u0644\u0645\u0627\u062F\u0629: ", data.subject || 'غير محددة'] }), _jsx(Text, { style: styles.headerLine, children: data.weekName }), _jsx(Text, { style: styles.reportTitle, children: reportTypeLabel }), data.enrichmentLink && (_jsxs(Text, { style: styles.metaLine, children: ["\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0625\u062B\u0631\u0627\u0626\u064A: ", _jsx(Link, { src: data.enrichmentLink, style: styles.linkText, children: data.enrichmentLink })] })), _jsx(View, { style: styles.statsRow, children: [_jsxs(Text, { children: ["إجمالي الطالبات: ", Object.values(data.classCounts || {}).reduce((sum, n) => sum + (Number(n) || 0), 0)] }), ...STATUS_KEYS.map((s) => (_jsxs(Text, { children: [s.label, ": ", data.classCounts[s.key] || 0, " \u0637\u0627\u0644\u0628\u0629"] }, s.key)))] }), _jsxs(View, { style: styles.columnHeaderRow, children: [_jsx(View, { style: [styles.headerCellWrap, { width: `${nameW}%` }], children: _jsx(Text, { style: [styles.headerCell, styles.headerCellFirst], children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }) }), data.skillTitles.map((t, i) => {
                                    const source = skillSources[i];
                                    return (_jsxs(View, { style: [styles.headerCellWrap, { width: `${skillW}%` }], children: [_jsx(Text, { style: [styles.headerCell, styles.englishHeader], children: t }), source && (_jsxs(Text, { style: styles.headerCellSource, children: ["(", source.name, " \u2014 ", TYPE_LABELS_AR[source.type] || source.type, ")"] }))] }, i));
                                }), _jsx(View, { style: [styles.headerCellWrap, { width: `${recW}%` }], children: _jsx(Text, { style: styles.headerCell, children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0629" }) }), includeActions && _jsx(View, { style: [styles.headerCellWrap, { width: `${actionW}%` }], children: _jsx(Text, { style: styles.headerCell, children: "\u0627\u0644\u0625\u062C\u0631\u0627\u0621" }) })] })] }), data.rows.map((row, i) => (_jsxs(View, { style: [styles.row, i % 2 === 1 && styles.rowEven], wrap: false, children: [_jsx(Text, { style: [styles.cell, { width: `${nameW}%`, textAlign: 'right' }], children: row.name }), row.cells.map((c, j) => (_jsx(View, { style: [styles.cell, { width: `${skillW}%`, paddingVertical: 4 }], children: _jsx(StatusBadge, { status: c.status, statusLabel: c.statusLabel }) }, j))), _jsx(Text, { style: [styles.cell, { width: `${recW}%`, fontSize: 8, textAlign: 'right', lineHeight: 1.35 }], children: row.recommendation }), includeActions && _jsx(View, { style: [styles.cell, { width: `${actionW}%` }], children: (row.activeActions || []).map((a, k) => (_jsxs(Text, { style: { fontSize: 7, color: a.type === 'remedial' ? '#8a5a00' : '#0b5c33' }, children: [a.type === 'remedial' ? '⚠' : '⭐', " ", a.affectedSkillTitles.join('، '), ": ", a.text] }, k))) })] }, i))), _jsxs(View, { style: styles.footer, fixed: true, children: [_jsxs(Text, { style: styles.footerColRight, children: ["\u0645\u062F\u064A\u0631\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629: ", data.principalName || '—'] }), _jsxs(Text, { style: styles.footerColCenter, children: ["\u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629: ", data.teacherName] }), _jsx(Text, { style: styles.footerColLeft, render: ({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}` })] })] }) }));
}
