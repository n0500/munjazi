import React from 'react';
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';

Font.register({ family: 'Plex', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf' });
Font.register({ family: 'Plex-Bold', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf' });
Font.registerHyphenationCallback((word) => [word]);

const styles = StyleSheet.create({
  page: { fontFamily: 'Plex', paddingTop: 98, paddingBottom: 40, paddingHorizontal: 30, fontSize: 9, color: '#14261e' },
  header: { position: 'absolute', top: 15, left: 30, right: 30 },
  logo: { position: 'absolute', top: 0, right: 0, width: 68, height: 31, objectFit: 'contain' },
  school: { fontFamily: 'Plex-Bold', fontSize: 13, textAlign: 'center' },
  title: { fontFamily: 'Plex-Bold', fontSize: 15, color: '#0b7a4b', textAlign: 'center', marginTop: 7 },
  meta: { fontSize: 8.5, color: '#555', textAlign: 'center', marginTop: 3 },
  section: { fontFamily: 'Plex-Bold', fontSize: 11, color: '#0b5c33', textAlign: 'right', marginTop: 12, marginBottom: 7 },
  cards: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 7 },
  card: { width: '23.5%', borderWidth: 1, borderColor: '#d7dfdb', borderRadius: 6, padding: 8, alignItems: 'center', minHeight: 48 },
  cardValue: { fontFamily: 'Plex-Bold', fontSize: 14, color: '#0b5c33' },
  cardLabel: { fontSize: 7.3, color: '#666', marginTop: 2, textAlign: 'center' },
  cycle: { borderWidth: 1, borderColor: '#dfe9e3', backgroundColor: '#fbfdfc', borderRadius: 6, padding: 10, textAlign: 'right', lineHeight: 1.65 },
  impactBox: { borderWidth: 1.2, borderColor: '#0b7a4b', borderRadius: 7, padding: 10, marginTop: 5 },
  impactTitle: { fontFamily: 'Plex-Bold', fontSize: 10.5, color: '#0b5c33', textAlign: 'right', marginBottom: 6 },
  impactLine: { fontSize: 9, textAlign: 'right', lineHeight: 1.6 },
  table: { borderWidth: 1, borderColor: '#ddd' },
  row: { flexDirection: 'row-reverse', borderBottomWidth: 0.5, borderBottomColor: '#ddd', minHeight: 24, alignItems: 'center' },
  head: { backgroundColor: '#14261e' },
  cell: { paddingHorizontal: 4, paddingVertical: 4, borderLeftWidth: 0.5, borderLeftColor: '#ddd', textAlign: 'center', fontSize: 7.5 },
  headText: { color: '#fff', fontFamily: 'Plex-Bold', fontSize: 7.2 },
  cClass: { width: '25%', textAlign: 'right' }, cSubject: { width: '18%' }, cWeek: { width: '18%' }, cPct: { width: '13%' }, cChange: { width: '13%' },
  statement: { borderWidth: 1, borderColor: '#cfdad4', backgroundColor: '#f8fbf9', borderRadius: 6, padding: 10, lineHeight: 1.7, textAlign: 'right' },
  footer: { position: 'absolute', bottom: 14, left: 30, right: 30, borderTopWidth: 0.5, borderTopColor: '#ccc', paddingTop: 6, flexDirection: 'row-reverse', fontSize: 7.5, color: '#444' },
  f1: { flex: 1, textAlign: 'right' }, f2: { flex: 1, textAlign: 'center' }, f3: { flex: 1, textAlign: 'left' },
});

function metric(v, suffix = '') { return v === null || v === undefined ? '—' : `${v}${suffix}`; }

function Header({ data }) {
  return <View style={styles.header} fixed>
    <ReportLogo style={styles.logo} />
    <Text style={styles.school}>{data.schoolName}</Text>
    <Text style={styles.title}>{data.audience === 'admin' ? 'تقرير الأثر العام — الإدارة' : 'تقرير الأثر العام'}</Text>
    <Text style={styles.meta}>الفترة: من {data.fromWeekName} إلى {data.toWeekName}</Text>
    {data.audience === 'admin'
      ? <Text style={styles.meta}>{data.scopeLabel || 'نطاق التقرير: المدرسة كاملة'}</Text>
      : <Text style={styles.meta}>المعلّمة: {data.teacherName}</Text>}
    <Text style={styles.meta}>تاريخ التقرير: {data.generatedDate}</Text>
  </View>;
}

function Footer({ data }) {
  return <View style={styles.footer} fixed>
    <Text style={styles.f1}>مديرة المدرسة: {data.principalName || '—'}</Text>
    <Text style={styles.f2}>{data.audience === 'admin' ? 'تقرير إشرافي' : `المعلّمة: ${data.teacherName}`}</Text>
    <Text style={styles.f3} render={({ pageNumber, totalPages }) => `صادر من منجزي — صفحة ${pageNumber} من ${totalPages}`} />
  </View>;
}

export default function ImpactReportDocument({ data }) {
  const m = data.metrics || {};
  const summarySentence = m.impactedMeasurementWeeks > 0
    ? `ارتفعت نسبة الإتقان في المهارات التي نُفذت لها معالجة من ${m.baselineImpactMastery}٪ في القياس إلى ${m.latestImpactMastery}٪ في آخر معالجة مرتبطة، بفارق ${m.improvementPoints >= 0 ? '+' : ''}${m.improvementPoints} نقطة مئوية، وتحسن مستوى ${m.improvedStudents} طالبة على الأقل في مهارة واحدة.`
    : 'لا توجد خلال الفترة قياسات مرتبطة بمعالجات مكتملة تسمح بحساب أثر قبل/بعد.';
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <Header data={data} />
        <Text style={styles.section}>ملخص المؤشرات</Text>
        <View style={styles.cards}>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.classes)}</Text><Text style={styles.cardLabel}>فصول مشمولة</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.students)}</Text><Text style={styles.cardLabel}>طالبات</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.measurementWeeks)}</Text><Text style={styles.cardLabel}>أسابيع قياس</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.measuredSkills)}</Text><Text style={styles.cardLabel}>مهارات مقاسة</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.remediationWeeks)}</Text><Text style={styles.cardLabel}>أسابيع معالجة</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.recommendations)}</Text><Text style={styles.cardLabel}>توصيات مسجلة</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.plans)}</Text><Text style={styles.cardLabel}>خطط علاجية</Text></View>
          <View style={styles.card}><Text style={styles.cardValue}>{metric(m.planSuccessRate, '٪')}</Text><Text style={styles.cardLabel}>نجاح الخطط المغلقة</Text></View>
        </View>

        <Text style={styles.section}>دورة التحسين التعليمية</Text>
        <Text style={styles.cycle}>قياس المهارات ← تحليل النتائج وتحديد الاحتياج ← تنفيذ المعالجة ← تقديم التوصيات والخطط العلاجية عند الحاجة ← إعادة الرصد ← متابعة التحسن وتوثيق الأثر.</Text>

        <Text style={styles.section}>الأثر المدعوم بالبيانات</Text>
        <View style={styles.impactBox} wrap={false}>
          <Text style={styles.impactTitle}>نتيجة المعالجات المرتبطة بالقياس</Text>
          <Text style={styles.impactLine}>{summarySentence}</Text>
          <Text style={styles.impactLine}>الخطط العلاجية: {m.activePlans || 0} نشطة، {m.successfulPlans || 0} أغلقت بنجاح، {m.failedPlans || 0} أغلقت دون نجاح.</Text>
        </View>

        <Text style={styles.section}>التوثيق المهني</Text>
        <Text style={styles.statement}>{data.audience === 'admin'
          ? 'يعرض التقرير صورة إشرافية موحدة لمدى توظيف القياس والمعالجة والخطط العلاجية والتوصيات في دعم نواتج التعلم، مع ربط مؤشرات التحسن بالفترة والفصول والمعلمات المشمولة في النطاق.'
          : 'يوثق التقرير توظيف البيانات في اتخاذ قرارات تعليمية قائمة على الاحتياج، وتنفيذ تدخلات علاجية وتوصيات ومتابعات موثقة، ثم قياس أثرها على تحسن مستويات الإتقان؛ ليكون شاهدًا مهنيًا مدعومًا ببيانات منجزي.'}</Text>
        <Footer data={data} />
      </Page>

      <Page size="A4" orientation="landscape" style={styles.page}>
        <Header data={data} />
        <Text style={styles.section}>ملخص الأثر حسب الفصل</Text>
        <View style={styles.table}>
          <View style={[styles.row, styles.head]} fixed>
            <Text style={[styles.cell, styles.cClass, styles.headText]}>الفصل</Text>
            <Text style={[styles.cell, styles.cSubject, styles.headText]}>المادة</Text>
            <Text style={[styles.cell, styles.cWeek, styles.headText]}>آخر رصد في الفترة</Text>
            <Text style={[styles.cell, styles.cPct, styles.headText]}>الإتقان</Text>
            <Text style={[styles.cell, styles.cPct, styles.headText]}>تحتاج متابعة</Text>
            <Text style={[styles.cell, styles.cChange, styles.headText]}>التغير</Text>
          </View>
          {(data.classSummaries || []).map((row, i) => (
            <View key={row.assignmentId || i} style={styles.row} wrap={false}>
              <Text style={[styles.cell, styles.cClass]}>{row.className}</Text>
              <Text style={[styles.cell, styles.cSubject]}>{row.subject}</Text>
              <Text style={[styles.cell, styles.cWeek]}>{row.latest ? `${row.latest.weekName} — ${row.latest.weekTypeLabel}` : 'لا يوجد رصد'}</Text>
              <Text style={[styles.cell, styles.cPct]}>{row.latest ? `${row.latest.masteryPercent}٪` : '—'}</Text>
              <Text style={[styles.cell, styles.cPct]}>{row.latest ? `${row.latest.attentionPercent}٪` : '—'}</Text>
              <Text style={[styles.cell, styles.cChange]}>{row.latest ? `${row.masteryChange > 0 ? '+' : ''}${row.masteryChange} نقطة` : '—'}</Text>
            </View>
          ))}
        </View>
        <Footer data={data} />
      </Page>
    </Document>
  );
}
