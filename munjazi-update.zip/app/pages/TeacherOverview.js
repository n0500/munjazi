import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { getLatestWeekSummary, getWeeksTrend } from '../lib/overviewApi.js';
import { STATUS_LABELS, STATUS_ICONS, STATUS_COLORS } from '../lib/recommendationsApi.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const STATUS_ORDER = ['mastered', 'needsSupport', 'notMastered', 'absent', 'unassessed'];
const STATUS_META = {
    mastered: { label: 'متقنة', icon: '✅', ...STATUS_COLORS.mastered },
    needsSupport: { label: 'تحتاج متابعة', icon: '⚠️', ...STATUS_COLORS.needsSupport },
    notMastered: { label: 'غير متقنة', icon: '❌', ...STATUS_COLORS.notMastered },
    absent: { label: 'غائبة', icon: '🚫', ...STATUS_COLORS.absent },
    unassessed: { label: 'غير مرصودة', icon: '—', bg: '#f7f7f7', text: '#666', border: '#b9b9b9' },
};
function visibleKeys(counts) {
    return STATUS_ORDER.filter((key) => key !== 'unassessed' || (counts.unassessed || 0) > 0);
}
function DonutChart({ counts, total }) {
    const keys = visibleKeys(counts);
    const denominator = Math.max(1, total || keys.reduce((sum, k) => sum + (counts[k] || 0), 0));
    if (!total)
        return _jsx("p", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A \u0628\u0639\u062F." });
    const radiusValue = 45;
    const circumference = 2 * Math.PI * radiusValue;
    let offsetAcc = 0;
    return (_jsxs("svg", { width: "120", height: "120", viewBox: "0 0 120 120", "aria-label": `إجمالي الطالبات ${total}`, children: [_jsx("g", { transform: "rotate(-90 60 60)", children: keys.map((key) => {
                    const value = counts[key] || 0;
                    if (value === 0)
                        return null;
                    const dash = (value / denominator) * circumference;
                    const circle = (_jsx("circle", { cx: "60", cy: "60", r: radiusValue, fill: "none", stroke: STATUS_META[key].border, strokeWidth: "18", strokeDasharray: `${dash} ${circumference - dash}`, strokeDashoffset: -offsetAcc }, key));
                    offsetAcc += dash;
                    return circle;
                }) }), _jsx("text", { x: "60", y: "59", textAnchor: "middle", fontSize: "17", fontWeight: "bold", children: total }), _jsx("text", { x: "60", y: "73", textAnchor: "middle", fontSize: "8", fill: "#666", children: "\u0637\u0627\u0644\u0628\u0629" })] }));
}
function TrendChart({ trend }) {
    if (trend.length === 0)
        return _jsx("p", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0623\u0633\u0627\u0628\u064A\u0639 \u0628\u0639\u062F." });
    const maxCount = Math.max(1, ...trend.flatMap((w) => STATUS_ORDER.map((k) => w.counts[k] || 0)));
    const barMaxHeight = 60;
    return (_jsx("div", { style: { display: 'flex', gap: 12, alignItems: 'flex-end', overflowX: 'auto', padding: '8px 0' }, children: trend.map((w, i) => (_jsxs("div", { style: { textAlign: 'center', minWidth: 64 }, children: [_jsx("div", { style: { display: 'flex', gap: 2, alignItems: 'flex-end', height: barMaxHeight }, children: visibleKeys(w.counts).map((key) => (_jsx("div", { title: `${STATUS_META[key].label}: ${w.counts[key] || 0} طالبة`, style: { width: 8, height: Math.max(2, ((w.counts[key] || 0) / maxCount) * barMaxHeight), background: STATUS_META[key].border, borderRadius: 2 } }, key))) }), _jsx("div", { style: { fontSize: 10, color: colors.textMuted, marginTop: 4, whiteSpace: 'nowrap' }, children: w.weekName })] }, `${w.weekName}-${i}`))) }));
}
function AssignmentOverviewCard({ schoolId, assignment, className }) {
    const [summary, setSummary] = useState(null);
    const [trend, setTrend] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedStatus, setExpandedStatus] = useState(null);
    useEffect(() => {
        (async () => {
            setLoading(true);
            const [s, t] = await Promise.all([
                getLatestWeekSummary(schoolId, assignment.classId, assignment.teacherUid, assignment.id),
                getWeeksTrend(schoolId, assignment.classId, assignment.teacherUid, assignment.id),
            ]);
            setSummary(s);
            setTrend(t);
            setLoading(false);
        })();
    }, [schoolId, assignment.id, assignment.classId, assignment.teacherUid]);
    if (loading)
        return _jsx("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, marginBottom: 12 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    return (_jsxs("div", { style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, marginBottom: 14 }, children: [_jsxs("h3", { style: { marginTop: 0, marginBottom: 4, fontFamily: font.family }, children: [assignment.subject || 'دون تحديد مادة', " \u2014 ", className] }), !summary ? (_jsx("p", { style: { fontSize: 13, color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0631\u0635\u0648\u062F\u0629 \u0628\u0639\u062F." })) : (_jsxs(_Fragment, { children: [_jsxs("p", { style: { fontSize: 12, color: colors.textMuted }, children: ["آخر رصد: ", summary.weekName, " · اكتمال الرصد: ", summary.completionPercent ?? 0, "٪"] }), _jsxs("div", { style: { display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }, children: [_jsx(DonutChart, { counts: summary.counts, total: summary.studentTotal }), _jsx("div", { style: { display: 'flex', flexWrap: 'wrap', gap: 8 }, children: visibleKeys(summary.counts).map((key) => (_jsxs("button", { onClick: () => setExpandedStatus(expandedStatus === key ? null : key), style: { padding: '6px 10px', background: STATUS_META[key].bg, color: STATUS_META[key].text, border: `1px solid ${STATUS_META[key].border}`, borderRadius: 8, fontSize: 12, fontWeight: 'bold' }, children: [STATUS_META[key].icon, " ", STATUS_META[key].label, ": ", summary.counts[key] || 0, " \u0637\u0627\u0644\u0628\u0629"] }, key))) })] }), expandedStatus && (_jsx("div", { style: { marginTop: 10, background: '#f9f9f9', borderRadius: 8, padding: 10 }, children: (summary.studentsByStatus[expandedStatus] || []).length === 0 ? _jsx("span", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0637\u0627\u0644\u0628\u0627\u062A \u0628\u0647\u0630\u0647 \u0627\u0644\u062D\u0627\u0644\u0629." }) : (_jsx("ul", { style: { margin: 0, paddingRight: 18, fontSize: 12 }, children: summary.studentsByStatus[expandedStatus].map((name, i) => _jsx("li", { children: name }, `${name}-${i}`)) })) })), (summary.topSkills || []).length > 0 && (_jsxs("div", { style: { marginTop: 12, padding: 10, border: `1px solid ${colors.amberBorder}`, background: colors.amberTint, borderRadius: 8 }, children: [_jsx("strong", { style: { fontSize: 12, color: colors.ink }, children: "أكثر المهارات التي تحتاج متابعة" }), _jsx("div", { style: { display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 6 }, children: summary.topSkills.map((item) => _jsxs("span", { style: { padding: '4px 8px', background: '#fff', border: `1px solid ${colors.amberBorder}`, borderRadius: 8, fontSize: 11, color: colors.amber }, children: [item.title, " · ", item.count, " طالبة"] }, item.title)) })] })), _jsx("h4", { style: { marginBottom: 4 }, children: "\u0645\u0642\u0627\u0631\u0646\u0629 \u0639\u0628\u0631 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639" }), _jsx(TrendChart, { trend: trend })] }))] }));
}
export default function TeacherOverview({ schoolId, assignments, classNameFor, compact = false }) {
    return (_jsxs("div", { dir: "rtl", children: [!compact && _jsx("h2", { style: { fontFamily: font.family, color: colors.ink }, children: "\u0646\u0638\u0631\u0629 \u0639\u0627\u0645\u0629" }), assignments.length === 0 ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0645 \u064A\u062A\u0645 \u0631\u0628\u0637 \u0623\u064A \u0641\u0635\u0644 \u062F\u0631\u0627\u0633\u064A \u0628\u0639\u062F." }) : assignments.map((a) => (_jsx(AssignmentOverviewCard, { schoolId: schoolId, assignment: a, className: classNameFor(a.classId) }, a.id)))] }));
}
