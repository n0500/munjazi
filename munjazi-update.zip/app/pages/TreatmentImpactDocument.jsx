import React from 'react';
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import ReportLogo from '../components/ReportLogo.js';
Font.register({ family: 'Plex', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Regular.ttf' });
Font.register({ family: 'Plex-Bold', src: 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Bold.ttf' });
Font.registerHyphenationCallback((word) => [word]);
const styles = StyleSheet.create({
  page:{fontFamily:'Plex',paddingTop:96,paddingBottom:38,paddingHorizontal:28,fontSize:9,color:'#14261e'},
  header:{position:'absolute',top:14,left:28,right:28},logo:{position:'absolute',top:0,right:0,width:68,height:31,objectFit:'contain'},school:{fontFamily:'Plex-Bold',fontSize:13,textAlign:'center'},title:{fontFamily:'Plex-Bold',fontSize:15,color:'#0b7a4b',textAlign:'center',marginTop:7},meta:{fontSize:8.5,color:'#555',textAlign:'center',marginTop:3},
  summary:{flexDirection:'row-reverse',gap:8,marginBottom:12},card:{flex:1,borderWidth:1,borderColor:'#d7dfdb',borderRadius:6,padding:8,alignItems:'center'},val:{fontFamily:'Plex-Bold',fontSize:15,color:'#0b5c33'},lab:{fontSize:7.5,color:'#666'},
  table:{borderWidth:1,borderColor:'#ddd'},row:{flexDirection:'row-reverse',borderBottomWidth:.5,borderBottomColor:'#ddd',minHeight:25,alignItems:'center'},head:{backgroundColor:'#14261e'},cell:{padding:4,borderLeftWidth:.5,borderLeftColor:'#ddd',textAlign:'center',fontSize:7.5},ht:{color:'#fff',fontFamily:'Plex-Bold'},skill:{width:'34%',textAlign:'right'},stage:{flex:1},change:{width:'14%'},
  footer:{position:'absolute',bottom:13,left:28,right:28,borderTopWidth:.5,borderTopColor:'#ccc',paddingTop:5,flexDirection:'row-reverse',fontSize:7.5,color:'#444'},f:{flex:1},
});
export default function TreatmentImpactDocument({data}){
  const stageLabels=['القياس',...(data.remediationWeeks||[]).map(w=>w.label)];
  return <Document><Page size="A4" orientation="landscape" style={styles.page}>
    <View style={styles.header} fixed><ReportLogo style={styles.logo}/><Text style={styles.school}>{data.schoolName}</Text><Text style={styles.title}>أثر المعالجة</Text><Text style={styles.meta}>{data.className} — {data.subject} — القياس: {data.measurementWeekName}</Text></View>
    <View style={styles.summary} wrap={false}><View style={styles.card}><Text style={styles.val}>{data.baselineMasteryPercent}٪</Text><Text style={styles.lab}>الإتقان قبل المعالجة</Text></View><View style={styles.card}><Text style={styles.val}>{data.latestMasteryPercent}٪</Text><Text style={styles.lab}>الإتقان في آخر معالجة</Text></View><View style={styles.card}><Text style={styles.val}>{data.improvementPoints>=0?'+':''}{data.improvementPoints}</Text><Text style={styles.lab}>التحسن بالنقاط المئوية</Text></View><View style={styles.card}><Text style={styles.val}>{(data.improvedStudentKeys||[]).length}</Text><Text style={styles.lab}>طالبات تحسن مستواهن</Text></View></View>
    <View style={styles.table}><View style={[styles.row,styles.head]} fixed><Text style={[styles.cell,styles.skill,styles.ht]}>المهارة</Text>{stageLabels.map((x,i)=><Text key={i} style={[styles.cell,styles.stage,styles.ht]}>{x}</Text>)}<Text style={[styles.cell,styles.change,styles.ht]}>التحسن</Text></View>{(data.skills||[]).map((skill)=><View key={skill.skillId} style={styles.row} wrap={false}><Text style={[styles.cell,styles.skill]}>{skill.title}</Text>{stageLabels.map((_,i)=>{const s=skill.stages[i];return <Text key={i} style={[styles.cell,styles.stage]}>{s?`${s.masteryPercent}٪`:'—'}</Text>})}<Text style={[styles.cell,styles.change]}>{skill.improvementPoints>0?'+':''}{skill.improvementPoints} نقطة</Text></View>)}</View>
    <View style={styles.footer} fixed><Text style={[styles.f,{textAlign:'right'}]}>مديرة المدرسة: {data.principalName||'—'}</Text><Text style={[styles.f,{textAlign:'center'}]}>المعلّمة: {data.teacherName}</Text><Text style={[styles.f,{textAlign:'left'}]} render={({pageNumber,totalPages})=>`صادر من منجزي — صفحة ${pageNumber} من ${totalPages}`}/></View>
  </Page></Document>;
}
