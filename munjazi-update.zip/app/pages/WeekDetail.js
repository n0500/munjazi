import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { useEffect, useRef, useState } from 'react';
import { listSkillsForWeek, updateSkillTitle, deleteSkillWithAssessments } from '../lib/skillsApi.js';
import { listAssessmentsForWeek, setAssessment, setAllMasteredForSkill, setAllMasteredForWeek, recomputeWeekSummary } from '../lib/assessmentsApi.js';
import { listClassStudents } from '../lib/studentsApi.js';
import { updateWeek, addSkillsToAssignments } from '../lib/weeksApi.js';
import { STATUS_LABELS, STATUS_ICONS, STATUS_COLORS, ENCOURAGEMENT_MESSAGES, pickRandomEncouragement, listAllRecommendationsForStatus, addCustomRecommendation } from '../lib/recommendationsApi.js';
import { listRecommendationsForWeek, setWeekRecommendation, autoFillEncouragementForMastered, worstStatus } from '../lib/weekRecommendationsApi.js';
import { normalizeSubject } from '../lib/dataLogic.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
const TYPE_LABELS = { measurement: 'قياس', remediation: 'معالجة' };
const NEW_RECOMMENDATION_VALUE = '__new__';
export default function WeekDetail({ schoolId, assignment, allAssignments, historicalAssignments = allAssignments, classNameFor, week, onBack }) {
    const { classId, teacherUid } = assignment;
    const assignmentId = assignment.id;
    const [students, setStudents] = useState([]);
    const [skills, setSkills] = useState([]);
    const [assessmentsBySkill, setAssessmentsBySkill] = useState({});
    const [weekRecommendations, setWeekRecommendations] = useState({});
    const [recommendationsByStatus, setRecommendationsByStatus] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [showSkillsMenu, setShowSkillsMenu] = useState(false);
    const [showAddSkills, setShowAddSkills] = useState(false);
    const [skillsEditMode, setSkillsEditMode] = useState(false);
    const [editingSkillId, setEditingSkillId] = useState(null);
    const [editSkillTitleValue, setEditSkillTitleValue] = useState('');
    const [savingSkillTitle, setSavingSkillTitle] = useState(false);
    const [deletingSkillId, setDeletingSkillId] = useState(null);
    const [editingLink, setEditingLink] = useState(false);
    const [linkDraft, setLinkDraft] = useState(week.enrichmentLink || '');
    const [savingLink, setSavingLink] = useState(false);
    const [skillsText, setSkillsText] = useState('');
    const [targetAssignmentIds, setTargetAssignmentIds] = useState(new Set([assignmentId]));
    const [addingSkills, setAddingSkills] = useState(false);
    const [addSkillsResult, setAddSkillsResult] = useState(null);
    const [saveState, setSaveState] = useState('saved');
    const [masteringAll, setMasteringAll] = useState(false);
    const [autoFilling, setAutoFilling] = useState(false);
    const [undoSnapshot, setUndoSnapshot] = useState(null);
    const [undoSeconds, setUndoSeconds] = useState(0);
    const summaryTimer = useRef(null);
    const undoTimer = useRef(null);
    const pendingStorageKey = `munjazi_pending_${schoolId}_${week.id}`;
    const sameSubjectAssignments = allAssignments.filter((a) => a.teacherUid === teacherUid && normalizeSubject(a.subject) === normalizeSubject(assignment.subject));
    function pendingRows() { try {
        return JSON.parse(localStorage.getItem(pendingStorageKey) || '[]');
    }
    catch {
        return [];
    } }
    function savePendingRows(rows) { if (!rows.length)
        localStorage.removeItem(pendingStorageKey);
    else
        localStorage.setItem(pendingStorageKey, JSON.stringify(rows)); }
    function queuePendingAssessment(payload) { const rows = pendingRows().filter((x) => `${x.skillId}_${x.studentId}` !== `${payload.skillId}_${payload.studentId}`); rows.push(payload); savePendingRows(rows); }
    function removePendingAssessment(skillId, studentId) { savePendingRows(pendingRows().filter((x) => `${x.skillId}_${x.studentId}` !== `${skillId}_${studentId}`)); }
    function scheduleSummaryRefresh() { if (summaryTimer.current)
        clearTimeout(summaryTimer.current); summaryTimer.current = setTimeout(() => recomputeWeekSummary(schoolId, week.id).catch(() => { }), 700); }
    async function flushPendingAssessments() {
        const rows = pendingRows();
        if (!rows.length) {
            setSaveState('saved');
            return;
        }
        setSaveState('saving');
        const failed = [];
        for (const row of rows) {
            try {
                await setAssessment(schoolId, { ...row, skipSummary: true });
            }
            catch {
                failed.push(row);
            }
        }
        savePendingRows(failed);
        if (failed.length)
            setSaveState('error');
        else {
            scheduleSummaryRefresh();
            setSaveState('saved');
        }
    }
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const [studentRows, skillRows] = await Promise.all([listClassStudents(schoolId, classId), listSkillsForWeek(schoolId, week.id)]);
            setStudents(studentRows);
            setSkills(skillRows);
            if (skillRows.length === 0)
                setShowAddSkills(true);
            const assessMap = await listAssessmentsForWeek(schoolId, week.id);
            skillRows.forEach((skill) => { if (!assessMap[skill.id])
                assessMap[skill.id] = {}; });
            setAssessmentsBySkill(assessMap);
            const recMap = await listRecommendationsForWeek(schoolId, week.id);
            const lib = {};
            await Promise.all(['needsSupport', 'notMastered', 'absent'].map(async (status) => { lib[status] = await listAllRecommendationsForStatus(schoolId, teacherUid, status); }));
            setRecommendationsByStatus(lib);
            // أصلحي أي توصية قديمة أصبحت لا تناسب حالة الطالبة الحالية.
            // نحافظ على النصوص الحرة التي كتبتها المعلمة، لكن نمسح/نستبدل
            // رسائل المكتبة المعروفة إذا تغيّر تصنيف الرصد.
            const correctedRecMap = { ...recMap };
            const recWrites = [];
            const knownStatusForText = (text) => {
                const trimmed = (text || '').trim();
                if (!trimmed) return null;
                if (ENCOURAGEMENT_MESSAGES.includes(trimmed)) return 'mastered';
                for (const status of ['needsSupport', 'notMastered', 'absent']) {
                    if ((lib[status] || []).some((r) => (r.text || '').trim() === trimmed)) return status;
                }
                return null;
            };
            studentRows.forEach((student) => {
                const statuses = skillRows.map((sk) => assessMap[sk.id]?.[student.id]?.status).filter(Boolean);
                const fullyMastered = skillRows.length > 0 && statuses.length === skillRows.length && statuses.every((st) => st === 'mastered');
                const adverseStatuses = statuses.filter((st) => st !== 'mastered');
                const relevantStatus = fullyMastered ? null : worstStatus(adverseStatuses);
                const currentText = correctedRecMap[student.id] || '';
                const knownStatus = knownStatusForText(currentText);
                let replacement = null;
                if (fullyMastered) {
                    // إذا أصبحت الطالبة متقنة بالكامل، فلا نُبقي أي توصية علاجية/قديمة.
                    // رسالة الشكر هي النص الصحيح الوحيد لهذه الحالة، حتى لو كانت التوصية السابقة
                    // نصًا حرًا أو من مكتبة قديمة لا نستطيع تصنيفها بالنص.
                    if (!ENCOURAGEMENT_MESSAGES.includes(currentText.trim())) replacement = pickRandomEncouragement();
                } else if (knownStatus === 'mastered' || (knownStatus && relevantStatus && knownStatus !== relevantStatus) || (knownStatus && !relevantStatus)) {
                    replacement = '';
                }
                if (replacement !== null && replacement !== currentText) {
                    correctedRecMap[student.id] = replacement;
                    recWrites.push(setWeekRecommendation(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, studentId: student.id, text: replacement }));
                }
            });
            setWeekRecommendations(correctedRecMap);
            if (recWrites.length) await Promise.allSettled(recWrites);
            if (pendingRows().length)
                flushPendingAssessments().catch(() => { });
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل بيانات الأسبوع الدراسي.');
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => { setLinkDraft(week.enrichmentLink || ''); setTargetAssignmentIds(new Set([assignmentId])); refresh(); }, [week.id, assignmentId]);
    useEffect(() => { const fn = () => { if (pendingRows().length)
        flushPendingAssessments().catch(() => { }); }; window.addEventListener('online', fn); return () => window.removeEventListener('online', fn); }, [week.id, assignmentId]);
    useEffect(() => () => { if (summaryTimer.current)
        clearTimeout(summaryTimer.current); if (undoTimer.current)
        clearInterval(undoTimer.current); }, []);
    function completionStats() {
        const total = students.length * skills.length;
        let recorded = 0;
        skills.forEach((sk) => students.forEach((st) => { if (assessmentsBySkill[sk.id]?.[st.id]?.status)
            recorded++; }));
        return { total, recorded, missing: Math.max(0, total - recorded), percent: total ? Math.round(recorded / total * 100) : 0 };
    }
    function statusesForStudent(studentId) { return skills.map((s) => assessmentsBySkill[s.id]?.[studentId]?.status).filter(Boolean); }
    function isFullyMastered(studentId) { const sts = statusesForStudent(studentId); return skills.length > 0 && sts.length === skills.length && sts.every((st) => st === 'mastered'); }
    function relevantStatusFor(statuses) {
        const adverseStatuses = statuses.filter((st) => st && st !== 'mastered');
        return adverseStatuses.length ? worstStatus(adverseStatuses) : null;
    }
    function toggleTargetAssignment(id) { setTargetAssignmentIds(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; }); }
    async function handleAddSkills(e) {
        e.preventDefault();
        const titles = skillsText.split('\n').map(x => x.trim()).filter(Boolean);
        if (!titles.length || !targetAssignmentIds.size || addingSkills)
            return;
        setAddingSkills(true);
        setError('');
        setAddSkillsResult(null);
        try {
            const results = await addSkillsToAssignments(schoolId, { sourceAssignmentId: assignmentId, sourceWeekId: week.id, targetAssignmentIds: [...targetAssignmentIds], skillTitles: titles });
            setAddSkillsResult(results);
            if (results.some((r) => r.ok && r.assignmentId === assignmentId))
                await refresh();
            if (results.every((r) => r.ok))
                setSkillsText('');
        }
        catch (err) {
            setError(err.message || 'تعذّر إضافة المهارات.');
        }
        finally {
            setAddingSkills(false);
        }
    }
    function startEditSkill(skill) { setEditingSkillId(skill.id); setEditSkillTitleValue(skill.title); }
    async function handleSaveSkillTitle(skillId) { setSavingSkillTitle(true); setError(''); try {
        await updateSkillTitle(schoolId, skillId, editSkillTitleValue);
        setEditingSkillId(null);
        await refresh();
    }
    catch (err) {
        setError(err.message || 'تعذّر تعديل اسم المهارة.');
    }
    finally {
        setSavingSkillTitle(false);
    } }
    async function handleDeleteSkill(skill) {
        if (!window.confirm(`سيتم حذف مهارة "${skill.title}" وجميع الرصد المرتبط بها لهذا الأسبوع. لا يمكن التراجع عن الحذف. هل تريدين المتابعة؟`))
            return;
        setDeletingSkillId(skill.id);
        setError('');
        try {
            await deleteSkillWithAssessments(schoolId, skill.id);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر حذف المهارة.');
        }
        finally {
            setDeletingSkillId(null);
        }
    }
    async function handleStatusChange(skillId, studentId, status) {
        setError('');
        setSaveState('saving');
        const payload = { skillId, weekId: week.id, classId, teacherUid, assignmentId, studentId, status };
        const previousStatuses = skills.map((sk) => assessmentsBySkill[sk.id]?.[studentId]?.status).filter(Boolean);
        const nextStatuses = skills.map((sk) => sk.id === skillId ? status : assessmentsBySkill[sk.id]?.[studentId]?.status).filter(Boolean);
        const wasFullyMastered = skills.length > 0 && previousStatuses.length === skills.length && previousStatuses.every((st) => st === 'mastered');
        const isNowFullyMastered = skills.length > 0 && nextStatuses.length === skills.length && nextStatuses.every((st) => st === 'mastered');
        const previousRelevantStatus = wasFullyMastered ? null : relevantStatusFor(previousStatuses);
        const nextRelevantStatus = isNowFullyMastered ? null : relevantStatusFor(nextStatuses);
        // حدّثي التوصية في الواجهة فورًا مع الرصد، ولا تنتظري رحلة Firebase.
        // هذا يمنع ظهور توصية الحالة السابقة ولو لثوانٍ بعد تغيير الرصد.
        let recommendationUpdate = null;
        if (isNowFullyMastered && !wasFullyMastered) {
            recommendationUpdate = pickRandomEncouragement();
        } else if (!isNowFullyMastered && (wasFullyMastered || previousRelevantStatus !== nextRelevantStatus)) {
            recommendationUpdate = '';
        }
        setAssessmentsBySkill((prev) => ({ ...prev, [skillId]: { ...(prev[skillId] || {}), [studentId]: { ...(prev[skillId]?.[studentId] || {}), status } } }));
        if (recommendationUpdate !== null) {
            setWeekRecommendations((p) => ({ ...p, [studentId]: recommendationUpdate }));
        }
        try {
            await setAssessment(schoolId, { ...payload, skipSummary: true });
            removePendingAssessment(skillId, studentId);
            scheduleSummaryRefresh();
            // احفظي التوصية الموافقة للتصنيف الجديد بعد نجاح حفظ الرصد.
            if (recommendationUpdate !== null) {
                await setWeekRecommendation(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, studentId, text: recommendationUpdate });
            }
            setSaveState(pendingRows().length ? 'error' : 'saved');
        }
        catch (err) {
            // إذا فشل حفظ الرصد نفسه نحفظه محليًا لإعادة المحاولة.
            // أما إذا كان الرصد وصل إلى Firebase وفشلت التوصية فقط، فلن
            // نكرر الرصد؛ سيصحح refresh التوصية في الفتح التالي.
            const currentSavedStatus = assessmentsBySkill[skillId]?.[studentId]?.status || '';
            if (currentSavedStatus !== status) queuePendingAssessment(payload);
            setSaveState('error');
            setError('لم تتم المزامنة بالكامل. التعديل محفوظ وسيعاد التحقق منه تلقائيًا.');
        }
    }
    async function handleSetAllMastered(skillId) { setSaveState('saving'); setError(''); try {
        await setAllMasteredForSkill(schoolId, { skillId, weekId: week.id, classId, teacherUid, assignmentId, studentIds: students.map(s => s.id) });
        await refresh();
        setSaveState('saved');
    }
    catch (err) {
        setSaveState('error');
        setError(err.message || 'تعذّر التعيين الجماعي.');
    } }
    async function handleSetAllMasteredWeek() {
        if (masteringAll || !skills.length || !students.length)
            return;
        setMasteringAll(true);
        setSaveState('saving');
        setError('');
        const snapshot = { assessments: JSON.parse(JSON.stringify(assessmentsBySkill)), recommendations: { ...weekRecommendations } };
        try {
            const studentIds = students.map(s => s.id);
            await setAllMasteredForWeek(schoolId, { skills, weekId: week.id, classId, teacherUid, assignmentId, studentIds });
            await autoFillEncouragementForMastered(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, fullyMasteredStudentIds: studentIds, force: true });
            await refresh();
            setSaveState('saved');
            setUndoSnapshot(snapshot);
            setUndoSeconds(20);
            if (undoTimer.current)
                clearInterval(undoTimer.current);
            undoTimer.current = setInterval(() => setUndoSeconds(n => { if (n <= 1) {
                clearInterval(undoTimer.current);
                setUndoSnapshot(null);
                return 0;
            } return n - 1; }), 1000);
        }
        catch (err) {
            setSaveState('error');
            setError(err.message || 'تعذّر تعيين جميع المهارات كمتقنة.');
        }
        finally {
            setMasteringAll(false);
        }
    }
    async function handleUndoMasterAll() {
        if (!undoSnapshot)
            return;
        setSaveState('saving');
        setError('');
        try {
            const writes = [];
            skills.forEach((sk) => students.forEach((st) => writes.push(setAssessment(schoolId, { skillId: sk.id, weekId: week.id, classId, teacherUid, assignmentId, studentId: st.id, status: undoSnapshot.assessments?.[sk.id]?.[st.id]?.status || null, skipSummary: true }))));
            await Promise.all(writes);
            await Promise.all(students.map(st => setWeekRecommendation(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, studentId: st.id, text: undoSnapshot.recommendations?.[st.id] || '' })));
            await recomputeWeekSummary(schoolId, week.id);
            setUndoSnapshot(null);
            setUndoSeconds(0);
            if (undoTimer.current)
                clearInterval(undoTimer.current);
            await refresh();
            setSaveState('saved');
        }
        catch (err) {
            setSaveState('error');
            setError(err.message || 'تعذّر التراجع.');
        }
    }
    async function handleAutoFillMastered() { setAutoFilling(true); setError(''); try {
        const ids = students.filter(s => isFullyMastered(s.id)).map(s => s.id);
        await autoFillEncouragementForMastered(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, fullyMasteredStudentIds: ids });
        await refresh();
    }
    catch (err) {
        setError(err.message || 'تعذّر إضافة رسائل الشكر.');
    }
    finally {
        setAutoFilling(false);
    } }
    async function handleRecommendationSelect(studentId, status, value) {
        setError('');
        if (!value)
            return;
        if (value === NEW_RECOMMENDATION_VALUE) {
            // الكتابة تتم داخل حقل التوصية نفسه، ثم تُحفظ تلقائيًا
            // كتوصية أسبوعية وتُضاف إلى قائمة توصيات المعلمة لهذه الحالة.
            setWeekRecommendations((p) => ({ ...p, [studentId]: '' }));
            setTimeout(() => document.getElementById(`week-rec-${studentId}`)?.focus(), 0);
            return;
        }
        try {
            setSaveState('saving');
            await setWeekRecommendation(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, studentId, text: value });
            setWeekRecommendations((p) => ({ ...p, [studentId]: value }));
            setSaveState('saved');
        }
        catch (err) {
            setSaveState('error');
            setError(err.message || 'تعذّر حفظ التوصية.');
        }
    }
    function handleRecommendationTextEdit(studentId, text) { setWeekRecommendations((p) => ({ ...p, [studentId]: text })); }
    async function handleRecommendationTextSave(studentId) { try {
        setSaveState('saving');
        const text = (weekRecommendations[studentId] || '').trim();
        await setWeekRecommendation(schoolId, { weekId: week.id, classId, teacherUid, assignmentId, studentId, text });
        // إذا كانت توصية مكتوبة يدويًا لحالة تحتاج تدخلاً، احفظيها تلقائيًا
        // في قائمة توصيات المعلمة حتى تظهر مباشرةً لاحقًا مع التوصيات الجاهزة.
        const statuses = statusesForStudent(studentId);
        const fullyMastered = isFullyMastered(studentId);
        const status = fullyMastered ? null : relevantStatusFor(statuses);
        if (text && status) {
            const existing = recommendationsByStatus[status] || [];
            const alreadyExists = existing.some((rec) => (rec.text || '').trim() === text);
            if (!alreadyExists) {
                const added = await addCustomRecommendation(schoolId, teacherUid, status, text);
                setRecommendationsByStatus((prev) => ({
                    ...prev,
                    [status]: [...(prev[status] || []), { ...added, isDefault: false }],
                }));
            }
        }
        setSaveState('saved');
    }
    catch (err) {
        setSaveState('error');
        setError(err.message || 'تعذّر حفظ التوصية.');
    } }
    async function handleSaveLink() { setSavingLink(true); setSaveState('saving'); setError(''); try {
        await updateWeek(schoolId, week.id, { name: week.name, type: week.type, enrichmentLink: linkDraft });
        week.enrichmentLink = linkDraft.trim();
        setEditingLink(false);
        setSaveState('saved');
    }
    catch (err) {
        setSaveState('error');
        setError(err.message || 'تعذّر حفظ الرابط الإثرائي.');
    }
    finally {
        setSavingLink(false);
    } }
    const stats = completionStats();
    const trackingLabel = stats.recorded === 0 ? 'لم يبدأ' : stats.percent === 100 ? 'مكتمل' : 'جاري الرصد';
    const saveLabel = saveState === 'saving' ? 'جارٍ الحفظ…' : saveState === 'error' ? 'لم تتم المزامنة' : 'تم الحفظ ✓';
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644..." });
    return _jsxs("div", { style: { maxWidth: 1000, width: '100%', boxSizing: 'border-box', margin: '20px auto', padding: spacing.lg, overflowX: 'hidden' }, dir: "rtl", children: [_jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: colors.primary, marginBottom: spacing.sm }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u062F\u0631\u0627\u0633\u064A\u0629" }), _jsxs("h1", { style: { fontFamily: font.family, color: colors.ink, marginBottom: 4 }, children: [week.name, " \u2014 ", _jsx("span", { style: { fontSize: 16, padding: '3px 9px', borderRadius: 999, background: week.type === 'remediation' ? colors.amberTint : colors.primaryTint, color: week.type === 'remediation' ? colors.amber : '#0b5c33' }, children: TYPE_LABELS[week.type] })] }), _jsxs("p", { style: { color: colors.textMuted, marginTop: 0 }, children: [assignment.subject, " \u2014 ", classNameFor(classId)] }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: 10, marginBottom: spacing.md, background: '#fff' }, children: [_jsxs("div", { style: { fontSize: 12 }, children: [_jsx("strong", { children: trackingLabel }), " \u00B7 \u0627\u0643\u062A\u0645\u0627\u0644 ", stats.percent, "\u066A \u00B7 ", stats.missing, " \u063A\u064A\u0631 \u0645\u0631\u0635\u0648\u062F\u0629"] }), _jsxs("div", { style: { display: 'flex', gap: 6, alignItems: 'center' }, children: [_jsx("span", { style: { fontSize: 12, color: saveState === 'error' ? colors.red : saveState === 'saving' ? colors.amber : '#0b5c33' }, children: saveLabel }), saveState === 'error' && _jsx("button", { onClick: flushPendingAssessments, style: { padding: '5px 8px', border: `1px solid ${colors.redBorder}`, background: colors.redTint, color: colors.red, borderRadius: 6, fontSize: 11 }, children: "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629" })] })] }), _jsxs("div", { style: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: spacing.md }, children: [_jsxs("div", { style: { position: 'relative' }, children: [_jsx("button", { onClick: () => setShowSkillsMenu(v => !v), style: { padding: '9px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontWeight: 'bold' }, children: "\u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u25BE" }), showSkillsMenu && _jsxs("div", { style: { position: 'absolute', right: 0, top: '110%', zIndex: 30, minWidth: 165, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, boxShadow: '0 8px 20px rgba(0,0,0,.10)', overflow: 'hidden' }, children: [_jsx("button", { onClick: () => { setShowAddSkills(true); setSkillsEditMode(false); setShowSkillsMenu(false); setAddSkillsResult(null); }, style: { width: '100%', padding: '10px 12px', background: '#fff', border: 'none', textAlign: 'right' }, children: "\u0625\u0636\u0627\u0641\u0629 \u0645\u0647\u0627\u0631\u0627\u062A" }), _jsx("button", { onClick: () => { setSkillsEditMode(true); setShowAddSkills(false); setShowSkillsMenu(false); }, style: { width: '100%', padding: '10px 12px', background: '#fff', border: 'none', borderTop: `1px solid ${colors.border}`, textAlign: 'right' }, children: "\u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A" })] })] }), _jsx("button", { onClick: () => { setLinkDraft(week.enrichmentLink || ''); setEditingLink(true); }, style: { padding: '9px 14px', background: week.enrichmentLink ? colors.primaryTint : colors.amberTint, color: week.enrichmentLink ? '#0b5c33' : colors.amber, border: `1px solid ${week.enrichmentLink ? colors.primary : colors.amberBorder}`, borderRadius: radius.button, fontWeight: 'bold' }, children: week.enrichmentLink ? 'الرابط الإثرائي ✓' : '+ إضافة رابط إثرائي' }), _jsx("button", { onClick: handleAutoFillMastered, disabled: autoFilling, style: { padding: '9px 14px', background: '#fff', border: `1px solid ${colors.border}`, color: colors.ink, borderRadius: radius.button }, children: autoFilling ? '...' : 'شكر المتقنات' })] }), editingLink && _jsxs("div", { style: { display: 'flex', gap: spacing.sm, marginBottom: spacing.md }, children: [_jsx("input", { type: "url", value: linkDraft, onChange: e => setLinkDraft(e.target.value), placeholder: "https://...", style: { flex: 1, padding: spacing.sm } }), _jsx("button", { onClick: handleSaveLink, disabled: savingLink, style: { padding: '8px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: savingLink ? '...' : 'حفظ' }), _jsx("button", { onClick: () => setEditingLink(false), style: { padding: '8px 14px', background: '#f2f2f2', border: 'none', borderRadius: radius.button }, children: "\u0625\u0644\u063A\u0627\u0621" })] }), showAddSkills && _jsxs("div", { style: { border: `1px solid ${colors.primary}`, background: colors.primaryTint, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.lg }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center' }, children: [_jsx("h3", { style: { margin: 0, fontFamily: font.family }, children: "\u0625\u0636\u0627\u0641\u0629 \u0645\u0647\u0627\u0631\u0627\u062A" }), _jsx("button", { onClick: () => setShowAddSkills(false), style: { background: 'none', border: 'none', color: colors.textMuted }, children: "\u0625\u063A\u0644\u0627\u0642" })] }), _jsx("p", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0627\u0643\u062A\u0628\u064A \u0643\u0644 \u0645\u0647\u0627\u0631\u0629 \u0641\u064A \u0633\u0637\u0631\u060C \u0648\u064A\u0645\u0643\u0646 \u062A\u0637\u0628\u064A\u0642 \u0646\u0641\u0633 \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0639\u0644\u0649 \u0639\u062F\u0629 \u0641\u0635\u0648\u0644 \u0644\u0644\u0645\u0627\u062F\u0629 \u0646\u0641\u0633\u0647\u0627." }), _jsxs("form", { onSubmit: handleAddSkills, children: [_jsx("textarea", { value: skillsText, onChange: e => setSkillsText(e.target.value), style: { width: '100%', minHeight: 90, padding: 8, boxSizing: 'border-box', margin: '6px 0 10px' }, placeholder: 'Listening\nReading\nWriting' }), _jsxs("div", { style: { marginBottom: 10 }, children: [_jsx("strong", { style: { fontSize: 13 }, children: "\u0627\u0644\u0641\u0635\u0648\u0644 \u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641\u0629" }), sameSubjectAssignments.map((a) => _jsxs("label", { style: { display: 'flex', gap: 6, alignItems: 'center', padding: '4px 0' }, children: [_jsx("input", { type: "checkbox", checked: targetAssignmentIds.has(a.id), onChange: () => toggleTargetAssignment(a.id) }), classNameFor(a.classId), " ", a.id === assignmentId ? '(الحالي)' : ''] }, a.id))] }), _jsx("button", { type: "submit", disabled: addingSkills || !targetAssignmentIds.size, style: { padding: '9px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: addingSkills ? 'جارٍ الإضافة...' : 'إضافة للفصول المحددة' })] }), addSkillsResult && _jsx("div", { style: { marginTop: 10, fontSize: 12 }, children: addSkillsResult.map((r) => { const a = sameSubjectAssignments.find((x) => x.id === r.assignmentId); return _jsxs("div", { style: { color: r.ok ? '#0b5c33' : colors.red }, children: [classNameFor(a?.classId), ": ", r.ok ? `أضيفت ${r.added}، وتجاوز النظام ${r.skipped} مكررة` : r.error] }, r.assignmentId); }) })] }), students.length === 0 ? _jsx("p", { style: { color: colors.textMuted }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0637\u0627\u0644\u0628\u0627\u062A \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0641\u0635\u0644 \u0628\u0639\u062F." }) : skills.length === 0 ? (showAddSkills ? null : _jsxs("div", { style: { border: `1px dashed ${colors.primary}`, borderRadius: radius.card, padding: 24, textAlign: 'center' }, children: [_jsx("p", { children: "\u0623\u0636\u064A\u0641\u064A \u0645\u0647\u0627\u0631\u0627\u062A \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0644\u0628\u062F\u0621 \u0627\u0644\u0631\u0635\u062F." }), _jsx("button", { onClick: () => setShowAddSkills(true), style: { padding: '10px 18px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: "+ \u0625\u0636\u0627\u0641\u0629 \u0645\u0647\u0627\u0631\u0627\u062A" })] })) : _jsxs(_Fragment, { children: [skillsEditMode && _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, background: '#f7f7f7', border: `1px solid ${colors.border}`, padding: 8, borderRadius: 8, marginBottom: 8 }, children: [_jsx("span", { style: { fontSize: 12 }, children: "\u0648\u0636\u0639 \u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A: \u064A\u0638\u0647\u0631 \u0627\u0644\u062A\u0639\u062F\u064A\u0644 \u0648\u0627\u0644\u062D\u0630\u0641 \u0623\u0633\u0641\u0644 \u0627\u0633\u0645 \u0643\u0644 \u0645\u0647\u0627\u0631\u0629." }), _jsx("button", { onClick: () => { setSkillsEditMode(false); setEditingSkillId(null); }, style: { padding: '5px 9px', border: `1px solid ${colors.border}`, background: '#fff', borderRadius: 6 }, children: "\u0625\u0646\u0647\u0627\u0621" })] }), _jsxs("div", { style: { border: `1px solid ${colors.primary}`, background: colors.primaryTint, borderRadius: radius.card, padding: 12, marginBottom: 10 }, children: [_jsx("button", { onClick: handleSetAllMasteredWeek, disabled: masteringAll, style: { width: '100%', padding: '12px 14px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button, fontWeight: 'bold', fontSize: 15 }, children: masteringAll ? 'جارٍ التعيين...' : '✓ متقن لجميع الطالبات في جميع مهارات الأسبوع' }), _jsx("div", { style: { fontSize: 12, color: colors.textMuted, marginTop: 6 }, children: "\u062B\u0645 \u0639\u062F\u0651\u0644\u064A \u0627\u0644\u0627\u0633\u062A\u062B\u0646\u0627\u0621\u0627\u062A \u0641\u0642\u0637 \u062F\u0627\u062E\u0644 \u0627\u0644\u062C\u062F\u0648\u0644." }), undoSnapshot && _jsxs("button", { onClick: handleUndoMasterAll, style: { marginTop: 8, padding: '6px 10px', background: '#fff', border: `1px solid ${colors.primary}`, color: colors.primary, borderRadius: 6, fontSize: 12 }, children: ["\u062A\u0631\u0627\u062C\u0639 (", undoSeconds, ")"] })] }), _jsxs("div", { style: { display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center', marginBottom: 10 }, children: [_jsx("span", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0639\u0631\u0636:" }), [['all', 'الكل'], ['needsSupport', 'تحتاج متابعة'], ['notMastered', 'غير متقنة'], ['absent', 'غياب'], ['unassessed', 'غير مرصودة']].map(([key, label]) => _jsx("button", { onClick: () => setStatusFilter(key), style: { padding: '6px 10px', background: statusFilter === key ? colors.primaryTint : '#fff', border: `1px solid ${statusFilter === key ? colors.primary : colors.border}`, color: statusFilter === key ? '#0b5c33' : colors.ink, borderRadius: 8, fontSize: 12 }, children: label }, key))] }), _jsx("div", { className: "assessment-table-scroll", style: { maxHeight: '68vh', overflow: 'auto', WebkitOverflowScrolling: 'touch', overscrollBehavior: 'contain' }, children: _jsxs("table", { style: { width: '100%', borderCollapse: 'separate', borderSpacing: 0, minWidth: 680 }, children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { style: { padding: spacing.sm, textAlign: 'right', borderBottom: `2px solid ${colors.border}`, position: 'sticky', right: 0, top: 0, zIndex: 4, background: '#fff' }, children: "\u0627\u0644\u0637\u0627\u0644\u0628\u0629" }), skills.map((s) => _jsx("th", { style: { padding: spacing.sm, borderBottom: `2px solid ${colors.border}`, minWidth: 150, position: 'sticky', top: 0, zIndex: 3, background: '#fff' }, children: editingSkillId === s.id ? _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 4 }, children: [_jsx("input", { value: editSkillTitleValue, onChange: e => setEditSkillTitleValue(e.target.value), style: { padding: 4, fontSize: 12, width: '100%', boxSizing: 'border-box' }, autoFocus: true }), _jsxs("div", { style: { display: 'flex', gap: 4 }, children: [_jsx("button", { onClick: () => handleSaveSkillTitle(s.id), disabled: savingSkillTitle, style: { flex: 1, padding: '2px 6px', fontSize: 11, background: colors.primary, color: '#fff', border: 'none', borderRadius: 6 }, children: savingSkillTitle ? '...' : 'حفظ' }), _jsx("button", { onClick: () => setEditingSkillId(null), style: { flex: 1, padding: '2px 6px', fontSize: 11, background: '#f2f2f2', border: 'none', borderRadius: 6 }, children: "\u0625\u0644\u063A\u0627\u0621" })] })] }) : _jsxs(_Fragment, { children: [_jsx("div", { style: { fontWeight: 'normal' }, children: s.title }), s.sourceWeekName && _jsxs("div", { style: { fontSize: 10, color: colors.textMuted, marginTop: 2 }, children: ["(", s.sourceWeekName, " \u2014 ", TYPE_LABELS[s.sourceWeekType] || s.sourceWeekType, ")"] }), _jsxs("div", { style: { display: 'flex', gap: 4, marginTop: 4, flexWrap: 'wrap', justifyContent: 'center' }, children: [_jsx("button", { onClick: () => handleSetAllMastered(s.id), style: { padding: '2px 6px', fontSize: 10, background: colors.primaryTint, border: `1px solid ${colors.primary}`, color: '#0b5c33', borderRadius: 6 }, children: "\u0645\u062A\u0642\u0646 \u0644\u0644\u0639\u0645\u0648\u062F" }), skillsEditMode && _jsx("button", { onClick: () => startEditSkill(s), style: { padding: '2px 6px', fontSize: 10, background: '#f2f2f2', border: 'none', borderRadius: 6 }, children: "\u062A\u0639\u062F\u064A\u0644" }), skillsEditMode && _jsx("button", { onClick: () => handleDeleteSkill(s), disabled: deletingSkillId === s.id, style: { padding: '2px 6px', fontSize: 10, background: colors.redTint, border: `1px solid ${colors.redBorder}`, color: colors.red, borderRadius: 6 }, children: deletingSkillId === s.id ? '...' : 'حذف' })] })] }) }, s.id)), _jsx("th", { style: { padding: spacing.sm, borderBottom: `2px solid ${colors.border}`, minWidth: 230, position: 'sticky', top: 0, zIndex: 3, background: '#fff' }, children: "\u0627\u0644\u062A\u0648\u0635\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A\u0629" })] }) }), _jsx("tbody", { children: students.filter((student) => { const sts = statusesForStudent(student.id); if (statusFilter === 'all')
                                    return true; if (statusFilter === 'unassessed')
                                    return sts.length < skills.length; return sts.includes(statusFilter); }).map((student, studentIndex) => { const statuses = statusesForStudent(student.id); const fullyMastered = isFullyMastered(student.id); const relevantStatus = fullyMastered ? null : relevantStatusFor(statuses); const options = relevantStatus ? (recommendationsByStatus[relevantStatus] || []) : []; return _jsxs("tr", { style: { borderBottom: `1px solid ${colors.border}` }, children: [_jsxs("td", { style: { padding: spacing.sm, position: 'sticky', right: 0, zIndex: 2, background: '#fff', fontWeight: 600, minWidth: 118, boxShadow: '-1px 0 0 #e7e7e7' }, children: [_jsx("span", { style: { display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 22, borderRadius: 999, background: colors.primaryTint, color: '#0b5c33', fontSize: 10, marginLeft: 6, verticalAlign: 'middle' }, children: studentIndex + 1 }), _jsx("span", { children: student.name })] }), skills.map((s) => { const current = assessmentsBySkill[s.id]?.[student.id]?.status || ''; const c = current ? STATUS_COLORS[current] : null; return _jsx("td", { style: { padding: 6, textAlign: 'center' }, children: _jsxs("select", { value: current, onChange: e => handleStatusChange(s.id, student.id, e.target.value), style: { padding: 4, width: '100%', background: c ? c.bg : '#fff', color: c ? c.text : '#000', border: c ? `1px solid ${c.border}` : '1px solid #ccc', fontWeight: c ? 'bold' : 'normal', borderRadius: 4 }, children: [_jsx("option", { value: "", children: "\u063A\u064A\u0631 \u0645\u0631\u0635\u0648\u062F\u0629" }), Object.entries(STATUS_LABELS).map(([val, label]) => _jsxs("option", { value: val, children: [STATUS_ICONS[val], " ", label] }, val))] }) }, s.id); }), _jsxs("td", { style: { padding: 6 }, children: [options.length > 0 && _jsxs("select", { value: "", onChange: e => handleRecommendationSelect(student.id, relevantStatus, e.target.value), style: { padding: 5, width: '100%', marginBottom: 4, fontSize: 12 }, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0646 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062A\u0648\u0635\u064A\u0627\u062A" }), options.map((rec) => _jsx("option", { value: rec.text, children: rec.text }, rec.id)), _jsx("option", { value: NEW_RECOMMENDATION_VALUE, children: "✎ كتابة توصية جديدة" })] }), _jsx("textarea", { id: `week-rec-${student.id}`, value: weekRecommendations[student.id] || '', onChange: e => handleRecommendationTextEdit(student.id, e.target.value), onBlur: () => handleRecommendationTextSave(student.id), placeholder: fullyMastered ? 'رسالة الشكر تظهر تلقائيًا' : 'اكتبي توصية جديدة — تحفظ تلقائيًا في القائمة', style: { padding: 4, width: '100%', fontSize: 12, minHeight: 42, boxSizing: 'border-box' } })] })] }, student.id); }) })] }) })] })] });
}
