import React, { useEffect, useState } from 'react';
import { getClass } from '../lib/classesApi.js';
import {
    listClassStudents,
    bulkImportStudents,
    addSingleStudent,
    updateStudent,
    deleteStudent,
    moveStudent,
    previewStudentRosterSync,
    syncStudentRoster,
    exportStudentRosterSafetyBackupBlob,
} from '../lib/studentsApi.js';

const h = React.createElement;

function cardStyle(extra = {}) {
    return { border: '1px solid #dfe5e1', borderRadius: 12, padding: 16, marginBottom: 20, background: '#fff', ...extra };
}

function buttonStyle(background = '#0b7a4b', color = '#fff') {
    return { padding: '10px 16px', background, color, border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 700 };
}

function badge(text, tone = 'neutral') {
    const tones = {
        green: { background: '#eaf6ee', color: '#0b5c33', border: '#b8dbc7' },
        amber: { background: '#fff8e5', color: '#7a5a00', border: '#ead18a' },
        red: { background: '#fdecea', color: '#a10000', border: '#efb6af' },
        blue: { background: '#eef5ff', color: '#235b9f', border: '#bed3ef' },
        neutral: { background: '#f5f6f5', color: '#4c5650', border: '#dfe5e1' },
    };
    const t = tones[tone] || tones.neutral;
    return h('span', { style: { display: 'inline-block', padding: '4px 8px', borderRadius: 999, border: `1px solid ${t.border}`, background: t.background, color: t.color, fontSize: 12, fontWeight: 700 } }, text);
}

function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function actionLabel(item, classNameFor) {
    if (item.status === 'add')
        return 'إضافة طالبة جديدة';
    if (item.status === 'recover')
        return 'استعادة وربط سجل قديم';
    const parts = [];
    if (item.flags?.move)
        parts.push(`نقل من ${classNameFor(item.fromClassId)}`);
    if (item.flags?.rename)
        parts.push('تحديث الاسم');
    if (item.flags?.reactivate)
        parts.push('إلغاء الأرشفة');
    if (item.flags?.linkNationalId)
        parts.push('استكمال ربط السجل المدني');
    if (item.flags?.repairIndex)
        parts.push('إصلاح رابط ولي الأمر');
    return parts.length ? parts.join(' + ') : 'موجودة ولا تغيير';
}

export default function ClassDetail({ schoolId, classId, allClasses, onBack }) {
    const [cls, setCls] = useState(null);
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [reportMsg, setReportMsg] = useState('');
    const [pasteText, setPasteText] = useState('');
    const [importing, setImporting] = useState(false);
    const [singleName, setSingleName] = useState('');
    const [singleId, setSingleId] = useState('');
    const [addingSingle, setAddingSingle] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState('');
    const [editId, setEditId] = useState('');

    const [syncText, setSyncText] = useState('');
    const [syncPreview, setSyncPreview] = useState(null);
    const [syncPreviewing, setSyncPreviewing] = useState(false);
    const [syncApplying, setSyncApplying] = useState(false);
    const [syncResult, setSyncResult] = useState(null);

    const classNameFor = (id) => (allClasses || []).find((c) => c.id === id)?.name || 'فصل آخر';

    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const [clsRow, studentRows] = await Promise.all([
                getClass(schoolId, classId),
                listClassStudents(schoolId, classId),
            ]);
            setCls(clsRow);
            setStudents(studentRows);
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل بيانات الفصل.');
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        refresh();
        setSyncPreview(null);
        setSyncResult(null);
        setSyncText('');
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [classId]);

    async function handlePreviewSync() {
        setError('');
        setReportMsg('');
        setSyncResult(null);
        if (!syncText.trim() || syncPreviewing)
            return;
        setSyncPreviewing(true);
        try {
            const preview = await previewStudentRosterSync(schoolId, classId, syncText);
            setSyncPreview(preview);
        }
        catch (err) {
            setError(err.message || 'تعذّرت مقارنة القائمة.');
        }
        finally {
            setSyncPreviewing(false);
        }
    }

    async function handleApplySync() {
        if (!syncPreview?.canApply || syncApplying)
            return;
        const ok = window.confirm('سيتم تحديث القائمة مع الحفاظ على نفس studentId للطالبة الموجودة. لن تُحذف أي طالبة ولن يُحذف أي رصد سابق. هل تريدين الاعتماد؟');
        if (!ok)
            return;
        setSyncApplying(true);
        setError('');
        setSyncResult(null);
        try {
            const safetyBlob = await exportStudentRosterSafetyBackupBlob(schoolId, classId);
            const safeClassName = (cls?.name || 'الفصل').replace(/[\\/:*?"<>|]/g, '-');
            downloadBlob(safetyBlob, `نسخة-أمان-قائمة-${safeClassName}-${new Date().toISOString().slice(0, 10)}.json`);
            const result = await syncStudentRoster(schoolId, classId, syncText);
            setSyncResult(result.verification);
            const nextPreview = await previewStudentRosterSync(schoolId, classId, syncText);
            setSyncPreview(nextPreview);
            await refresh();
        }
        catch (err) {
            if (err.preview)
                setSyncPreview(err.preview);
            setError(err.message || 'تعذّر اعتماد تحديث القائمة.');
        }
        finally {
            setSyncApplying(false);
        }
    }

    async function handleImport() {
        setError('');
        setReportMsg('');
        if (!pasteText.trim() || importing)
            return;
        setImporting(true);
        try {
            const { success, failed, total } = await bulkImportStudents(schoolId, classId, pasteText);
            setReportMsg(`تمت إضافة ${success} من ${total}.` +
                (failed.length ? ` تعذّر إضافة ${failed.length}: ${failed.map((f) => f.name || '؟').join('، ')}` : ''));
            setPasteText('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر استيراد القائمة.');
        }
        finally {
            setImporting(false);
        }
    }

    async function handleAddSingle(e) {
        e.preventDefault();
        setError('');
        if (!singleName.trim() || !singleId.trim() || addingSingle)
            return;
        setAddingSingle(true);
        try {
            await addSingleStudent(schoolId, classId, singleName, singleId);
            setSingleName('');
            setSingleId('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر إضافة الطالبة.');
        }
        finally {
            setAddingSingle(false);
        }
    }

    function startEdit(s) {
        setEditingId(s.id);
        setEditName(s.name);
        setEditId('');
    }

    async function handleSaveEdit(studentId) {
        setError('');
        try {
            await updateStudent(schoolId, studentId, { name: editName, nationalId: editId });
            setEditingId(null);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر حفظ التعديل.');
        }
    }

    async function handleDelete(studentId, name) {
        if (!window.confirm(`سيتم حذف الطالبة "${name}" نهائيًا، ولا يمكن التراجع عن هذا الإجراء. هل الرغبة في المتابعة مؤكدة؟`))
            return;
        setError('');
        try {
            await deleteStudent(schoolId, studentId);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر الحذف.');
        }
    }

    async function handleMove(studentId, newClassId) {
        setError('');
        try {
            await moveStudent(schoolId, studentId, newClassId);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر النقل.');
        }
    }

    if (loading)
        return h('p', { style: { textAlign: 'center', marginTop: 60 } }, 'جارٍ التحميل...');

    const summary = syncPreview?.summary || null;
    const changeItems = (syncPreview?.items || []).filter((x) => x.status !== 'unchanged');

    return h('div', { style: { maxWidth: 720, margin: '20px auto', padding: 16 }, dir: 'rtl' },
        h('button', { onClick: onBack, style: { background: 'none', border: 'none', color: '#0b7a4b', marginBottom: 10, cursor: 'pointer' } }, '← العودة إلى قائمة الفصول'),
        h('h1', null, cls?.name),
        error && h('div', { style: { background: '#fdecea', color: '#a10000', padding: 10, borderRadius: 8, marginBottom: 12 } }, error),
        reportMsg && h('div', { style: { background: '#eaf6ee', color: '#0b5c33', padding: 10, borderRadius: 8, marginBottom: 12 } }, reportMsg),

        h('div', { style: cardStyle({ border: '2px solid #0b7a4b', background: '#fbfefc' }) },
            h('div', { style: { display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', flexWrap: 'wrap' } },
                h('div', null,
                    h('h2', { style: { margin: 0, fontSize: 20, color: '#123b2a' } }, 'تحديث قائمة الطالبات'),
                    h('p', { style: { margin: '6px 0 0', color: '#5b665f', fontSize: 13 } }, 'الموصى به عند وجود طالبات ناقصات أو جديدات أو انتقالات بين الفصول. الرصد السابق لا يُحذف.')
                ),
                badge('آمن للرصد السابق', 'green')
            ),
            h('div', { style: { background: '#eef7f1', borderRadius: 10, padding: 12, margin: '14px 0', fontSize: 13, lineHeight: 1.8 } },
                h('strong', null, 'طريقة الاستخدام: '),
                'الصقي القائمة الرسمية كاملة لهذا الفصل: الاسم ثم السجل المدني. يقبل اللصق من Excel أو سطرًا بصيغة الاسم، السجل المدني.'
            ),
            h('textarea', {
                value: syncText,
                onChange: (e) => { setSyncText(e.target.value); setSyncPreview(null); setSyncResult(null); },
                rows: 8,
                placeholder: 'أضواء ايمن بن محمد القزلان\t1156836668\nألين عبدالله عبدالعزيز الخليفه\t1157129774',
                style: { width: '100%', boxSizing: 'border-box', padding: 12, marginBottom: 10, fontFamily: 'inherit', fontSize: 14, lineHeight: 1.7, borderRadius: 8, border: '1px solid #cfd8d2' },
            }),
            h('button', { onClick: handlePreviewSync, disabled: syncPreviewing || !syncText.trim(), style: buttonStyle() }, syncPreviewing ? 'جارٍ الفحص...' : 'معاينة التحديث'),

            summary && h('div', { style: { marginTop: 16 } },
                h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 8 } },
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20 } }, syncPreview.officialCount), h('div', { style: { fontSize: 12 } }, 'بالقائمة الرسمية')),
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20 } }, summary.unchanged), h('div', { style: { fontSize: 12 } }, 'موجودة بلا تغيير')),
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20, color: '#0b7a4b' } }, summary.add), h('div', { style: { fontSize: 12 } }, 'ستُضاف')),
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20, color: '#7a5a00' } }, summary.move), h('div', { style: { fontSize: 12 } }, 'ستُنقل')),
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20, color: '#235b9f' } }, summary.rename), h('div', { style: { fontSize: 12 } }, 'تحديث اسم')),
                    h('div', { style: cardStyle({ marginBottom: 0, padding: 10, textAlign: 'center' }) }, h('strong', { style: { fontSize: 20, color: summary.extras ? '#7a5a00' : '#0b7a4b' } }, summary.extras), h('div', { style: { fontSize: 12 } }, 'موجودة خارج القائمة'))
                ),

                changeItems.length > 0 && h('div', { style: { marginTop: 14 } },
                    h('h4', { style: { marginBottom: 8 } }, 'التغييرات المقترحة'),
                    ...changeItems.map((item) => h('div', { key: `${item.lineNo}-${item.nationalId}`, style: { display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'center', padding: '9px 0', borderBottom: '1px solid #edf0ee', flexWrap: 'wrap' } },
                        h('div', null, h('strong', null, item.name), h('div', { style: { color: '#778079', fontSize: 12 } }, item.nationalId)),
                        badge(actionLabel(item, classNameFor), item.status === 'add' ? 'green' : item.status === 'recover' ? 'blue' : 'amber')
                    ))
                ),

                syncPreview.extras.length > 0 && h('div', { style: { marginTop: 14, background: '#fff8e5', border: '1px solid #ead18a', borderRadius: 8, padding: 12 } },
                    h('strong', null, 'للمراجعة فقط — لن يتم حذفهن: '),
                    syncPreview.extras.map((x) => x.name).join('، ')
                ),

                (syncPreview.invalidRows.length > 0 || syncPreview.duplicateIds.length > 0 || syncPreview.conflicts.length > 0) && h('div', { style: { marginTop: 14, background: '#fdecea', border: '1px solid #efb6af', borderRadius: 8, padding: 12, color: '#8d1610' } },
                    h('strong', null, 'يوجد ما يمنع الاعتماد:'),
                    h('ul', { style: { marginBottom: 0 } },
                        ...[...syncPreview.invalidRows, ...syncPreview.duplicateIds, ...syncPreview.conflicts].map((row, i) => h('li', { key: i }, `${row.name || `السطر ${row.lineNo}`}: ${row.reason}`))
                    )
                ),

                syncPreview.canApply && h('div', { style: { marginTop: 14 } },
                    h('button', { onClick: handleApplySync, disabled: syncApplying, style: buttonStyle('#123b2a') }, syncApplying ? 'جارٍ الاعتماد والفحص...' : 'اعتماد التحديث'),
                    h('div', { style: { color: '#6a746e', fontSize: 12, marginTop: 7 } }, 'سيتم تنزيل نسخة أمان تلقائيًا قبل أي تعديل. لا يتم حذف الطالبات غير الموجودة في القائمة.')
                )
            ),

            syncResult && h('div', { style: { marginTop: 16, background: syncResult.verified ? '#eaf6ee' : '#fff8e5', border: `1px solid ${syncResult.verified ? '#b8dbc7' : '#ead18a'}`, borderRadius: 10, padding: 14 } },
                h('h3', { style: { margin: '0 0 8px', color: syncResult.verified ? '#0b5c33' : '#7a5a00' } }, syncResult.verified ? '✓ تم التحديث والفحص بنجاح' : 'تم التحديث ويحتاج مراجعة'),
                h('div', { style: { lineHeight: 1.9, fontSize: 13 } },
                    `القائمة الرسمية: ${syncResult.officialCount} — الموجود حاليًا في الفصل: ${syncResult.classCountAfter}.`,
                    h('br'),
                    `الرصد السابق المرتبط بالطالبات الموجودات: ${syncResult.priorAssessmentDataPreserved ? 'محفوظ ✓' : 'يحتاج مراجعة'}.`,
                    h('br'),
                    `تمت مزامنة قائمة الطالبات مع ${syncResult.activeWeeksUpdated || 0} أسبوع مفتوح، لتظهر الطالبات الناقصات في الرصد السابق كغير مرصودات حتى تُكملي تقييمهن.`,
                    h('br'),
                    syncResult.extraCurrentCount > 0 ? `يوجد ${syncResult.extraCurrentCount} سجل/طالبة حالية خارج القائمة الرسمية، ولم يتم حذفها.` : 'لا توجد طالبات إضافيات خارج القائمة الرسمية.'
                )
            )
        ),

        h('div', { style: cardStyle() },
            h('h3', { style: { marginTop: 0 } }, 'إضافة طالبات جديدات فقط (الطريقة القديمة)'),
            h('p', { style: { fontSize: 13, color: '#666' } }, 'استخدمي هذا القسم فقط إذا كنتِ متأكدة أن الطالبات غير موجودات أصلًا في منجزي. لتحديث قائمة كاملة استخدمي القسم الأخضر أعلاه.'),
            h('textarea', { value: pasteText, onChange: (e) => setPasteText(e.target.value), rows: 5, placeholder: 'سارة أحمد المطيري, 1234567890\nنورة سعد القحطاني, 1234567891', style: { width: '100%', boxSizing: 'border-box', padding: 10, marginBottom: 10, fontFamily: 'inherit' } }),
            h('button', { onClick: handleImport, disabled: importing, style: buttonStyle() }, importing ? '...' : 'إضافة الجديدات')
        ),

        h('div', { style: cardStyle() },
            h('h3', { style: { marginTop: 0 } }, 'إضافة طالبة واحدة'),
            h('form', { onSubmit: handleAddSingle, style: { display: 'flex', gap: 8, flexWrap: 'wrap' } },
                h('input', { type: 'text', placeholder: 'الاسم', value: singleName, onChange: (e) => setSingleName(e.target.value), style: { flex: 1, padding: 10, minWidth: 140 }, required: true }),
                h('input', { type: 'text', placeholder: 'السجل المدني', inputMode: 'numeric', value: singleId, onChange: (e) => setSingleId(e.target.value), style: { flex: 1, padding: 10, minWidth: 140 }, required: true }),
                h('button', { type: 'submit', disabled: addingSingle, style: buttonStyle() }, addingSingle ? '...' : 'إضافة')
            )
        ),

        h('h3', null, `الطالبات (${students.length})`),
        students.length === 0
            ? h('p', { style: { color: '#666' } }, 'لا توجد طالبات بهذا الفصل بعد.')
            : students.map((s) => h('div', { key: s.id, style: { border: '1px solid #eee', borderRadius: 8, padding: 10, marginBottom: 8 } },
                editingId === s.id
                    ? h('div', null,
                        h('input', { type: 'text', value: editName, onChange: (e) => setEditName(e.target.value), placeholder: 'الاسم', style: { width: '100%', boxSizing: 'border-box', padding: 8, marginBottom: 6 } }),
                        h('input', { type: 'text', value: editId, onChange: (e) => setEditId(e.target.value), placeholder: 'سجل مدني جديد (اتركيه فارغًا لعدم التغيير)', style: { width: '100%', boxSizing: 'border-box', padding: 8, marginBottom: 6 } }),
                        h('div', { style: { display: 'flex', gap: 6 } },
                            h('button', { onClick: () => handleSaveEdit(s.id), style: buttonStyle() }, 'حفظ'),
                            h('button', { onClick: () => setEditingId(null), style: buttonStyle('#f2f2f2', '#222') }, 'إلغاء')
                        )
                    )
                    : h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 } },
                        h('span', null, s.name),
                        h('div', { style: { display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' } },
                            h('select', { value: classId, onChange: (e) => handleMove(s.id, e.target.value), style: { padding: 4 } }, ...(allClasses || []).map((c) => h('option', { key: c.id, value: c.id }, c.name))),
                            h('button', { onClick: () => startEdit(s), style: buttonStyle('#f2f2f2', '#222') }, 'تعديل'),
                            h('button', { onClick: () => handleDelete(s.id, s.name), style: buttonStyle('#a10000') }, 'حذف')
                        )
                    )
            ))
    );
}
