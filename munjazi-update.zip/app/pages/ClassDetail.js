import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { getClass } from '../lib/classesApi.js';
import { listClassStudents, bulkImportStudents, addSingleStudent, updateStudent, deleteStudent, moveStudent, } from '../lib/studentsApi.js';
export default function ClassDetail({ schoolId, classId, allClasses, onBack }) {
    const [cls, setCls] = useState(null);
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [reportMsg, setReportMsg] = useState('');
    const [pasteText, setPasteText] = useState('');
    const [importing, setImporting] = useState(false);
    const [singleName, setSingleName] = useState('');
    const [singleId, setSingleId] = useState('');
    const [addingSingle, setAddingSingle] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState('');
    const [editId, setEditId] = useState('');
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const [clsRow, studentRows] = await Promise.all([
                getClass(schoolId, classId),
                listClassStudents(schoolId, classId),
            ]);
            setCls(clsRow);
            setStudents(studentRows);
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل بيانات الفصل.');
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [classId]);
    async function handleImport() {
        setError('');
        setReportMsg('');
        if (!pasteText.trim() || importing)
            return;
        setImporting(true);
        try {
            const { success, failed, total } = await bulkImportStudents(schoolId, classId, pasteText);
            setReportMsg(`تمت إضافة ${success} من ${total}.` +
                (failed.length ? ` تعذّر إضافة ${failed.length}: ${failed.map((f) => f.name || '؟').join('، ')}` : ''));
            setPasteText('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر استيراد القائمة.');
        }
        finally {
            setImporting(false);
        }
    }
    async function handleAddSingle(e) {
        e.preventDefault();
        setError('');
        if (!singleName.trim() || !singleId.trim() || addingSingle)
            return;
        setAddingSingle(true);
        try {
            await addSingleStudent(schoolId, classId, singleName, singleId);
            setSingleName('');
            setSingleId('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر إضافة الطالبة.');
        }
        finally {
            setAddingSingle(false);
        }
    }
    function startEdit(s) {
        setEditingId(s.id);
        setEditName(s.name);
        setEditId('');
    }
    async function handleSaveEdit(studentId) {
        setError('');
        try {
            await updateStudent(schoolId, studentId, { name: editName, nationalId: editId });
            setEditingId(null);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر حفظ التعديل.');
        }
    }
    async function handleDelete(studentId, name) {
        if (!window.confirm(`سيتم حذف الطالبة "${name}" نهائيًا، ولا يمكن التراجع عن هذا الإجراء. هل الرغبة في المتابعة مؤكدة؟`))
            return;
        setError('');
        try {
            await deleteStudent(schoolId, studentId);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر الحذف.');
        }
    }
    async function handleMove(studentId, newClassId) {
        setError('');
        try {
            await moveStudent(schoolId, studentId, newClassId);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر النقل.');
        }
    }
    if (loading)
        return _jsx("p", { style: { textAlign: 'center', marginTop: 60 }, children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    return (_jsxs("div", { style: { maxWidth: 600, margin: '20px auto', padding: 16 }, dir: "rtl", children: [_jsx("button", { onClick: onBack, style: { background: 'none', border: 'none', color: '#0b7a4b', marginBottom: 10 }, children: "\u2190 \u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0641\u0635\u0648\u0644" }), _jsx("h1", { children: cls?.name }), error && _jsx("div", { style: { background: '#fdecea', color: '#a10000', padding: 10, borderRadius: 8, marginBottom: 12 }, children: error }), reportMsg && _jsx("div", { style: { background: '#eaf6ee', color: '#0b5c33', padding: 10, borderRadius: 8, marginBottom: 12 }, children: reportMsg }), _jsxs("div", { style: { border: '1px solid #ddd', borderRadius: 10, padding: 16, marginBottom: 20 }, children: [_jsx("h3", { style: { marginTop: 0 }, children: "\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0642\u0627\u0626\u0645\u0629 \u0637\u0627\u0644\u0628\u0627\u062A (\u0644\u0635\u0642)" }), _jsx("p", { style: { fontSize: 13, color: '#666' }, children: "\u0633\u0637\u0631 \u0644\u0643\u0644 \u0637\u0627\u0644\u0628\u0629\u060C \u0628\u0635\u064A\u063A\u0629: \u0627\u0644\u0627\u0633\u0645, \u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0645\u062F\u0646\u064A" }), _jsx("textarea", { value: pasteText, onChange: (e) => setPasteText(e.target.value), rows: 6, placeholder: 'سارة أحمد المطيري, 1234567890\nنورة سعد القحطاني, 1234567891', style: { width: '100%', padding: 10, marginBottom: 10, fontFamily: 'monospace' } }), _jsx("button", { onClick: handleImport, disabled: importing, style: { padding: '10px 20px', background: '#0b7a4b', color: '#fff', border: 'none', borderRadius: 8 }, children: importing ? '...' : 'استيراد' })] }), _jsxs("div", { style: { border: '1px solid #ddd', borderRadius: 10, padding: 16, marginBottom: 20 }, children: [_jsx("h3", { style: { marginTop: 0 }, children: "\u0625\u0636\u0627\u0641\u0629 \u0637\u0627\u0644\u0628\u0629 \u0648\u0627\u062D\u062F\u0629" }), _jsxs("form", { onSubmit: handleAddSingle, style: { display: 'flex', gap: 8, flexWrap: 'wrap' }, children: [_jsx("input", { type: "text", placeholder: "\u0627\u0644\u0627\u0633\u0645", value: singleName, onChange: (e) => setSingleName(e.target.value), style: { flex: 1, padding: 10, minWidth: 140 }, required: true }), _jsx("input", { type: "text", placeholder: "\u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0645\u062F\u0646\u064A", inputMode: "numeric", value: singleId, onChange: (e) => setSingleId(e.target.value), style: { flex: 1, padding: 10, minWidth: 140 }, required: true }), _jsx("button", { type: "submit", disabled: addingSingle, style: { padding: '10px 16px', background: '#0b7a4b', color: '#fff', border: 'none', borderRadius: 8 }, children: addingSingle ? '...' : 'إضافة' })] })] }), _jsxs("h3", { children: ["\u0627\u0644\u0637\u0627\u0644\u0628\u0627\u062A (", students.length, ")"] }), students.length === 0 ? (_jsx("p", { style: { color: '#666' }, children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0637\u0627\u0644\u0628\u0627\u062A \u0628\u0647\u0630\u0627 \u0627\u0644\u0641\u0635\u0644 \u0628\u0639\u062F." })) : (students.map((s) => (_jsx("div", { style: { border: '1px solid #eee', borderRadius: 8, padding: 10, marginBottom: 8 }, children: editingId === s.id ? (_jsxs("div", { children: [_jsx("input", { type: "text", value: editName, onChange: (e) => setEditName(e.target.value), placeholder: "\u0627\u0644\u0627\u0633\u0645", style: { width: '100%', padding: 8, marginBottom: 6 } }), _jsx("input", { type: "text", value: editId, onChange: (e) => setEditId(e.target.value), placeholder: "\u0633\u062C\u0644 \u0645\u062F\u0646\u064A \u062C\u062F\u064A\u062F (\u0627\u062A\u0631\u0643\u064A\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0639\u062F\u0645 \u0627\u0644\u062A\u063A\u064A\u064A\u0631)", style: { width: '100%', padding: 8, marginBottom: 6 } }), _jsxs("div", { style: { display: 'flex', gap: 6 }, children: [_jsx("button", { onClick: () => handleSaveEdit(s.id), style: { padding: '6px 12px', background: '#0b7a4b', color: '#fff', border: 'none', borderRadius: 6 }, children: "\u062D\u0641\u0638" }), _jsx("button", { onClick: () => setEditingId(null), style: { padding: '6px 12px', background: '#f2f2f2', border: 'none', borderRadius: 6 }, children: "\u0625\u0644\u063A\u0627\u0621" })] })] })) : (_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }, children: [_jsx("span", { children: s.name }), _jsxs("div", { style: { display: 'flex', gap: 6, alignItems: 'center' }, children: [_jsx("select", { value: classId, onChange: (e) => handleMove(s.id, e.target.value), style: { padding: 4 }, children: (allClasses || []).map((c) => (_jsx("option", { value: c.id, children: c.name }, c.id))) }), _jsx("button", { onClick: () => startEdit(s), style: { padding: '4px 10px', background: '#f2f2f2', border: 'none', borderRadius: 6 }, children: "\u062A\u0639\u062F\u064A\u0644" }), _jsx("button", { onClick: () => handleDelete(s.id, s.name), style: { padding: '4px 10px', background: '#a10000', color: '#fff', border: 'none', borderRadius: 6 }, children: "\u062D\u0630\u0641" })] })] })) }, s.id))))] }));
}
