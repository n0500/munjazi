import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase.js';
import { listSchools, createSchool, setSchoolActive } from '../lib/schoolsApi.js';
import { listSchoolTeachers } from '../lib/teachersApi.js';
import { createAdminAccount } from '../lib/auth.js';
import { colors, font, radius, spacing } from '../lib/theme.js';
export default function OwnerDashboard() {
    const [schools, setSchools] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [name, setName] = useState('');
    const [principalName, setPrincipalName] = useState('');
    const [creating, setCreating] = useState(false);
    const [lastCreatedCode, setLastCreatedCode] = useState('');
    const [adminSchoolId, setAdminSchoolId] = useState('');
    const [adminEmail, setAdminEmail] = useState('');
    const [adminPassword, setAdminPassword] = useState('');
    const [adminDisplayName, setAdminDisplayName] = useState('إدارة المدرسة');
    const [creatingAdmin, setCreatingAdmin] = useState(false);
    const [adminCreatedMsg, setAdminCreatedMsg] = useState('');
    const [stats, setStats] = useState({ totalTeachers: 0, totalStudents: 0 });
    const [statsLoading, setStatsLoading] = useState(true);
    async function refresh() {
        setLoading(true);
        setError('');
        try {
            const rows = await listSchools();
            setSchools(rows);
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل قائمة المدارس.');
        }
        finally {
            setLoading(false);
        }
    }
    // يجمع إحصائيات شاملة (معلمات وطالبات) عبر كل المدارس مجتمعة — يعمل بشكل منفصل
    // عن تحميل قائمة المدارس نفسها، لأنه يحتاج استعلامات إضافية لكل مدرسة
    async function loadStats(schoolRows) {
        setStatsLoading(true);
        try {
            let totalTeachers = 0;
            let totalStudents = 0;
            await Promise.all(schoolRows.map(async (school) => {
                const teachers = await listSchoolTeachers(school.id);
                totalTeachers += teachers.length;
                const studentsSnap = await getDocs(collection(db, 'schools', school.id, 'students'));
                const activeStudents = studentsSnap.docs.filter((d) => d.data().archived !== true);
                totalStudents += activeStudents.length;
            }));
            setStats({ totalTeachers, totalStudents });
        }
        catch (err) {
            setError(err.message || 'تعذّر تحميل الإحصائيات الشاملة.');
        }
        finally {
            setStatsLoading(false);
        }
    }
    useEffect(() => {
        refresh();
    }, []);
    useEffect(() => {
        if (!loading && schools.length > 0) {
            loadStats(schools);
        }
        else if (!loading) {
            setStatsLoading(false);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [loading, schools]);
    async function handleCreate(e) {
        e.preventDefault();
        setError('');
        setLastCreatedCode('');
        if (!name.trim() || creating)
            return;
        setCreating(true);
        try {
            const { schoolCode } = await createSchool({ name, principalName });
            setLastCreatedCode(schoolCode);
            setName('');
            setPrincipalName('');
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر إنشاء المدرسة.');
        }
        finally {
            setCreating(false);
        }
    }
    async function handleCreateAdmin(e) {
        e.preventDefault();
        if (creatingAdmin)
            return;
        setCreatingAdmin(true);
        setError('');
        setAdminCreatedMsg('');
        try {
            const result = await createAdminAccount({
                schoolId: adminSchoolId,
                email: adminEmail,
                password: adminPassword,
                displayName: adminDisplayName,
            });
            const schoolName = schools.find((row) => row.id === adminSchoolId)?.name || 'المدرسة';
            setAdminCreatedMsg(`تم إنشاء حساب إدارة ${schoolName} بنجاح: ${result.email}`);
            setAdminEmail('');
            setAdminPassword('');
            setAdminDisplayName('إدارة المدرسة');
        }
        catch (err) {
            setError(err.message || 'تعذّر إنشاء حساب الإدارة.');
        }
        finally {
            setCreatingAdmin(false);
        }
    }
    async function handleToggle(school) {
        setError('');
        try {
            await setSchoolActive(school.id, !school.active);
            await refresh();
        }
        catch (err) {
            setError(err.message || 'تعذّر تحديث حالة المدرسة.');
        }
    }
    const activeSchoolsCount = schools.filter((s) => s.active).length;
    const inactiveSchoolsCount = schools.length - activeSchoolsCount;
    return (_jsxs("div", { style: { maxWidth: 600, margin: '40px auto', padding: spacing.lg }, dir: "rtl", children: [_jsx("h1", { style: { fontFamily: font.family, color: colors.ink }, children: "\u0644\u0648\u062D\u0629 \u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u062F\u0627\u0631\u0633" }), error && (_jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.lg }, children: error })), _jsxs("div", { style: { display: 'flex', gap: spacing.sm, flexWrap: 'wrap', marginBottom: spacing.xl }, children: [_jsxs("div", { style: { flex: '1 1 130px', border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, textAlign: 'center' }, children: [_jsx("div", { style: { fontSize: 22, fontWeight: 'bold', color: colors.ink }, children: schools.length }), _jsx("div", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0645\u062F\u0631\u0633\u0629 \u0625\u062C\u0645\u0627\u0644\u064B\u0627" }), schools.length > 0 && (_jsxs("div", { style: { fontSize: 11, color: colors.textMuted }, children: ["(", activeSchoolsCount, " \u0646\u0634\u0637\u0629", inactiveSchoolsCount > 0 ? `، ${inactiveSchoolsCount} معطّلة` : '', ")"] }))] }), _jsxs("div", { style: { flex: '1 1 130px', border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, textAlign: 'center' }, children: [_jsx("div", { style: { fontSize: 22, fontWeight: 'bold', color: colors.ink }, children: statsLoading ? '...' : stats.totalTeachers }), _jsx("div", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0645\u0639\u0644\u0651\u0645\u0629 \u0625\u062C\u0645\u0627\u0644\u064B\u0627" })] }), _jsxs("div", { style: { flex: '1 1 130px', border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.md, textAlign: 'center' }, children: [_jsx("div", { style: { fontSize: 22, fontWeight: 'bold', color: colors.ink }, children: statsLoading ? '...' : stats.totalStudents }), _jsx("div", { style: { fontSize: 12, color: colors.textMuted }, children: "\u0637\u0627\u0644\u0628\u0629 \u0625\u062C\u0645\u0627\u0644\u064B\u0627" })] })] }), _jsxs("form", { onSubmit: handleCreate, style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.xl }, children: [_jsx("h3", { style: { marginTop: 0, fontFamily: font.family }, children: "\u0625\u0636\u0627\u0641\u0629 \u0645\u062F\u0631\u0633\u0629 \u062C\u062F\u064A\u062F\u0629" }), _jsx("label", { children: "\u0627\u0633\u0645 \u0627\u0644\u0645\u062F\u0631\u0633\u0629" }), _jsx("input", { type: "text", value: name, onChange: (e) => setName(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' }, required: true }), _jsx("label", { children: "\u0627\u0633\u0645 \u0627\u0644\u0645\u062F\u064A\u0631\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)" }), _jsx("input", { type: "text", value: principalName, onChange: (e) => setPrincipalName(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' } }), _jsx("button", { type: "submit", disabled: creating, style: { padding: '10px 20px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: creating ? '...' : 'إنشاء المدرسة' }), lastCreatedCode && (_jsxs("div", { style: { marginTop: spacing.md, background: colors.primaryTint, padding: spacing.sm, borderRadius: radius.button }, children: ["\u062A\u0645 \u0627\u0644\u0625\u0646\u0634\u0627\u0621 \u2705 \u2014 \u0631\u0645\u0632 \u0627\u0644\u0645\u062F\u0631\u0633\u0629: ", _jsx("strong", { style: { fontSize: 18 }, children: lastCreatedCode }), _jsx("br", {}), _jsx("small", { children: "\u064A\u064F\u0631\u062C\u0649 \u062A\u0633\u0644\u064A\u0645 \u0647\u0630\u0627 \u0627\u0644\u0631\u0645\u0632 \u0644\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0644\u0625\u0646\u0634\u0627\u0621 \u062D\u0633\u0627\u0628\u0647\u0627." })] }))] }), _jsxs("form", { onSubmit: handleCreateAdmin, style: { border: `1px solid ${colors.border}`, borderRadius: radius.card, padding: spacing.lg, marginBottom: spacing.xl }, children: [_jsx("h3", { style: { marginTop: 0, fontFamily: font.family }, children: "\u0625\u0646\u0634\u0627\u0621 \u062D\u0633\u0627\u0628 \u0625\u062F\u0627\u0631\u0629 \u0645\u062F\u0631\u0633\u0629" }), _jsx("p", { style: { fontSize: 12, color: colors.textMuted, marginTop: 0 }, children: "\u064A\u064F\u0646\u0634\u0623 \u0627\u0644\u062D\u0633\u0627\u0628 \u062F\u0648\u0646 \u0625\u062E\u0631\u0627\u062C \u0627\u0644\u0645\u0627\u0644\u0643\u0629 \u0645\u0646 \u062C\u0644\u0633\u062A\u0647\u0627 \u0627\u0644\u062D\u0627\u0644\u064A\u0629." }), _jsx("label", { children: "\u0627\u0644\u0645\u062F\u0631\u0633\u0629" }), _jsxs("select", { value: adminSchoolId, onChange: (e) => setAdminSchoolId(e.target.value), required: true, style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' }, children: [_jsx("option", { value: "", children: "\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0645\u062F\u0631\u0633\u0629" }), schools.filter((row) => row.active !== false).map((row) => _jsxs("option", { value: row.id, children: [row.name, " \u2014 ", row.schoolCode] }, row.id))] }), _jsx("label", { children: "\u0627\u0633\u0645 \u0627\u0644\u062D\u0633\u0627\u0628" }), _jsx("input", { value: adminDisplayName, onChange: (e) => setAdminDisplayName(e.target.value), style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' } }), _jsx("label", { children: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A" }), _jsx("input", { type: "email", value: adminEmail, onChange: (e) => setAdminEmail(e.target.value), required: true, style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' } }), _jsx("label", { children: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u0645\u0624\u0642\u062A\u0629" }), _jsx("input", { type: "password", value: adminPassword, onChange: (e) => setAdminPassword(e.target.value), minLength: 6, required: true, style: { width: '100%', padding: spacing.sm, marginBottom: spacing.sm, boxSizing: 'border-box' } }), _jsx("button", { type: "submit", disabled: creatingAdmin, style: { padding: '10px 20px', background: colors.primary, color: '#fff', border: 'none', borderRadius: radius.button }, children: creatingAdmin ? '...جارٍ الإنشاء' : 'إنشاء حساب الإدارة' }), adminCreatedMsg && _jsxs("div", { style: { marginTop: spacing.sm, background: colors.primaryTint, color: '#0b5c33', padding: spacing.sm, borderRadius: radius.button, fontSize: 12 }, children: ["\u2713 ", adminCreatedMsg] })] }), _jsxs("h3", { style: { fontFamily: font.family }, children: ["\u0627\u0644\u0645\u062F\u0627\u0631\u0633 (", schools.length, ")"] }), loading ? (_jsx("p", { children: "...\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644" })) : schools.length === 0 ? (_jsx("p", { children: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u062F\u0627\u0631\u0633 \u0628\u0639\u062F." })) : (_jsxs("table", { style: { width: '100%', borderCollapse: 'collapse' }, children: [_jsx("thead", { children: _jsxs("tr", { style: { borderBottom: `2px solid ${colors.border}`, textAlign: 'right' }, children: [_jsx("th", { style: { padding: spacing.sm }, children: "\u0627\u0644\u0627\u0633\u0645" }), _jsx("th", { style: { padding: spacing.sm }, children: "\u0627\u0644\u0631\u0645\u0632" }), _jsx("th", { style: { padding: spacing.sm }, children: "\u0627\u0644\u062D\u0627\u0644\u0629" }), _jsx("th", { style: { padding: spacing.sm } })] }) }), _jsx("tbody", { children: schools.map((s) => (_jsxs("tr", { style: { borderBottom: '1px solid #eee' }, children: [_jsx("td", { style: { padding: spacing.sm }, children: s.name }), _jsx("td", { style: { padding: spacing.sm, fontFamily: 'monospace' }, children: s.schoolCode }), _jsx("td", { style: { padding: spacing.sm }, children: s.active ? 'نشطة' : 'معطّلة' }), _jsx("td", { style: { padding: spacing.sm }, children: _jsx("button", { onClick: () => handleToggle(s), style: {
                                            padding: '6px 12px',
                                            background: s.active ? colors.red : colors.primary,
                                            color: '#fff',
                                            border: 'none',
                                            borderRadius: 6,
                                        }, children: s.active ? 'تعطيل' : 'تفعيل' }) })] }, s.id))) })] }))] }));
}
