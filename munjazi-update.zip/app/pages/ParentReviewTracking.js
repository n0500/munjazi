import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { pdf } from '@react-pdf/renderer';
import * as XLSX from 'xlsx';
import { listParentReviewAttentionItems } from '../lib/parentReviewAckApi.js';
import ParentReviewPendingReportDocument from './ParentReviewPendingReportDocument.js';
import { colors, font, radius, spacing } from '../lib/theme.js';

function formatDateTime(value) {
    if (!value)
        return '—';
    try {
        const date = value.toDate ? value.toDate() : new Date(value);
        return date.toLocaleString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }
    catch {
        return '—';
    }
}

function safeFilePart(value) {
    return String(value || '').replace(/[\\/:*?"<>|]/g, '-').replace(/\s+/g, '_').slice(0, 80);
}

function downloadPendingReviewExcel(rows) {
    const pending = rows.filter((r) => !r.viewedCurrent);
    if (pending.length === 0)
        return;
    const data = pending.map((r, index) => {
        const base = {
            'م': index + 1,
            'الطالبة': r.studentName,
        };
        base['المعلمة'] = r.teacherName;
        base['المادة'] = r.subject;
        base['الفصل'] = r.className;
        base['الأسبوع'] = r.weekName;
        base['نوع الأسبوع'] = r.weekTypeLabel;
        base['غير متقنة'] = r.notMasteredCount;
        base['تحتاج متابعة'] = r.needsSupportCount;
        base['المهارات'] = r.weakSkills.map((s) => s.title).join('، ');
        base['اطلاع ولي الأمر'] = 'لم يطلع بعد';
        return base;
    });
    const ws = XLSX.utils.json_to_sheet(data);
    ws['!cols'] = Object.keys(data[0] || {}).map((key) => ({
        wch: Math.min(42, Math.max(12, key.length + 4, ...data.map((row) => String(row[key] ?? '').length + 2))),
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'لم يطلع ولي الأمر');
    const date = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, safeFilePart(`تقرير_متابعة_من_لم_يطلع_${date}.xlsx`));
}


async function downloadPendingReviewPdf(rows, schoolName) {
    const pending = rows.filter((r) => !r.viewedCurrent);
    if (pending.length === 0)
        return;
    const generatedDate = new Date().toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' });
    const blob = await pdf(_jsx(ParentReviewPendingReportDocument, { rows: pending, schoolName: schoolName || '', generatedDate: generatedDate })).toBlob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = safeFilePart(`تقرير_متابعة_من_لم_يطلع_${new Date().toISOString().slice(0, 10)}.pdf`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function StatCard({ value, label, tone = 'neutral' }) {
    const toneMap = {
        good: { bg: colors.primaryTint, border: colors.primary, text: '#0b5c33' },
        bad: { bg: colors.redTint, border: colors.redBorder, text: colors.red },
        neutral: { bg: '#f5f6f7', border: colors.border, text: colors.ink },
    };
    const c = toneMap[tone] || toneMap.neutral;
    return (_jsxs("div", { style: { flex: '1 1 100px', textAlign: 'center', border: `1px solid ${c.border}`, borderRadius: radius.card, padding: '10px 6px', background: c.bg }, children: [_jsx("div", { style: { fontSize: 20, fontWeight: 'bold', color: c.text }, children: value }), _jsx("div", { style: { fontSize: 11, color: c.text }, children: label })] }));
}

export default function ParentReviewTracking({ schoolId, teacherUid = null, title = 'اطلاع ولي الأمر على الرصد', adminReportEnabled = false, schoolName = '' }) {
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [filter, setFilter] = useState('all');

    async function refresh() {
        setLoading(true);
        setError('');
        try {
            setRows(await listParentReviewAttentionItems(schoolId, { teacherUid }));
        }
        catch (err) {
            setError(err.message || 'تعذر تحميل متابعة اطلاع ولي الأمر.');
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [schoolId, teacherUid]);

    const viewedCount = rows.filter((r) => r.viewedCurrent).length;
    const pendingCount = rows.length - viewedCount;
    const filtered = rows.filter((r) => filter === 'pending' ? !r.viewedCurrent : filter === 'viewed' ? r.viewedCurrent : true);

    if (loading)
        return _jsx("p", { style: { textAlign: 'center', color: colors.textMuted, margin: '28px 0' }, children: "...جارٍ تحميل متابعة الاطلاع" });

    return (_jsxs("section", { dir: "rtl", style: { marginBottom: spacing.xl }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 6 }, children: [_jsx("h2", { style: { margin: 0, fontFamily: font.family, color: colors.ink, fontSize: 20 }, children: title }), _jsxs("div", { style: { display: 'flex', gap: 6, flexWrap: 'wrap' }, children: [adminReportEnabled && pendingCount > 0 && _jsx("button", { onClick: () => downloadPendingReviewPdf(rows, schoolName), style: { padding: '6px 10px', background: colors.primary, border: 'none', borderRadius: 8, color: '#fff', fontSize: 12, fontWeight: 'bold' }, children: "PDF لمن لم يطلع" }), adminReportEnabled && pendingCount > 0 && _jsx("button", { onClick: () => downloadPendingReviewExcel(rows), style: { padding: '6px 10px', background: '#fff', border: `1px solid ${colors.primary}`, borderRadius: 8, color: colors.primary, fontSize: 12, fontWeight: 'bold' }, children: "Excel لمن لم يطلع" }), _jsx("button", { onClick: refresh, style: { padding: '6px 10px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, color: colors.ink, fontSize: 12 }, children: "تحديث" })] })] }), _jsx("p", { style: { marginTop: 0, color: colors.textMuted, fontSize: 13, lineHeight: 1.7 }, children: "تشمل الطالبات اللاتي لديهن مهارة غير متقنة أو تحتاج متابعة. يحتسب الاطلاع عندما يفتح ولي الأمر تفاصيل المادة، وإذا تغيّر الرصد بعد ذلك تعود الحالة إلى «لم يطلع بعد» حتى يفتح التفاصيل من جديد." }), error && _jsx("div", { style: { background: colors.redTint, color: colors.red, padding: 10, borderRadius: radius.button, marginBottom: spacing.md }, children: error }), _jsxs("div", { style: { display: 'flex', gap: spacing.sm, flexWrap: 'wrap', marginBottom: spacing.md }, children: [_jsx(StatCard, { value: rows.length, label: "حالات تحتاج اطلاع", tone: "neutral" }), _jsx(StatCard, { value: viewedCount, label: "تم الاطلاع", tone: "good" }), _jsx(StatCard, { value: pendingCount, label: "لم يطلع بعد", tone: "bad" })] }), _jsx("div", { style: { display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: spacing.md }, children: [
                    { key: 'all', label: `الكل (${rows.length})` },
                    { key: 'pending', label: `لم يطلع بعد (${pendingCount})` },
                    { key: 'viewed', label: `تم الاطلاع (${viewedCount})` },
                ].map((f) => _jsx("button", { onClick: () => setFilter(f.key), style: { padding: '6px 12px', borderRadius: radius.pill, fontSize: 12, border: filter === f.key ? 'none' : `1px solid ${colors.border}`, background: filter === f.key ? colors.primary : '#fff', color: filter === f.key ? '#fff' : colors.ink }, children: f.label }, f.key)) }), filtered.length === 0 ? _jsx("div", { style: { textAlign: 'center', color: colors.textMuted, padding: 20, border: `1px dashed ${colors.border}`, borderRadius: radius.card }, children: "لا توجد حالات مطابقة لهذا الفلتر." }) : _jsx("div", { style: { overflowX: 'auto' }, children: _jsxs("table", { style: { width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: teacherUid ? 700 : 820 }, children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "الطالبة" }), !teacherUid && _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "المعلمة" }), _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "المادة والفصل" }), _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "الأسبوع" }), _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "الحالة" }), _jsx("th", { style: { textAlign: 'right', padding: 8, borderBottom: `2px solid ${colors.border}` }, children: "اطلاع ولي الأمر" })] }) }), _jsx("tbody", { children: filtered.map((r) => _jsxs("tr", { style: { borderBottom: '1px solid #f0f0f0', background: r.viewedCurrent ? 'transparent' : '#fffafa' }, children: [_jsx("td", { style: { padding: 8, fontWeight: 'bold' }, children: r.studentName }), !teacherUid && _jsx("td", { style: { padding: 8 }, children: r.teacherName }), _jsxs("td", { style: { padding: 8 }, children: [_jsx("div", { children: r.subject }), _jsx("div", { style: { fontSize: 11, color: colors.textMuted }, children: r.className })] }), _jsxs("td", { style: { padding: 8 }, children: [_jsx("div", { children: r.weekName }), _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: r.weekTypeLabel })] }), _jsxs("td", { style: { padding: 8 }, children: [r.notMasteredCount > 0 && _jsxs("div", { style: { color: colors.red, fontWeight: 'bold' }, children: [r.notMasteredCount, " غير متقنة"] }), r.needsSupportCount > 0 && _jsxs("div", { style: { color: colors.amber, fontWeight: 'bold' }, children: [r.needsSupportCount, " تحتاج متابعة"] }), _jsx("div", { title: r.weakSkills.map((s) => s.title).join('، '), style: { fontSize: 10, color: colors.textMuted, marginTop: 2, maxWidth: 190, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, children: r.weakSkills.map((s) => s.title).join('، ') })] }), _jsx("td", { style: { padding: 8 }, children: r.viewedCurrent ? _jsxs("div", { children: [_jsx("strong", { style: { color: '#0b5c33' }, children: "✓ تم الاطلاع" }), _jsx("div", { style: { fontSize: 10, color: colors.textMuted }, children: formatDateTime(r.viewedAt) })] }) : _jsx("strong", { style: { color: colors.red }, children: "لم يطلع بعد" }) })] }, `${r.weekId}_${r.studentId}`)) })] }) })] }));
}
